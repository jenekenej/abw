"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { signIn } from "next-auth/react";
import { Loader2, ShoppingBag, Store } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input, NativeSelect } from "@/components/ui/input";
import { Field } from "@/components/ui/label";
import { registerSchema, type RegisterInput } from "@/lib/validation";
import { CITIES } from "@/lib/constants";
import { cn, isRecord } from "@/lib/utils";

export function RegisterForm() {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const { register, handleSubmit, watch, setValue, setError: setFieldError, formState } = useForm<RegisterInput>({
    resolver: zodResolver(registerSchema),
    defaultValues: { role: "buyer", sellerType: "individual", phone: "+375", city: "Минск" },
  });
  const role = watch("role");

  const onSubmit = async (values: RegisterInput) => {
    setError(null);
    const res = await fetch("/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    if (!res.ok) {
      const body: unknown = await res.json().catch(() => null);
      if (isRecord(body)) {
        setError(typeof body.error === "string" ? body.error : "Ошибка регистрации");
        if (isRecord(body.details) && typeof body.details.email === "string") {
          setFieldError("email", { message: body.details.email });
        }
      }
      return;
    }
    await signIn("credentials", { email: values.email, password: values.password, redirect: false });
    router.push(values.role === "seller" ? "/dashboard" : "/catalog");
    router.refresh();
  };

  const roleOption = (value: "buyer" | "seller", label: string, Icon: typeof Store) => (
    <button
      type="button"
      onClick={() => setValue("role", value)}
      className={cn(
        "flex flex-1 flex-col items-center gap-1 rounded-lg border p-4 text-sm font-medium",
        role === value ? "border-primary bg-accent text-accent-foreground" : "hover:border-primary/60",
      )}
    >
      <Icon className="h-6 w-6" />
      {label}
    </button>
  );

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="text-2xl">Регистрация</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="flex gap-3">
            {roleOption("buyer", "Покупатель", ShoppingBag)}
            {roleOption("seller", "Продавец", Store)}
          </div>
          <Field label={role === "seller" ? "Имя или название компании" : "Имя"} htmlFor="name" error={formState.errors.name?.message}>
            <Input id="name" {...register("name")} />
          </Field>
          <Field label="Email" htmlFor="email" error={formState.errors.email?.message}>
            <Input id="email" type="email" autoComplete="email" {...register("email")} />
          </Field>
          <Field label="Пароль" htmlFor="password" error={formState.errors.password?.message}>
            <Input id="password" type="password" autoComplete="new-password" {...register("password")} />
          </Field>
          {role === "seller" && (
            <>
              <Field label="Телефон" htmlFor="phone" error={formState.errors.phone?.message}>
                <Input id="phone" type="tel" {...register("phone")} />
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Город" htmlFor="city" error={formState.errors.city?.message}>
                  <NativeSelect id="city" {...register("city")}>
                    {CITIES.map((c) => <option key={c} value={c}>{c}</option>)}
                  </NativeSelect>
                </Field>
                <Field label="Тип продавца" htmlFor="sellerType">
                  <NativeSelect id="sellerType" {...register("sellerType")}>
                    <option value="individual">Частное лицо</option>
                    <option value="dealer">Дилер</option>
                  </NativeSelect>
                </Field>
              </div>
            </>
          )}
          {error && <p className="text-sm text-destructive">{error}</p>}
          <Button type="submit" className="w-full" disabled={formState.isSubmitting}>
            {formState.isSubmitting && <Loader2 className="h-4 w-4 animate-spin" />}
            Создать аккаунт
          </Button>
        </form>
        <p className="mt-4 text-center text-sm text-muted-foreground">
          Уже есть аккаунт? <Link href="/login" className="text-primary hover:underline">Войти</Link>
        </p>
      </CardContent>
    </Card>
  );
}
