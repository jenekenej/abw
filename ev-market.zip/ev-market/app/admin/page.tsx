import Link from "next/link";
import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { listingCardInclude, toListingCard } from "@/lib/serialize";
import { ModerationActions, SellerVerificationActions } from "@/components/admin/moderation-actions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ConditionBadge } from "@/components/listing/listing-badges";
import { formatDate, formatPrice } from "@/lib/utils";

export const metadata: Metadata = { title: "Модерация" };
export const dynamic = "force-dynamic";

/** Простая админка: очередь модерации объявлений, проверки оригинальности и верификации продавцов. */
export default async function AdminPage() {
  const user = await getSessionUser();
  if (user?.role !== "admin") redirect("/login?callbackUrl=/admin");

  const [moderation, originals, sellers, log] = await Promise.all([
    prisma.listing.findMany({
      where: { status: "moderation" },
      orderBy: { updatedAt: "asc" },
      include: { ...listingCardInclude, seller: { select: { id: true, displayName: true, verified: true } } },
    }),
    prisma.listing.findMany({
      where: { status: "active", isOriginal: true, originalVerified: false },
      select: { id: true, title: true, serialNumber: true, vin: true, certificateUrl: true, seller: { select: { displayName: true } } },
    }),
    prisma.seller.findMany({ where: { verificationStatus: "pending" }, include: { user: { select: { email: true } } } }),
    prisma.moderationLog.findMany({
      orderBy: { createdAt: "desc" },
      take: 15,
      include: { listing: { select: { id: true, title: true } }, actor: { select: { name: true } } },
    }),
  ]);

  return (
    <div className="container space-y-6 py-6">
      <h1 className="text-2xl font-bold">Модерация</h1>

      <Card>
        <CardHeader><CardTitle>Объявления на модерации ({moderation.length})</CardTitle></CardHeader>
        <CardContent className="divide-y">
          {moderation.length === 0 && <p className="text-sm text-muted-foreground">Очередь пуста 🎉</p>}
          {moderation.map((raw) => {
            const l = toListingCard(raw);
            return (
              <div key={l.id} className="flex flex-col gap-3 py-4 md:flex-row md:items-center">
                <div className="h-20 w-28 shrink-0 overflow-hidden rounded bg-muted">
                  {l.imageUrl && <img src={l.imageUrl} alt="" className="h-full w-full object-cover" />}
                </div>
                <div className="min-w-0 flex-1 space-y-1 text-sm">
                  <Link href={`/listing/${l.id}`} className="font-medium hover:text-primary">{l.title}</Link>
                  <div className="flex flex-wrap items-center gap-2 text-muted-foreground">
                    <ConditionBadge condition={l.condition} />
                    <span>{formatPrice(l.priceByn)}</span>
                    <span>· {l.categoryName} · {l.city}</span>
                    <span>· {raw.seller.displayName}{raw.seller.verified ? " ✓" : ""}</span>
                  </div>
                  {raw.isOriginal && (
                    <p className="text-xs">Заявлена оригинальность: {raw.serialNumber ?? raw.vin ?? "—"}</p>
                  )}
                </div>
                <ModerationActions listingId={l.id} kind="listing" />
              </div>
            );
          })}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Проверка оригинальности ({originals.length})</CardTitle></CardHeader>
        <CardContent className="divide-y">
          {originals.length === 0 && <p className="text-sm text-muted-foreground">Нет заявок.</p>}
          {originals.map((o) => (
            <div key={o.id} className="flex flex-col gap-3 py-3 text-sm md:flex-row md:items-center">
              <div className="min-w-0 flex-1">
                <Link href={`/listing/${o.id}`} className="font-medium hover:text-primary">{o.title}</Link>
                <p className="text-muted-foreground">
                  {o.seller.displayName} · S/N: {o.serialNumber ?? "—"} · VIN: {o.vin ?? "—"}
                  {o.certificateUrl && (
                    <> · <a href={o.certificateUrl} target="_blank" rel="noreferrer" className="text-primary hover:underline">сертификат</a></>
                  )}
                </p>
              </div>
              <ModerationActions listingId={o.id} kind="original" />
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Верификация продавцов ({sellers.length})</CardTitle></CardHeader>
        <CardContent className="divide-y">
          {sellers.length === 0 && <p className="text-sm text-muted-foreground">Нет заявок.</p>}
          {sellers.map((s) => (
            <div key={s.id} className="flex flex-col gap-3 py-3 text-sm md:flex-row md:items-center">
              <div className="min-w-0 flex-1">
                <p className="font-medium">{s.displayName} <span className="text-muted-foreground">({s.user.email})</span></p>
                <p className="text-muted-foreground">
                  {s.type === "dealer" ? "Дилер" : "Частное лицо"} · УНП {s.inn ?? "—"} · документов: {s.verificationDocs.length}
                </p>
                <div className="flex flex-wrap gap-2">
                  {s.verificationDocs.map((d, i) => (
                    <a key={d} href={d} target="_blank" rel="noreferrer" className="text-xs text-primary hover:underline">документ {i + 1}</a>
                  ))}
                </div>
              </div>
              <SellerVerificationActions sellerId={s.id} />
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Журнал модерации</CardTitle></CardHeader>
        <CardContent>
          <ul className="space-y-1 text-sm">
            {log.map((e) => (
              <li key={e.id} className="text-muted-foreground">
                {formatDate(e.createdAt.toISOString())} · <b className="text-foreground">{e.action}</b>
                {e.listing && <> · {e.listing.title}</>}
                {e.actor && <> · {e.actor.name}</>}
                {e.comment && <> · «{e.comment}»</>}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
