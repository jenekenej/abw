import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="container py-20 text-center">
      <p className="text-6xl font-bold text-primary">404</p>
      <h1 className="mt-4 text-2xl font-semibold">Страница не найдена</h1>
      <p className="mt-2 text-muted-foreground">Возможно, объявление снято с публикации или ссылка устарела.</p>
      <Button asChild className="mt-6"><Link href="/catalog">Перейти в каталог</Link></Button>
    </div>
  );
}
