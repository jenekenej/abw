import { Suspense } from "react";
import type { Metadata } from "next";
import { CatalogView } from "@/components/catalog/catalog-view";
import { getCategoryTree } from "@/lib/categories";

export const metadata: Metadata = { title: "Каталог электротранспорта" };
export const dynamic = "force-dynamic";

export default async function CatalogPage() {
  const categories = await getCategoryTree();
  return (
    // useSearchParams в клиентском компоненте требует Suspense-границы
    <Suspense>
      <CatalogView categories={categories} />
    </Suspense>
  );
}
