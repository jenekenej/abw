import { Suspense } from "react";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { CatalogView } from "@/components/catalog/catalog-view";
import { getCategoryTree } from "@/lib/categories";

export const dynamic = "force-dynamic";

interface Props {
  params: { categorySlug: string };
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const category = (await getCategoryTree()).find((c) => c.slug === params.categorySlug);
  return { title: category ? `${category.name} — купить в Беларуси` : "Категория не найдена" };
}

export default async function CategoryPage({ params }: Props) {
  const categories = await getCategoryTree();
  if (!categories.some((c) => c.slug === params.categorySlug)) notFound();
  return (
    <Suspense>
      <CatalogView categories={categories} categorySlug={params.categorySlug} />
    </Suspense>
  );
}
