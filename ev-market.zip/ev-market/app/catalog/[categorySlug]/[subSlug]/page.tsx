import { Suspense } from "react";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { CatalogView } from "@/components/catalog/catalog-view";
import { getCategoryTree } from "@/lib/categories";

export const dynamic = "force-dynamic";

interface Props {
  params: { categorySlug: string; subSlug: string };
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const category = (await getCategoryTree()).find((c) => c.slug === params.categorySlug);
  const sub = category?.children.find((s) => s.slug === params.subSlug);
  return { title: category && sub ? `${category.name}: ${sub.name}` : "Категория не найдена" };
}

export default async function SubcategoryPage({ params }: Props) {
  const categories = await getCategoryTree();
  const category = categories.find((c) => c.slug === params.categorySlug);
  if (!category || !category.children.some((s) => s.slug === params.subSlug)) notFound();
  return (
    <Suspense>
      <CatalogView categories={categories} categorySlug={params.categorySlug} subSlug={params.subSlug} />
    </Suspense>
  );
}
