import Link from "next/link";
import { Bike, Car, CircleDot, Disc3, Package, Zap, type LucideIcon } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { getCategoryTree } from "@/lib/categories";
import { listingCardInclude, toListingCard } from "@/lib/serialize";
import { ListingCard } from "@/components/listing/listing-card";
import { Button } from "@/components/ui/button";
import { plural } from "@/lib/utils";

export const dynamic = "force-dynamic";

const CATEGORY_ICONS: Record<string, LucideIcon> = {
  elektrovelosipedy: Bike,
  elektroskutery: Zap,
  elektromotocikly: Zap,
  giroskutery: Disc3,
  monokolesa: CircleDot,
  elektromobili: Car,
  "zapchasti-i-aksessuary": Package,
};

// Бренды для блока «Топ-бренды»: поиск по вхождению в заголовок.
// TODO: вынести бренд в отдельный справочник/атрибут.
const BRANDS = ["Surron", "Xiaomi", "Ninebot", "NIU", "Begode", "InMotion", "Super Soco", "Talaria", "BYD", "Nissan"];

export default async function HomePage() {
  const [categories, counts, fresh, brandCounts] = await Promise.all([
    getCategoryTree(),
    prisma.listing.groupBy({ by: ["categoryId"], where: { status: "active" }, _count: { _all: true } }),
    prisma.listing.findMany({
      where: { status: "active" },
      orderBy: { publishedAt: "desc" },
      take: 8,
      include: listingCardInclude,
    }),
    Promise.all(
      BRANDS.map(async (brand) => ({
        brand,
        count: await prisma.listing.count({
          where: { status: "active", title: { contains: brand, mode: "insensitive" } },
        }),
      })),
    ),
  ]);
  const countByCategory = new Map(counts.map((c) => [c.categoryId, c._count._all]));
  const topBrands = brandCounts.filter((b) => b.count > 0).sort((a, b) => b.count - a.count);

  return (
    <div className="container space-y-12 py-8">
      {/* Hero */}
      <section className="rounded-2xl bg-gradient-to-br from-primary to-emerald-700 px-6 py-10 text-white md:px-10 md:py-14">
        <h1 className="max-w-2xl text-3xl font-bold md:text-4xl">Электротранспорт в Беларуси — новый и с пробегом</h1>
        <p className="mt-3 max-w-xl text-white/85">
          Электровелосипеды, скутеры, моноколёса и электромобили. Проверка оригинальности и покупка в рассрочку от банков-партнёров.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Button asChild size="lg" variant="secondary">
            <Link href="/catalog">Смотреть каталог</Link>
          </Button>
          <Button asChild size="lg" variant="outline" className="border-white/40 bg-transparent text-white hover:bg-white/10 hover:text-white">
            <Link href="/catalog?has_installment=1">В рассрочку</Link>
          </Button>
        </div>
      </section>

      {/* Популярные категории */}
      <section>
        <h2 className="mb-4 text-xl font-bold">Популярные категории</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-7">
          {categories.map((c) => {
            const Icon = CATEGORY_ICONS[c.slug] ?? Zap;
            const n = countByCategory.get(c.id) ?? 0;
            return (
              <Link
                key={c.id}
                href={`/catalog/${c.slug}`}
                className="flex flex-col items-center gap-2 rounded-lg border bg-card p-4 text-center transition hover:border-primary hover:shadow-sm"
              >
                <Icon className="h-8 w-8 text-primary" />
                <span className="text-sm font-medium leading-tight">{c.name}</span>
                <span className="text-xs text-muted-foreground">
                  {n} {plural(n, ["объявление", "объявления", "объявлений"])}
                </span>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Свежие объявления */}
      <section>
        <div className="mb-4 flex items-end justify-between">
          <h2 className="text-xl font-bold">Свежие объявления</h2>
          <Link href="/catalog" className="text-sm text-primary hover:underline">Все объявления →</Link>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {fresh.map((l) => (
            <ListingCard key={l.id} listing={toListingCard(l)} />
          ))}
        </div>
      </section>

      {/* Топ-бренды */}
      {topBrands.length > 0 && (
        <section>
          <h2 className="mb-4 text-xl font-bold">Топ-бренды</h2>
          <div className="flex flex-wrap gap-2">
            {topBrands.map((b) => (
              <Link
                key={b.brand}
                href={`/catalog?q=${encodeURIComponent(b.brand)}`}
                className="rounded-full border bg-card px-4 py-2 text-sm font-medium hover:border-primary"
              >
                {b.brand} <span className="text-muted-foreground">{b.count}</span>
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
