import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";
import { Providers } from "@/components/providers";
import { Header } from "@/components/layout/header";

export const metadata: Metadata = {
  title: { default: "ЭлектроРынок — электротранспорт в Беларуси", template: "%s · ЭлектроРынок" },
  description: "Объявления о продаже электровелосипедов, электроскутеров, моноколёс и электромобилей в Беларуси.",
};

// Скрипт до гидрации: применяем сохранённую тему, чтобы не было «вспышки» светлой темы
const themeScript = `try{var t=localStorage.getItem('ev-theme');if(t==='dark'||(!t&&matchMedia('(prefers-color-scheme: dark)').matches))document.documentElement.classList.add('dark')}catch(e){}`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body className="font-sans">
        <Providers>
          <Header />
          <main className="min-h-[calc(100vh-8rem)]">{children}</main>
          <footer className="border-t py-6 text-sm text-muted-foreground">
            <div className="container flex flex-wrap items-center justify-between gap-2">
              <span>© {new Date().getFullYear()} ЭлектроРынок — MVP классифайда электротранспорта</span>
              <Link href="/catalog" className="hover:text-foreground">
                Все объявления
              </Link>
            </div>
          </footer>
        </Providers>
      </body>
    </html>
  );
}
