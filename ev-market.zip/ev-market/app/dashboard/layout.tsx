import Link from "next/link";
import { BadgeCheck, CreditCard, LayoutList, Plus } from "lucide-react";
import { requireSeller } from "@/lib/dashboard";

const NAV = [
  { href: "/dashboard", label: "Мои объявления", icon: LayoutList },
  { href: "/dashboard/listings/new", label: "Создать объявление", icon: Plus },
  { href: "/dashboard/installments", label: "Рассрочка", icon: CreditCard },
  { href: "/dashboard/verification", label: "Верификация", icon: BadgeCheck },
];

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const user = await requireSeller();
  return (
    <div className="container grid gap-6 py-6 lg:grid-cols-[220px_1fr]">
      <aside className="space-y-1">
        <p className="mb-2 px-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Кабинет продавца · {user.name}
        </p>
        <nav className="flex gap-1 overflow-x-auto lg:flex-col">
          {NAV.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              className="flex shrink-0 items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-accent hover:text-accent-foreground"
            >
              <Icon className="h-4 w-4" /> {label}
            </Link>
          ))}
        </nav>
      </aside>
      <div className="min-w-0">{children}</div>
    </div>
  );
}
