import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ListingWizard } from "@/components/dashboard/listing-wizard";
import { getCategoryTree } from "@/lib/categories";
import { getBankOptions, getListingFormValues, requireSeller } from "@/lib/dashboard";

export const metadata: Metadata = { title: "Редактирование объявления" };
export const dynamic = "force-dynamic";

export default async function EditListingPage({ params }: { params: { id: string } }) {
  const user = await requireSeller();
  const [categories, banks, values] = await Promise.all([
    getCategoryTree(),
    getBankOptions(),
    getListingFormValues(params.id, user.sellerId),
  ]);
  if (!values) notFound();
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Редактирование объявления</h1>
      <p className="text-sm text-muted-foreground">После сохранения объявление повторно пройдёт модерацию.</p>
      <ListingWizard categories={categories} banks={banks} listingId={params.id} initialValues={values} />
    </div>
  );
}
