import type { Metadata } from "next";
import { ListingWizard } from "@/components/dashboard/listing-wizard";
import { getCategoryTree } from "@/lib/categories";
import { getBankOptions } from "@/lib/dashboard";

export const metadata: Metadata = { title: "Новое объявление" };
export const dynamic = "force-dynamic";

export default async function NewListingPage() {
  const [categories, banks] = await Promise.all([getCategoryTree(), getBankOptions()]);
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Новое объявление</h1>
      <ListingWizard categories={categories} banks={banks} />
    </div>
  );
}
