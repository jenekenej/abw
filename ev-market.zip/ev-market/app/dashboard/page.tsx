import Link from "next/link";
import type { Metadata } from "next";
import { Plus } from "lucide-react";
import type { ListingStatus } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { requireSeller } from "@/lib/dashboard";
import { listingCardInclude, toListingCard } from "@/lib/serialize";
import { Button } from "@/components/ui/button";
import { ListingsTable } from "@/components/dashboard/listings-table";
import { cn } from "@/lib/utils";

export const metadata: Metadata = { title: "Мои объявления" };
export const dynamic = "force-dynamic";

const TABS: { key: string; label: string; statuses: ListingStatus[] }[] = [
  { key: "all", label: "Все", statuses: ["active", "moderation", "rejected", "archived", "draft"] },
  { key: "active", label: "Активные", statuses: ["active"] },
  { key: "moderation", label: "На модерации", statuses: ["moderation", "rejected"] },
  { key: "archived", label: "Архив", statuses: ["archived"] },
];

interface Props {
  searchParams: { status?: string; saved?: string };
}

export default async function DashboardPage({ searchParams }: Props) {
  const user = await requireSeller();
  const tab = TABS.find((t) => t.key === searchParams.status) ?? TABS[0];

  const [listings, counts] = await Promise.all([
    prisma.listing.findMany({
      where: { sellerId: user.sellerId, status: { in: tab.statuses } },
      orderBy: { createdAt: "desc" },
      include: listingCardInclude,
    }),
    prisma.listing.groupBy({ by: ["status"], where: { sellerId: user.sellerId }, _count: { _all: true } }),
  ]);
  const countFor = (statuses: ListingStatus[]) =>
    counts.filter((c) => statuses.includes(c.status)).reduce((sum, c) => sum + c._count._all, 0);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-bold">Мои объявления</h1>
        <Button asChild>
          <Link href="/dashboard/listings/new">
            <Plus className="h-4 w-4" /> Создать объявление
          </Link>
        </Button>
      </div>

      {searchParams.saved && (
        <div className="rounded-lg border border-tag-new/40 bg-tag-new/10 p-3 text-sm">
          {searchParams.saved === "active"
            ? "Объявление опубликовано."
            : "Объявление отправлено на модерацию. Обычно проверка занимает до 1 часа."}
        </div>
      )}

      <div className="flex gap-1 overflow-x-auto border-b">
        {TABS.map((t) => (
          <Link
            key={t.key}
            href={t.key === "all" ? "/dashboard" : `/dashboard?status=${t.key}`}
            className={cn(
              "shrink-0 border-b-2 px-3 py-2 text-sm",
              t.key === tab.key ? "border-primary font-medium text-foreground" : "border-transparent text-muted-foreground hover:text-foreground",
            )}
          >
            {t.label} <span className="text-muted-foreground">{countFor(t.statuses)}</span>
          </Link>
        ))}
      </div>

      <ListingsTable listings={listings.map(toListingCard)} />
    </div>
  );
}
