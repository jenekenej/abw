import Link from "next/link";
import type { Metadata } from "next";
import { Pencil } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireSeller } from "@/lib/dashboard";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatDate, formatPrice } from "@/lib/utils";

export const metadata: Metadata = { title: "Рассрочка" };
export const dynamic = "force-dynamic";

const APP_STATUS: Record<string, { label: string; variant: "secondary" | "installment" | "new" | "discounted" }> = {
  created: { label: "Создана", variant: "secondary" },
  sent: { label: "Отправлена в банк", variant: "installment" },
  approved: { label: "Одобрена", variant: "new" },
  rejected: { label: "Отказ", variant: "discounted" },
};

/** Настройка рассрочки: банки-партнёры, условия по объявлениям и входящие заявки. */
export default async function InstallmentsPage() {
  const user = await requireSeller();
  const [banks, listings, applications] = await Promise.all([
    prisma.bank.findMany({ orderBy: { name: "asc" } }),
    prisma.listing.findMany({
      where: { sellerId: user.sellerId, status: { in: ["active", "moderation"] } },
      include: { installmentOffers: { include: { bank: true } } },
      orderBy: { createdAt: "desc" },
    }),
    prisma.installmentApplication.findMany({
      where: { listing: { sellerId: user.sellerId } },
      include: { bank: true, listing: { select: { id: true, title: true } } },
      orderBy: { createdAt: "desc" },
      take: 50,
    }),
  ]);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Рассрочка</h1>

      <Card>
        <CardHeader><CardTitle>Банки-партнёры</CardTitle></CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-3">
          {banks.map((b) => (
            <div key={b.id} className="rounded-lg border p-4">
              <p className="font-medium">{b.name}</p>
              <p className="text-sm text-muted-foreground">
                {b.defaultRate === 0 ? "0% — рассрочка без переплаты" : `${Math.round(b.defaultRate * 100)}% годовых`}
              </p>
            </div>
          ))}
          <p className="text-xs text-muted-foreground sm:col-span-3">
            Интеграция с банками в MVP — заглушка: заявки сохраняются в БД, статусы обновляются через webhook
            <code className="mx-1">/api/webhooks/bank/[bankId]</code>.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Условия по объявлениям</CardTitle></CardHeader>
        <CardContent className="divide-y">
          {listings.length === 0 && <p className="text-sm text-muted-foreground">Нет активных объявлений.</p>}
          {listings.map((l) => (
            <div key={l.id} className="flex flex-wrap items-center gap-3 py-3 text-sm">
              <Link href={`/listing/${l.id}`} className="min-w-0 flex-1 truncate font-medium hover:text-primary">{l.title}</Link>
              {l.installmentOffers.length === 0 ? (
                <span className="text-muted-foreground">Рассрочка не подключена</span>
              ) : (
                <div className="flex flex-wrap gap-1">
                  {l.installmentOffers.map((o) => (
                    <Badge key={o.id} variant="installment">
                      {o.bank.name.replace(" (демо)", "")}: {o.terms.join("/")} мес.{o.minDownPercent ? `, от ${o.minDownPercent}%` : ""}
                    </Badge>
                  ))}
                </div>
              )}
              <Button asChild size="sm" variant="ghost">
                <Link href={`/dashboard/listings/${l.id}/edit`}><Pencil className="h-3.5 w-3.5" /> Настроить</Link>
              </Button>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Заявки покупателей</CardTitle></CardHeader>
        <CardContent>
          {applications.length === 0 ? (
            <p className="text-sm text-muted-foreground">Заявок пока нет.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[640px] text-sm">
                <thead className="text-left text-xs uppercase text-muted-foreground">
                  <tr><th className="py-2">Дата</th><th>Товар</th><th>Банк</th><th>Условия</th><th>Статус</th></tr>
                </thead>
                <tbody className="divide-y">
                  {applications.map((a) => {
                    const s = APP_STATUS[a.status] ?? APP_STATUS.created;
                    return (
                      <tr key={a.id}>
                        <td className="py-2">{formatDate(a.createdAt.toISOString())}</td>
                        <td className="max-w-[200px] truncate">{a.listing.title}</td>
                        <td>{a.bank.name}</td>
                        <td>{a.termMonths} мес. · {formatPrice(a.monthlyPayment.toNumber())}/мес.</td>
                        <td><Badge variant={s.variant}>{s.label}</Badge></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
