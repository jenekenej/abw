import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { requireSeller } from "@/lib/dashboard";
import { VerificationForm } from "@/components/dashboard/verification-form";

export const metadata: Metadata = { title: "Верификация" };
export const dynamic = "force-dynamic";

export default async function VerificationPage() {
  const user = await requireSeller();
  const seller = await prisma.seller.findUniqueOrThrow({
    where: { id: user.sellerId },
    select: { type: true, inn: true, verificationStatus: true, verificationDocs: true, verified: true },
  });
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Верификация продавца</h1>
      <p className="max-w-2xl text-sm text-muted-foreground">
        Проверенные продавцы получают бейдж «Проверенный продавец» и больше доверия покупателей. Для проверки
        оригинальности конкретного товара укажите серийный номер / VIN в форме объявления.
      </p>
      <VerificationForm initial={seller} />
    </div>
  );
}
