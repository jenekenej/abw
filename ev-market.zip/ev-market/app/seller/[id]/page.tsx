import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { BadgeCheck, CalendarDays, MapPin, Star, Store } from "lucide-react";
import { getSellerProfile } from "@/lib/sellers";
import { ListingCard } from "@/components/listing/listing-card";
import { formatDate, plural } from "@/lib/utils";

export const dynamic = "force-dynamic";

interface Props {
  params: { id: string };
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const p = await getSellerProfile(params.id);
  return { title: p ? `Продавец ${p.seller.displayName}` : "Продавец не найден" };
}

export default async function SellerPage({ params }: Props) {
  const profile = await getSellerProfile(params.id);
  if (!profile) notFound();
  const { seller, listings } = profile;

  return (
    <div className="container space-y-6 py-6">
      <div className="flex flex-col gap-4 rounded-lg border bg-card p-6 sm:flex-row sm:items-center">
        <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-accent text-accent-foreground">
          <Store className="h-8 w-8" />
        </div>
        <div className="space-y-1">
          <h1 className="flex items-center gap-2 text-2xl font-bold">
            {seller.displayName}
            {seller.verified && <BadgeCheck className="h-6 w-6 text-tag-original" aria-label="Проверенный продавец" />}
          </h1>
          <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground">
            <span>{seller.type === "dealer" ? "Дилер" : "Частное лицо"}</span>
            <span className="inline-flex items-center gap-1"><MapPin className="h-4 w-4" />{seller.city}</span>
            <span className="inline-flex items-center gap-1">
              <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
              {seller.rating.toFixed(1)} ({seller.ratingCount})
            </span>
            <span className="inline-flex items-center gap-1"><CalendarDays className="h-4 w-4" />на сайте с {formatDate(seller.createdAt)}</span>
          </div>
        </div>
      </div>

      <h2 className="text-xl font-bold">
        {listings.length} {plural(listings.length, ["активное объявление", "активных объявления", "активных объявлений"])}
      </h2>
      {listings.length === 0 ? (
        <p className="rounded-lg border border-dashed p-10 text-center text-muted-foreground">У продавца пока нет активных объявлений.</p>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {listings.map((l) => <ListingCard key={l.id} listing={l} />)}
        </div>
      )}
    </div>
  );
}
