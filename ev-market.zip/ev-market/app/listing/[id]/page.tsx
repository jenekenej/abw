import Link from "next/link";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { BadgeCheck, CalendarDays, Eye, MapPin, ShieldAlert, ShieldCheck, Star, Store } from "lucide-react";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { getSessionUser } from "@/lib/auth";
import { listingCardInclude, listingDetailInclude, toListingCard, toListingDetail } from "@/lib/serialize";
import { Gallery } from "@/components/listing/gallery";
import { ContactButtons } from "@/components/listing/contact-buttons";
import { InstallmentDialog } from "@/components/listing/installment-dialog";
import { ConditionBadge, ListingBadges } from "@/components/listing/listing-badges";
import { ListingCard } from "@/components/listing/listing-card";
import { Price } from "@/components/price";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LISTING_STATUS_LABELS } from "@/lib/constants";
import { formatDate, plural } from "@/lib/utils";
import type { AttrValue, AttributeDefinitionDTO } from "@/types";

export const dynamic = "force-dynamic";

interface Props {
  params: { id: string };
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const l = await prisma.listing.findUnique({ where: { id: params.id }, select: { title: true } });
  return { title: l?.title ?? "Объявление не найдено" };
}

function formatAttr(def: AttributeDefinitionDTO, value: AttrValue): string {
  if (typeof value === "boolean") return value ? "Да" : "Нет";
  if (typeof value === "number") return `${value.toLocaleString("ru-RU")}${def.unit ? ` ${def.unit}` : ""}`;
  return value;
}

export default async function ListingPage({ params }: Props) {
  const raw = await prisma.listing.findUnique({ where: { id: params.id }, include: listingDetailInclude });
  if (!raw) notFound();

  const user = await getSessionUser();
  const isOwner = user?.sellerId === raw.sellerId;
  const canSeeHidden = isOwner || user?.role === "admin";
  if (raw.status !== "active" && !canSeeHidden) notFound();

  // Счётчик просмотров (для сортировки «по популярности»). Свои просмотры не считаем.
  if (raw.status === "active" && !isOwner) {
    await prisma.listing.update({ where: { id: raw.id }, data: { views: { increment: 1 } } });
  }

  const listing = toListingDetail(raw);
  const price = raw.priceByn.toNumber();

  // Похожие: та же категория, цена ±20%
  const similarRaw = await prisma.listing.findMany({
    where: {
      status: "active",
      categoryId: raw.categoryId,
      id: { not: raw.id },
      priceByn: { gte: new Prisma.Decimal(price * 0.8), lte: new Prisma.Decimal(price * 1.2) },
    },
    include: listingCardInclude,
    take: 4,
    orderBy: { views: "desc" },
  });
  const similar = similarRaw.map(toListingCard);

  // Таблица характеристик — только заполненные поля
  const specs = listing.attributeDefinitions
    .filter((d) => listing.attrs[d.code] !== undefined && listing.attrs[d.code] !== false)
    .map((d) => ({ name: d.name, value: formatAttr(d, listing.attrs[d.code] as AttrValue) }));

  return (
    <div className="container py-6">
      <nav className="mb-3 text-sm text-muted-foreground">
        <Link href="/catalog" className="hover:text-foreground">Каталог</Link>
        {" / "}
        <Link href={`/catalog/${listing.category.slug}`} className="hover:text-foreground">{listing.category.name}</Link>
        {listing.subcategory && (
          <>
            {" / "}
            <Link href={`/catalog/${listing.category.slug}/${listing.subcategory.slug}`} className="hover:text-foreground">
              {listing.subcategory.name}
            </Link>
          </>
        )}
      </nav>

      {listing.status !== "active" && (
        <div className="mb-4 rounded-lg border border-tag-discounted/40 bg-tag-discounted/10 p-3 text-sm">
          Статус объявления: <b>{LISTING_STATUS_LABELS[listing.status]}</b>. Его видите только вы и модераторы.
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-[1fr_380px]">
        {/* Левая часть: галерея, описание, характеристики */}
        <div className="min-w-0 space-y-6">
          <Gallery media={listing.media} title={listing.title} />

          <div className="space-y-3 lg:hidden">
            <TitleBlock />
          </div>

          <Card>
            <CardHeader><CardTitle>Характеристики</CardTitle></CardHeader>
            <CardContent>
              <dl className="divide-y text-sm">
                <SpecRow name="Состояние" value={<ConditionBadge condition={listing.condition} />} />
                {listing.condition === "discounted" && listing.discountReason && (
                  <SpecRow name="Причина уценки" value={listing.discountReason} />
                )}
                {specs.map((s) => <SpecRow key={s.name} name={s.name} value={s.value} />)}
                <SpecRow name="Город" value={listing.city} />
              </dl>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Описание</CardTitle></CardHeader>
            <CardContent>
              <p className="whitespace-pre-line text-sm leading-relaxed">{listing.description}</p>
            </CardContent>
          </Card>

          {/* Проверка оригинальности */}
          <Card>
            <CardHeader><CardTitle>Проверка оригинальности</CardTitle></CardHeader>
            <CardContent className="space-y-3 text-sm">
              {listing.originalVerified ? (
                <div className="flex items-start gap-2 rounded-md bg-tag-original/10 p-3 text-tag-original">
                  <ShieldCheck className="h-5 w-5 shrink-0" />
                  <span>Оригинальность подтверждена модератором по серийному номеру / VIN и документам продавца.</span>
                </div>
              ) : listing.isOriginal ? (
                <div className="flex items-start gap-2 rounded-md bg-muted p-3">
                  <ShieldAlert className="h-5 w-5 shrink-0 text-tag-discounted" />
                  <span>Продавец заявил, что товар оригинальный. Проверка ещё не завершена.</span>
                </div>
              ) : (
                <p className="text-muted-foreground">Продавец не подавал заявку на проверку оригинальности.</p>
              )}
              {(listing.serialNumber || listing.vin) && (
                <dl className="divide-y">
                  {listing.serialNumber && <SpecRow name="Серийный номер" value={<code>{listing.serialNumber}</code>} />}
                  {listing.vin && <SpecRow name="VIN" value={<code>{listing.vin}</code>} />}
                </dl>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Правая колонка: цена, кнопки, продавец */}
        <aside className="space-y-4 lg:sticky lg:top-20 lg:self-start">
          <Card className="space-y-4 p-5">
            <div className="hidden space-y-3 lg:block">
              <TitleBlock />
            </div>
            <ContactButtons phone={raw.seller.phone} />
            {listing.hasInstallment && listing.installmentOffers.length > 0 && (
              <InstallmentDialog listingId={listing.id} priceByn={listing.priceByn} offers={listing.installmentOffers} />
            )}
            {isOwner && (
              <Button asChild variant="outline" className="w-full">
                <Link href={`/dashboard/listings/${listing.id}/edit`}>Редактировать</Link>
              </Button>
            )}
          </Card>

          <Card className="p-5">
            <div className="flex items-start gap-3">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-accent text-accent-foreground">
                <Store className="h-6 w-6" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="flex items-center gap-1 font-semibold">
                  <span className="truncate">{listing.seller.displayName}</span>
                  {listing.seller.verified && <BadgeCheck className="h-4 w-4 shrink-0 text-tag-original" aria-label="Проверенный продавец" />}
                </p>
                <p className="text-xs text-muted-foreground">
                  {listing.seller.type === "dealer" ? "Дилер" : "Частное лицо"} · {listing.seller.city}
                </p>
                <p className="mt-1 flex items-center gap-1 text-sm">
                  <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                  {listing.seller.rating.toFixed(1)}
                  <span className="text-muted-foreground">({listing.seller.ratingCount} отзывов)</span>
                </p>
                <p className="text-sm text-muted-foreground">
                  {listing.seller.activeListings} {plural(listing.seller.activeListings, ["объявление", "объявления", "объявлений"])}
                </p>
              </div>
            </div>
            {listing.seller.verified && (
              <Badge variant="original" className="mt-3">Проверенный продавец</Badge>
            )}
            <Button asChild variant="outline" className="mt-4 w-full">
              <Link href={`/seller/${listing.seller.id}`}>Все объявления продавца</Link>
            </Button>
          </Card>
        </aside>
      </div>

      {similar.length > 0 && (
        <section className="mt-10">
          <h2 className="mb-4 text-xl font-bold">Похожие объявления</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {similar.map((l) => <ListingCard key={l.id} listing={l} />)}
          </div>
        </section>
      )}
    </div>
  );

  // Заголовок, цена и бейджи — рендерятся в разных местах для mobile/desktop
  function TitleBlock() {
    return (
      <>
        <h1 className="text-2xl font-bold leading-tight">{listing.title}</h1>
        <div className="flex items-baseline gap-3">
          <Price byn={listing.priceByn} className="text-3xl font-bold" />
          {listing.oldPriceByn && <Price byn={listing.oldPriceByn} className="text-lg text-muted-foreground line-through" />}
        </div>
        <ListingBadges badges={listing.badges} />
        <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />{listing.city}</span>
          <span className="inline-flex items-center gap-1"><CalendarDays className="h-3.5 w-3.5" />{formatDate(listing.createdAt)}</span>
          <span className="inline-flex items-center gap-1"><Eye className="h-3.5 w-3.5" />{listing.views}</span>
        </div>
      </>
    );
  }
}

function SpecRow({ name, value }: { name: string; value: React.ReactNode }) {
  return (
    <div className="flex justify-between gap-4 py-2">
      <dt className="text-muted-foreground">{name}</dt>
      <dd className="text-right font-medium">{value}</dd>
    </div>
  );
}
