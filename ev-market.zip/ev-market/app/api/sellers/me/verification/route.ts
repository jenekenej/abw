import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSessionUser, hasRole } from "@/lib/auth";
import { jsonError, readJson, zodDetails } from "@/lib/api";
import { sellerVerificationSchema } from "@/lib/validation";

// GET — текущий статус верификации продавца
export async function GET() {
  const user = await getSessionUser();
  if (!hasRole(user, "seller") || !user.sellerId) return jsonError(403, "Доступно только продавцам");
  const seller = await prisma.seller.findUniqueOrThrow({
    where: { id: user.sellerId },
    select: { type: true, inn: true, verificationStatus: true, verificationDocs: true, verified: true },
  });
  return NextResponse.json(seller);
}

// POST — подать заявку на верификацию продавца (статус pending → решение в /admin)
export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!hasRole(user, "seller") || !user.sellerId) return jsonError(403, "Доступно только продавцам");

  const parsed = sellerVerificationSchema.safeParse(await readJson(req));
  if (!parsed.success) return jsonError(400, "Проверьте поля формы", zodDetails(parsed.error));

  const seller = await prisma.seller.update({
    where: { id: user.sellerId },
    data: {
      type: parsed.data.type,
      inn: parsed.data.inn,
      verificationDocs: parsed.data.docs,
      verificationStatus: "pending",
    },
    select: { verificationStatus: true },
  });
  await prisma.moderationLog.create({
    data: { sellerId: user.sellerId, actorId: user.id, action: "submitted", comment: "Заявка на верификацию продавца" },
  });
  return NextResponse.json(seller);
}
