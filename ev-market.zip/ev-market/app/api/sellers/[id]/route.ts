import { NextResponse } from "next/server";
import { getSellerProfile } from "@/lib/sellers";
import { jsonError } from "@/lib/api";

// GET /api/sellers/[id] — публичный профиль продавца и его активные объявления
export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const profile = await getSellerProfile(params.id);
  if (!profile) return jsonError(404, "Продавец не найден");
  return NextResponse.json(profile);
}
