import { NextResponse } from "next/server";
import { getCategoryTree } from "@/lib/categories";

export const dynamic = "force-dynamic";

// GET /api/categories — дерево категорий с атрибутами
export async function GET() {
  return NextResponse.json(await getCategoryTree());
}
