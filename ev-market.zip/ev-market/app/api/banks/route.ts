import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

// GET /api/banks — список банков-партнёров (для формы объявления)
export async function GET() {
  const banks = await prisma.bank.findMany({
    orderBy: { name: "asc" },
    select: { id: true, code: true, name: true, defaultRate: true },
  });
  return NextResponse.json(banks);
}
