import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { jsonError, readJson, zodDetails } from "@/lib/api";
import { registerSchema } from "@/lib/validation";

// POST /api/register — регистрация покупателя или продавца
export async function POST(req: Request) {
  const parsed = registerSchema.safeParse(await readJson(req));
  if (!parsed.success) return jsonError(400, "Проверьте поля формы", zodDetails(parsed.error));
  const { name, email, password, role, phone, city, sellerType } = parsed.data;

  const normalizedEmail = email.toLowerCase();
  if (await prisma.user.findUnique({ where: { email: normalizedEmail } })) {
    return jsonError(409, "Пользователь с таким email уже существует", { email: "Email уже занят" });
  }

  const normalizedPhone = phone?.replace(/[\s()-]/g, "") ?? null;
  const user = await prisma.user.create({
    data: {
      email: normalizedEmail,
      name,
      role,
      phone: normalizedPhone,
      passwordHash: await bcrypt.hash(password, 10),
      seller:
        role === "seller"
          ? {
              create: {
                displayName: name,
                type: sellerType ?? "individual",
                city: city ?? "Минск",
                phone: normalizedPhone ?? "",
              },
            }
          : undefined,
    },
  });
  return NextResponse.json({ id: user.id }, { status: 201 });
}
