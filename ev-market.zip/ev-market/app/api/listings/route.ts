import { NextResponse, type NextRequest } from "next/server";
import { parseFilters } from "@/lib/filters";
import { searchListings } from "@/lib/search";
import { getSessionUser, hasRole } from "@/lib/auth";
import { jsonError, readJson, zodDetails } from "@/lib/api";
import { listingInputSchema } from "@/lib/validation";
import { ListingValidationError, saveListing } from "@/lib/listing-service";

export const dynamic = "force-dynamic";

// GET /api/listings?category&condition&price_min&...&sort&page
export async function GET(req: NextRequest) {
  const filters = parseFilters(req.nextUrl.searchParams);
  return NextResponse.json(await searchListings(filters));
}

// POST /api/listings — создание объявления (только продавец)
export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!hasRole(user, "seller") || !user.sellerId) return jsonError(403, "Доступно только продавцам");

  const parsed = listingInputSchema.safeParse(await readJson(req));
  if (!parsed.success) return jsonError(400, "Проверьте поля формы", zodDetails(parsed.error));

  try {
    const result = await saveListing(user.sellerId, user.id, parsed.data);
    return NextResponse.json(result, { status: 201 });
  } catch (e: unknown) {
    if (e instanceof ListingValidationError) return jsonError(400, e.message, e.details);
    throw e;
  }
}
