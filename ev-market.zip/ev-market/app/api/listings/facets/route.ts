import { NextResponse, type NextRequest } from "next/server";
import { parseFilters } from "@/lib/filters";
import { getFacets } from "@/lib/search";

export const dynamic = "force-dynamic";

// GET /api/listings/facets — счётчики для каждого значения фильтров.
// Принимает те же параметры, что и /api/listings.
export async function GET(req: NextRequest) {
  return NextResponse.json(await getFacets(parseFilters(req.nextUrl.searchParams)));
}
