import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSessionUser } from "@/lib/auth";
import { jsonError, readJson, zodDetails } from "@/lib/api";
import { listingVerifySchema } from "@/lib/validation";
import { syncBadges } from "@/lib/listing-service";

interface Ctx {
  params: { id: string };
}

// POST /api/listings/[id]/verify — заявка на проверку оригинальности.
// Сбрасывает originalVerified; подтверждает администратор в /admin.
export async function POST(req: Request, { params }: Ctx) {
  const user = await getSessionUser();
  const listing = await prisma.listing.findUnique({ where: { id: params.id } });
  if (!user || !listing || listing.sellerId !== user.sellerId) return jsonError(403, "Нет доступа");

  const parsed = listingVerifySchema.safeParse(await readJson(req));
  if (!parsed.success) return jsonError(400, "Проверьте поля", zodDetails(parsed.error));

  await prisma.$transaction(async (tx) => {
    await tx.listing.update({
      where: { id: listing.id },
      data: {
        isOriginal: true,
        originalVerified: false,
        serialNumber: parsed.data.serialNumber || listing.serialNumber,
        vin: parsed.data.vin || listing.vin,
        certificateUrl: parsed.data.certificateUrl || listing.certificateUrl,
      },
    });
    await syncBadges(tx, listing.id);
    await tx.moderationLog.create({
      data: { listingId: listing.id, actorId: user.id, action: "submitted", comment: "Заявка на проверку оригинальности" },
    });
  });
  return NextResponse.json({ ok: true, status: "pending" });
}
