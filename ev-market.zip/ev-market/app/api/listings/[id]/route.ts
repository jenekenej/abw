import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSessionUser, hasRole, type SessionUser } from "@/lib/auth";
import { jsonError, readJson, zodDetails } from "@/lib/api";
import { listingDetailInclude, toListingDetail } from "@/lib/serialize";
import { listingPatchSchema } from "@/lib/validation";
import { ListingValidationError, saveListing } from "@/lib/listing-service";

interface Ctx {
  params: { id: string };
}

/** Владелец объявления или администратор. */
async function canManage(user: SessionUser | null, listingId: string): Promise<boolean> {
  if (!user) return false;
  if (user.role === "admin") return true;
  const listing = await prisma.listing.findUnique({ where: { id: listingId }, select: { sellerId: true } });
  return listing !== null && listing.sellerId === user.sellerId;
}

// GET /api/listings/[id] — активное объявление доступно всем, остальные — владельцу/админу
export async function GET(_req: Request, { params }: Ctx) {
  const listing = await prisma.listing.findUnique({ where: { id: params.id }, include: listingDetailInclude });
  if (!listing) return jsonError(404, "Объявление не найдено");
  if (listing.status !== "active" && !(await canManage(await getSessionUser(), listing.id))) {
    return jsonError(404, "Объявление не найдено");
  }
  return NextResponse.json(toListingDetail(listing));
}

// PATCH /api/listings/[id] — { data } для редактирования или { status: "archived" | "moderation" }
export async function PATCH(req: Request, { params }: Ctx) {
  const user = await getSessionUser();
  if (!user || !(await canManage(user, params.id))) return jsonError(403, "Нет доступа");

  const parsed = listingPatchSchema.safeParse(await readJson(req));
  if (!parsed.success) return jsonError(400, "Некорректный запрос", zodDetails(parsed.error));

  const listing = await prisma.listing.findUniqueOrThrow({ where: { id: params.id } });

  try {
    if (parsed.data.data) {
      const result = await saveListing(listing.sellerId, user.id, parsed.data.data, listing.id);
      return NextResponse.json(result);
    }
    if (parsed.data.status) {
      const status = parsed.data.status;
      await prisma.$transaction([
        prisma.listing.update({ where: { id: listing.id }, data: { status } }),
        prisma.moderationLog.create({
          data: { listingId: listing.id, actorId: user.id, action: status === "archived" ? "archived" : "submitted" },
        }),
      ]);
      return NextResponse.json({ id: listing.id, status });
    }
    return jsonError(400, "Нечего обновлять");
  } catch (e: unknown) {
    if (e instanceof ListingValidationError) return jsonError(400, e.message, e.details);
    throw e;
  }
}

// DELETE /api/listings/[id]
export async function DELETE(_req: Request, { params }: Ctx) {
  const user = await getSessionUser();
  if (!hasRole(user, "seller", "admin") || !(await canManage(user, params.id))) {
    return jsonError(403, "Нет доступа");
  }
  await prisma.listing.delete({ where: { id: params.id } });
  return new NextResponse(null, { status: 204 });
}
