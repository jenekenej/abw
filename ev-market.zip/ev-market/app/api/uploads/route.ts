import { NextResponse } from "next/server";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { getSessionUser } from "@/lib/auth";
import { jsonError } from "@/lib/api";

const MAX_SIZE = 10 * 1024 * 1024; // 10 МБ
const ALLOWED: Record<string, string> = {
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/webp": ".webp",
  "video/mp4": ".mp4",
  "application/pdf": ".pdf",
};

// POST /api/uploads — multipart/form-data, поле `files`.
// MVP: сохраняем в /public/uploads. В проде заменить на загрузку в S3 (presigned URL).
export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) return jsonError(401, "Требуется вход");

  const form = await req.formData();
  const files = form.getAll("files").filter((f): f is File => f instanceof File);
  if (files.length === 0) return jsonError(400, "Файлы не переданы");

  const dir = path.join(process.cwd(), "public", "uploads");
  await mkdir(dir, { recursive: true });

  const saved: { url: string; kind: "image" | "video"; name: string }[] = [];
  for (const file of files) {
    const ext = ALLOWED[file.type];
    if (!ext) return jsonError(400, `Недопустимый тип файла: ${file.name}`);
    if (file.size > MAX_SIZE) return jsonError(400, `Файл больше 10 МБ: ${file.name}`);
    const name = `${randomUUID()}${ext}`;
    await writeFile(path.join(dir, name), Buffer.from(await file.arrayBuffer()));
    saved.push({ url: `/uploads/${name}`, kind: file.type.startsWith("video/") ? "video" : "image", name: file.name });
  }
  return NextResponse.json({ files: saved }, { status: 201 });
}
