import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getSessionUser, hasRole } from "@/lib/auth";
import { jsonError, readJson, zodDetails } from "@/lib/api";
import { syncBadges } from "@/lib/listing-service";

const actionSchema = z.object({
  action: z.enum(["approve", "reject", "approve_original", "reject_original"]),
  comment: z.string().max(500).optional(),
});

// POST /api/admin/listings/[id] — модерация объявления и проверки оригинальности
export async function POST(req: Request, { params }: { params: { id: string } }) {
  const user = await getSessionUser();
  if (!hasRole(user, "admin")) return jsonError(403, "Только для администратора");

  const parsed = actionSchema.safeParse(await readJson(req));
  if (!parsed.success) return jsonError(400, "Некорректный запрос", zodDetails(parsed.error));
  const { action, comment } = parsed.data;

  const listing = await prisma.listing.findUnique({ where: { id: params.id } });
  if (!listing) return jsonError(404, "Объявление не найдено");

  await prisma.$transaction(async (tx) => {
    switch (action) {
      case "approve":
        await tx.listing.update({
          where: { id: listing.id },
          data: { status: "active", publishedAt: listing.publishedAt ?? new Date() },
        });
        break;
      case "reject":
        await tx.listing.update({ where: { id: listing.id }, data: { status: "rejected" } });
        break;
      case "approve_original":
        await tx.listing.update({ where: { id: listing.id }, data: { originalVerified: true } });
        break;
      case "reject_original":
        await tx.listing.update({ where: { id: listing.id }, data: { originalVerified: false, isOriginal: false } });
        break;
    }
    await syncBadges(tx, listing.id);
    await tx.moderationLog.create({
      data: {
        listingId: listing.id,
        actorId: user.id,
        action:
          action === "approve"
            ? "approved"
            : action === "reject"
              ? "rejected"
              : action === "approve_original"
                ? "verification_approved"
                : "verification_rejected",
        comment: comment ?? null,
      },
    });
  });
  return NextResponse.json({ ok: true });
}
