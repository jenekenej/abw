import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getSessionUser, hasRole } from "@/lib/auth";
import { jsonError, readJson, zodDetails } from "@/lib/api";

const actionSchema = z.object({ action: z.enum(["approve", "reject"]), comment: z.string().max(500).optional() });

// POST /api/admin/sellers/[id] — решение по заявке на верификацию продавца
export async function POST(req: Request, { params }: { params: { id: string } }) {
  const user = await getSessionUser();
  if (!hasRole(user, "admin")) return jsonError(403, "Только для администратора");

  const parsed = actionSchema.safeParse(await readJson(req));
  if (!parsed.success) return jsonError(400, "Некорректный запрос", zodDetails(parsed.error));
  const approve = parsed.data.action === "approve";

  const seller = await prisma.seller.findUnique({ where: { id: params.id } });
  if (!seller) return jsonError(404, "Продавец не найден");

  await prisma.$transaction([
    prisma.seller.update({
      where: { id: seller.id },
      data: { verificationStatus: approve ? "approved" : "rejected", verified: approve },
    }),
    prisma.moderationLog.create({
      data: {
        sellerId: seller.id,
        actorId: user.id,
        action: approve ? "verification_approved" : "verification_rejected",
        comment: parsed.data.comment ?? null,
      },
    }),
  ]);
  return NextResponse.json({ ok: true });
}
