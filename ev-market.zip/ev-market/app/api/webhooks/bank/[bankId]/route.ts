import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { jsonError, readJson, zodDetails } from "@/lib/api";

// Формат уведомления от банка (заглушка — реальный формат согласуется с банком)
const webhookSchema = z.object({
  applicationId: z.string().min(1),
  externalId: z.string().optional(),
  status: z.enum(["sent", "approved", "rejected"]),
});

// POST /api/webhooks/bank/[bankId] — банк сообщает о смене статуса заявки.
// Подпись проверяется упрощённо: заголовок X-Bank-Secret должен совпадать с BANK_WEBHOOK_SECRET.
// В проде — HMAC-подпись тела запроса и проверка IP банка.
export async function POST(req: Request, { params }: { params: { bankId: string } }) {
  const secret = process.env.BANK_WEBHOOK_SECRET;
  if (!secret || req.headers.get("x-bank-secret") !== secret) return jsonError(401, "Неверная подпись");

  const parsed = webhookSchema.safeParse(await readJson(req));
  if (!parsed.success) return jsonError(400, "Некорректное тело", zodDetails(parsed.error));

  const bank = await prisma.bank.findFirst({ where: { OR: [{ id: params.bankId }, { code: params.bankId }] } });
  if (!bank) return jsonError(404, "Банк не найден");

  const app = await prisma.installmentApplication.findFirst({
    where: { id: parsed.data.applicationId, bankId: bank.id },
  });
  if (!app) return jsonError(404, "Заявка не найдена");

  const updated = await prisma.installmentApplication.update({
    where: { id: app.id },
    data: { status: parsed.data.status, externalId: parsed.data.externalId ?? app.externalId },
  });
  return NextResponse.json({ ok: true, id: updated.id, status: updated.status });
}
