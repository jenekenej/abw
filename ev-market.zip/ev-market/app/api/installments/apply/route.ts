import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { getSessionUser } from "@/lib/auth";
import { jsonError, readJson, zodDetails } from "@/lib/api";
import { installmentApplySchema } from "@/lib/validation";
import { calcInstallment } from "@/lib/installment";

// POST /api/installments/apply — заявка на рассрочку.
// В MVP заявка только сохраняется со статусом `created`; отправка в банк — заглушка.
export async function POST(req: Request) {
  const parsed = installmentApplySchema.safeParse(await readJson(req));
  if (!parsed.success) return jsonError(400, "Проверьте поля формы", zodDetails(parsed.error));
  const input = parsed.data;

  const offer = await prisma.installmentOffer.findUnique({
    where: { listingId_bankId: { listingId: input.listingId, bankId: input.bankId } },
    include: { listing: { select: { priceByn: true, status: true } } },
  });
  if (!offer || offer.listing.status !== "active") return jsonError(404, "Предложение рассрочки не найдено");
  if (!offer.terms.includes(input.termMonths)) return jsonError(400, "Банк не предоставляет такой срок");
  if (input.downPercent < offer.minDownPercent) {
    return jsonError(400, `Минимальный первоначальный взнос — ${offer.minDownPercent}%`);
  }

  // Пересчитываем на сервере, не доверяя клиенту
  const price = offer.listing.priceByn.toNumber();
  const downPayment = Math.round(price * input.downPercent) / 100;
  const { monthlyPayment } = calcInstallment({ price, downPayment, rate: offer.rate, termMonths: input.termMonths });

  const user = await getSessionUser();
  const application = await prisma.installmentApplication.create({
    data: {
      listingId: input.listingId,
      bankId: input.bankId,
      userId: user?.id ?? null,
      fullName: input.fullName,
      phone: input.phone,
      price: new Prisma.Decimal(price),
      downPayment: new Prisma.Decimal(downPayment),
      termMonths: input.termMonths,
      rate: offer.rate,
      monthlyPayment: new Prisma.Decimal(monthlyPayment),
      status: "created",
    },
  });

  // TODO(интеграция): здесь отправляем заявку в API банка и сохраняем externalId.
  return NextResponse.json(
    { id: application.id, status: application.status, monthlyPayment, message: "Заявка отправлена в банк-партнёр" },
    { status: 201 },
  );
}
