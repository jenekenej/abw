// DTO, которыми обмениваются API и UI. Decimal из Prisma приводится к number,
// даты — к ISO-строкам, чтобы данные можно было безопасно сериализовать в JSON.

import type { ConditionValue } from "@/lib/constants";

/** Значение динамической характеристики. */
export type AttrValue = string | number | boolean;
export type ListingAttrs = Record<string, AttrValue>;

export interface BadgeDTO {
  code: string;
  name: string;
  color: string;
}

export interface ListingCardDTO {
  id: string;
  title: string;
  priceByn: number;
  oldPriceByn: number | null;
  city: string;
  condition: ConditionValue;
  isOriginal: boolean;
  originalVerified: boolean;
  hasInstallment: boolean;
  imageUrl: string | null;
  createdAt: string;
  attrs: ListingAttrs;
  categorySlug: string;
  categoryName: string;
  badges: BadgeDTO[];
  status: string;
  views: number;
}

export interface AttributeDefinitionDTO {
  code: string;
  name: string;
  type: "int" | "float" | "enum" | "bool";
  unit: string | null;
  options: string[];
}

export interface CategoryDTO {
  id: string;
  slug: string;
  name: string;
  isVehicle: boolean;
  children: { id: string; slug: string; name: string }[];
  attributes: AttributeDefinitionDTO[];
}

export interface InstallmentOfferDTO {
  bankId: string;
  bankName: string;
  rate: number;
  terms: number[];
  minDownPercent: number;
}

export interface SellerPublicDTO {
  id: string;
  displayName: string;
  type: "individual" | "dealer";
  city: string;
  rating: number;
  ratingCount: number;
  verified: boolean;
  activeListings: number;
  createdAt: string;
}

export interface ListingDetailDTO extends ListingCardDTO {
  description: string;
  currency: "BYN" | "USD";
  price: number;
  discountReason: string | null;
  media: { id: string; url: string; kind: string }[];
  category: { id: string; slug: string; name: string };
  subcategory: { id: string; slug: string; name: string } | null;
  attributeDefinitions: AttributeDefinitionDTO[];
  serialNumber: string | null;
  vin: string | null;
  certificateUrl: string | null;
  installmentOffers: InstallmentOfferDTO[];
  seller: SellerPublicDTO;
  updatedAt: string;
}

export interface ListingsResponse {
  items: ListingCardDTO[];
  total: number;
  page: number;
  pageSize: number;
}

export interface RangeBucketCount {
  key: string;
  label: string;
  min: number | null;
  max: number | null;
  count: number;
}

/** Ответ GET /api/listings/facets — счётчики для каждого фильтра. */
export interface FacetsResponse {
  total: number;
  price: { min: number; max: number };
  condition: Record<string, number>;
  city: Record<string, number>;
  isOriginal: number;
  hasInstallment: number;
  motorPower: RangeBucketCount[];
  battery: RangeBucketCount[];
  speed: RangeBucketCount[];
  batteryType: Record<string, number>;
  noLicense: number;
  hasEpts: number;
  pedals: number;
}

export interface ApiError {
  error: string;
  details?: unknown;
}
