// Расширение типов NextAuth: добавляем id, роль и sellerId пользователя.
import type { DefaultSession } from "next-auth";
import type { UserRole } from "@prisma/client";

declare module "next-auth" {
  interface User {
    id: string;
    role: UserRole;
    sellerId: string | null;
  }
  interface Session {
    user: {
      id: string;
      role: UserRole;
      sellerId: string | null;
    } & DefaultSession["user"];
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    id: string;
    role: UserRole;
    sellerId: string | null;
  }
}
