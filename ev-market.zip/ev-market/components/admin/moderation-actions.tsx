"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

async function post(url: string, body: Record<string, string>): Promise<boolean> {
  const res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  return res.ok;
}

function Actions({ onDecide }: { onDecide: (approve: boolean, comment: string) => Promise<boolean> }) {
  const router = useRouter();
  const [comment, setComment] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(false);

  const decide = async (approve: boolean) => {
    setBusy(true);
    setError(false);
    const ok = await onDecide(approve, comment);
    setBusy(false);
    if (ok) router.refresh();
    else setError(true);
  };

  return (
    <div className="flex shrink-0 flex-col gap-2 sm:flex-row sm:items-center">
      <Input value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Комментарий" className="h-9 sm:w-44" />
      <div className="flex gap-2">
        <Button size="sm" disabled={busy} onClick={() => decide(true)}><Check className="h-4 w-4" /> Одобрить</Button>
        <Button size="sm" variant="destructive" disabled={busy} onClick={() => decide(false)}><X className="h-4 w-4" /> Отклонить</Button>
      </div>
      {error && <span className="text-xs text-destructive">Ошибка</span>}
    </div>
  );
}

/** Одобрение/отклонение объявления или проверки оригинальности. */
export function ModerationActions({ listingId, kind }: { listingId: string; kind: "listing" | "original" }) {
  return (
    <Actions
      onDecide={(approve, comment) =>
        post(`/api/admin/listings/${listingId}`, {
          action: kind === "listing" ? (approve ? "approve" : "reject") : approve ? "approve_original" : "reject_original",
          ...(comment ? { comment } : {}),
        })
      }
    />
  );
}

/** Решение по верификации продавца. */
export function SellerVerificationActions({ sellerId }: { sellerId: string }) {
  return (
    <Actions
      onDecide={(approve, comment) =>
        post(`/api/admin/sellers/${sellerId}`, { action: approve ? "approve" : "reject", ...(comment ? { comment } : {}) })
      }
    />
  );
}
