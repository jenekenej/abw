"use client";

import { useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination, Thumbs } from "swiper/modules";
import type { Swiper as SwiperType } from "swiper";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/thumbs";
import { PlayCircle } from "lucide-react";

interface GalleryProps {
  media: { id: string; url: string; kind: string }[];
  title: string;
}

/** Галерея фото и видео на Swiper с миниатюрами. */
export function Gallery({ media, title }: GalleryProps) {
  const [thumbs, setThumbs] = useState<SwiperType | null>(null);

  if (media.length === 0) {
    return (
      <div className="flex aspect-[4/3] items-center justify-center rounded-lg border bg-muted text-muted-foreground">
        Фото не загружены
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <Swiper
        modules={[Navigation, Pagination, Thumbs]}
        navigation
        pagination={{ clickable: true }}
        thumbs={{ swiper: thumbs && !thumbs.destroyed ? thumbs : null }}
        className="aspect-[4/3] overflow-hidden rounded-lg bg-muted"
      >
        {media.map((m, i) => (
          <SwiperSlide key={m.id}>
            {m.kind === "video" ? (
              <video src={m.url} controls className="h-full w-full bg-black object-contain" />
            ) : (
              <img src={m.url} alt={`${title} — фото ${i + 1}`} className="h-full w-full object-cover" />
            )}
          </SwiperSlide>
        ))}
      </Swiper>
      {media.length > 1 && (
        <Swiper modules={[Thumbs]} onSwiper={setThumbs} slidesPerView={5} spaceBetween={8} watchSlidesProgress>
          {media.map((m) => (
            <SwiperSlide key={m.id} className="cursor-pointer overflow-hidden rounded-md opacity-70 [&.swiper-slide-thumb-active]:opacity-100 [&.swiper-slide-thumb-active]:ring-2 [&.swiper-slide-thumb-active]:ring-primary">
              {m.kind === "video" ? (
                <div className="flex aspect-[4/3] items-center justify-center bg-black text-white">
                  <PlayCircle className="h-6 w-6" />
                </div>
              ) : (
                <img src={m.url} alt="" className="aspect-[4/3] w-full object-cover" />
              )}
            </SwiperSlide>
          ))}
        </Swiper>
      )}
    </div>
  );
}
