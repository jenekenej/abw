import Link from "next/link";
import { BatteryCharging, Gauge, MapPin, Zap } from "lucide-react";
import { Price } from "@/components/price";
import { Skeleton } from "@/components/ui/skeleton";
import { ConditionBadge, ListingBadges } from "./listing-badges";
import type { ListingCardDTO } from "@/types";

/** Карточка объявления в сетке каталога. */
export function ListingCard({ listing }: { listing: ListingCardDTO }) {
  const { attrs } = listing;
  const specs: { icon: typeof Zap; text: string }[] = [];
  if (typeof attrs.motor_power_w === "number") specs.push({ icon: Zap, text: `${attrs.motor_power_w} Вт` });
  if (typeof attrs.battery_capacity_ah === "number")
    specs.push({ icon: BatteryCharging, text: `${attrs.battery_capacity_ah} А·ч` });
  if (typeof attrs.max_speed_kmh === "number") specs.push({ icon: Gauge, text: `${attrs.max_speed_kmh} км/ч` });

  // Бейдж «Новинка/Уценка» дублирует метку состояния — в карточке показываем только «Оригинал»/«Рассрочка»
  const extraBadges = listing.badges.filter((b) => b.code === "original" || b.code === "installment");

  return (
    <Link
      href={`/listing/${listing.id}`}
      className="group flex flex-col overflow-hidden rounded-lg border bg-card shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
    >
      <div className="relative aspect-[4/3] overflow-hidden bg-muted">
        {listing.imageUrl ? (
          <img
            src={listing.imageUrl}
            alt={listing.title}
            loading="lazy"
            className="h-full w-full object-cover transition group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full items-center justify-center text-muted-foreground">Нет фото</div>
        )}
        <div className="absolute left-2 top-2">
          <ConditionBadge condition={listing.condition} />
        </div>
      </div>
      <div className="flex flex-1 flex-col gap-2 p-4">
        <div className="flex items-baseline gap-2">
          <Price byn={listing.priceByn} className="text-xl font-bold" />
          {listing.oldPriceByn && (
            <Price byn={listing.oldPriceByn} className="text-sm text-muted-foreground line-through" />
          )}
        </div>
        <h3 className="line-clamp-2 font-medium leading-snug group-hover:text-primary">{listing.title}</h3>
        {specs.length > 0 && (
          <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
            {specs.map(({ icon: Icon, text }) => (
              <span key={text} className="inline-flex items-center gap-1">
                <Icon className="h-3.5 w-3.5" />
                {text}
              </span>
            ))}
          </div>
        )}
        <ListingBadges badges={extraBadges} />
        <div className="mt-auto flex items-center gap-1 pt-1 text-xs text-muted-foreground">
          <MapPin className="h-3.5 w-3.5" />
          {listing.city} · {listing.categoryName}
        </div>
      </div>
    </Link>
  );
}

export function ListingCardSkeleton() {
  return (
    <div className="overflow-hidden rounded-lg border bg-card">
      <Skeleton className="aspect-[4/3] rounded-none" />
      <div className="space-y-2 p-4">
        <Skeleton className="h-6 w-1/2" />
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-2/3" />
      </div>
    </div>
  );
}
