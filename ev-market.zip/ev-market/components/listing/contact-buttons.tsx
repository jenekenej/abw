"use client";

import { useState } from "react";
import { MessageCircle, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";

/** «Показать телефон» и «Написать в чат» (чат — заглушка). */
export function ContactButtons({ phone }: { phone: string }) {
  const [shown, setShown] = useState(false);
  const [chatNotice, setChatNotice] = useState(false);
  const masked = phone.length > 6 ? `${phone.slice(0, 7)} XXX-XX-XX` : "Показать телефон";
  const pretty = phone.replace(/^(\+375)(\d{2})(\d{3})(\d{2})(\d{2})$/, "$1 ($2) $3-$4-$5");

  return (
    <div className="space-y-2">
      {shown ? (
        <Button asChild size="lg" className="w-full">
          <a href={`tel:${phone}`}>
            <Phone className="h-4 w-4" /> {pretty}
          </a>
        </Button>
      ) : (
        <Button size="lg" className="w-full" onClick={() => setShown(true)}>
          <Phone className="h-4 w-4" /> Показать телефон
          <span className="font-normal opacity-75">{masked}</span>
        </Button>
      )}
      <Button size="lg" variant="outline" className="w-full" onClick={() => setChatNotice(true)}>
        <MessageCircle className="h-4 w-4" /> Написать в чат
      </Button>
      {chatNotice && <p className="text-center text-xs text-muted-foreground">Чат появится в следующей версии — пока свяжитесь по телефону.</p>}
    </div>
  );
}
