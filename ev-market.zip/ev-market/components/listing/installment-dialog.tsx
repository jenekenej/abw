"use client";

import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { CheckCircle2, CreditCard, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Field } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { calcInstallment } from "@/lib/installment";
import { installmentApplySchema } from "@/lib/validation";
import { INSTALLMENT_TERMS } from "@/lib/constants";
import { cn, formatPrice } from "@/lib/utils";
import type { InstallmentOfferDTO } from "@/types";

// Схема формы — только контактные поля; банк/срок/взнос управляются отдельно
const contactSchema = installmentApplySchema.pick({ fullName: true, phone: true });
type ContactForm = { fullName: string; phone: string };

interface ApplyResponse {
  id: string;
  status: string;
  monthlyPayment: number;
  message: string;
}

interface Props {
  listingId: string;
  priceByn: number;
  offers: InstallmentOfferDTO[];
}

/** Кнопка «Купить в рассрочку» + модалка с кредитным калькулятором. */
export function InstallmentDialog({ listingId, priceByn, offers }: Props) {
  const [open, setOpen] = useState(false);
  const [bankId, setBankId] = useState(offers[0]?.bankId ?? "");
  const offer = offers.find((o) => o.bankId === bankId) ?? offers[0];
  const [term, setTerm] = useState<number>(offer?.terms.at(-1) ?? 12);
  const [downPercent, setDownPercent] = useState<number>(offer?.minDownPercent ?? 0);

  // При смене банка подгоняем срок и взнос под его условия
  useEffect(() => {
    if (!offer) return;
    if (!offer.terms.includes(term)) setTerm(offer.terms.at(-1) ?? 12);
    if (downPercent < offer.minDownPercent) setDownPercent(offer.minDownPercent);
  }, [offer, term, downPercent]);

  const downPayment = Math.round(priceByn * downPercent) / 100;
  const calc = useMemo(
    () => calcInstallment({ price: priceByn, downPayment, rate: offer?.rate ?? 0, termMonths: term }),
    [priceByn, downPayment, offer?.rate, term],
  );

  const form = useForm<ContactForm>({ resolver: zodResolver(contactSchema), defaultValues: { fullName: "", phone: "+375" } });

  const mutation = useMutation({
    mutationFn: async (contact: ContactForm): Promise<ApplyResponse> => {
      const res = await fetch("/api/installments/apply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ listingId, bankId, termMonths: term, downPercent, ...contact }),
      });
      const body: unknown = await res.json();
      if (!res.ok) {
        const msg = typeof body === "object" && body !== null && "error" in body ? String(body.error) : "Ошибка";
        throw new Error(msg);
      }
      return body as ApplyResponse;
    },
  });

  if (!offer) return null;

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        setOpen(v);
        if (!v) mutation.reset();
      }}
    >
      <DialogTrigger asChild>
        <Button size="lg" variant="installment" className="w-full">
          <CreditCard className="h-4 w-4" /> Купить в рассрочку
        </Button>
      </DialogTrigger>
      <DialogContent>
        {mutation.isSuccess ? (
          <div className="py-6 text-center">
            <CheckCircle2 className="mx-auto h-14 w-14 text-tag-new" />
            <DialogTitle className="mt-3">Заявка отправлена в банк-партнёр</DialogTitle>
            <DialogDescription className="mt-2">
              {offer.bankName} свяжется с вами в течение рабочего дня. Номер заявки: {mutation.data.id.slice(-8).toUpperCase()}.
            </DialogDescription>
            <Button className="mt-6" onClick={() => setOpen(false)}>Понятно</Button>
          </div>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle>Покупка в рассрочку</DialogTitle>
              <DialogDescription>Стоимость товара: {formatPrice(priceByn)}</DialogDescription>
            </DialogHeader>

            {/* Выбор банка */}
            <div className="space-y-2">
              <p className="text-sm font-medium">Банк</p>
              <div className="grid gap-2">
                {offers.map((o) => (
                  <button
                    key={o.bankId}
                    type="button"
                    onClick={() => setBankId(o.bankId)}
                    className={cn(
                      "flex items-center justify-between rounded-md border p-3 text-left text-sm",
                      o.bankId === bankId ? "border-tag-installment bg-tag-installment/10" : "hover:border-tag-installment/60",
                    )}
                  >
                    <span className="font-medium">{o.bankName}</span>
                    <span className="text-muted-foreground">
                      {o.rate === 0 ? "0% — без переплаты" : `${Math.round(o.rate * 100)}% годовых`}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Срок */}
            <div className="space-y-2">
              <p className="text-sm font-medium">Срок</p>
              <div className="grid grid-cols-4 gap-2">
                {INSTALLMENT_TERMS.map((t) => {
                  const available = offer.terms.includes(t);
                  return (
                    <Button
                      key={t}
                      type="button"
                      size="sm"
                      variant={t === term ? "installment" : "outline"}
                      disabled={!available}
                      onClick={() => setTerm(t)}
                    >
                      {t} мес.
                    </Button>
                  );
                })}
              </div>
            </div>

            {/* Первоначальный взнос */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="font-medium">Первоначальный взнос</span>
                <span>{downPercent}% · {formatPrice(downPayment)}</span>
              </div>
              <Slider
                min={0}
                max={50}
                step={5}
                value={[downPercent]}
                onValueChange={([v = 0]) => setDownPercent(Math.max(v, offer.minDownPercent))}
              />
              {offer.minDownPercent > 0 && (
                <p className="text-xs text-muted-foreground">Минимальный взнос в этом банке — {offer.minDownPercent}%</p>
              )}
            </div>

            {/* Итог расчёта */}
            <div className="rounded-lg bg-tag-installment/10 p-4">
              <div className="flex items-baseline justify-between">
                <span className="text-sm">Ежемесячный платёж</span>
                <span className="text-2xl font-bold text-tag-installment">{formatPrice(calc.monthlyPayment)}</span>
              </div>
              <div className="mt-1 flex justify-between text-xs text-muted-foreground">
                <span>Переплата: {formatPrice(calc.overpayment)}</span>
                <span>Итого: {formatPrice(calc.totalPayment)}</span>
              </div>
            </div>

            {/* Контакты */}
            <form onSubmit={form.handleSubmit((v) => mutation.mutate(v))} className="space-y-3">
              <Field label="ФИО" htmlFor="fullName" error={form.formState.errors.fullName?.message}>
                <Input id="fullName" autoComplete="name" {...form.register("fullName")} />
              </Field>
              <Field label="Телефон" htmlFor="phone" error={form.formState.errors.phone?.message}>
                <Input id="phone" type="tel" autoComplete="tel" {...form.register("phone")} />
              </Field>
              {mutation.isError && <p className="text-sm text-destructive">{mutation.error.message}</p>}
              <Button type="submit" variant="installment" size="lg" className="w-full" disabled={mutation.isPending}>
                {mutation.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
                Отправить заявку
              </Button>
              <p className="text-center text-xs text-muted-foreground">
                Расчёт предварительный. Окончательные условия определяет банк.
              </p>
            </form>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
