import { BadgeCheck, CreditCard, Sparkles, Tag } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { CONDITION_LABELS, type ConditionValue } from "@/lib/constants";
import type { BadgeDTO } from "@/types";

type BadgeVariant = "original" | "installment" | "new" | "discounted";

const ICONS: Record<BadgeVariant, typeof Tag> = {
  original: BadgeCheck,
  installment: CreditCard,
  new: Sparkles,
  discounted: Tag,
};

function isVariant(code: string): code is BadgeVariant {
  return code in ICONS;
}

/** Бейджи объявления: «Оригинал», «Рассрочка», «Новинка», «Уценка». */
export function ListingBadges({ badges, className }: { badges: BadgeDTO[]; className?: string }) {
  if (!badges.length) return null;
  return (
    <div className={className ?? "flex flex-wrap gap-1.5"}>
      {badges.filter((b) => isVariant(b.code)).map((b) => {
        const variant = b.code as BadgeVariant;
        const Icon = ICONS[variant];
        return (
          <Badge key={b.code} variant={variant}>
            <Icon className="h-3 w-3" />
            {b.name}
          </Badge>
        );
      })}
    </div>
  );
}

/** Метка состояния: Новый — зелёный, Б/У — серый, Уценка — оранжевый. */
export function ConditionBadge({ condition }: { condition: ConditionValue }) {
  return <Badge variant={condition}>{CONDITION_LABELS[condition]}</Badge>;
}
