"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { signOut, useSession } from "next-auth/react";
import { LogOut, Moon, Plus, Search, Shield, Sun, User, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useCurrencyStore } from "@/lib/store/currency";
import { useDisplayCurrency } from "@/components/price";

export function Header() {
  const { data: session } = useSession();
  const router = useRouter();
  const [q, setQ] = useState("");
  const currency = useDisplayCurrency();
  const setCurrency = useCurrencyStore((s) => s.setCurrency);

  const onSearch = (e: FormEvent) => {
    e.preventDefault();
    router.push(q.trim() ? `/catalog?q=${encodeURIComponent(q.trim())}` : "/catalog");
  };

  const toggleTheme = () => {
    const isDark = document.documentElement.classList.toggle("dark");
    try {
      localStorage.setItem("ev-theme", isDark ? "dark" : "light");
    } catch {
      // localStorage может быть недоступен — тема просто не сохранится
    }
  };

  const role = session?.user.role;

  return (
    <header className="sticky top-0 z-40 border-b bg-card/95 backdrop-blur">
      <div className="container flex h-16 items-center gap-3">
        <Link href="/" className="flex shrink-0 items-center gap-1.5 text-lg font-bold">
          <Zap className="h-6 w-6 text-primary" />
          <span className="hidden sm:inline">ЭлектроРынок</span>
        </Link>
        <Link href="/catalog" className="hidden text-sm font-medium hover:text-primary md:inline">
          Каталог
        </Link>

        <form onSubmit={onSearch} className="relative mx-auto flex-1 sm:max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Поиск: Surron, моноколесо…"
            className="pl-9"
            aria-label="Поиск"
          />
        </form>

        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setCurrency(currency === "BYN" ? "USD" : "BYN")}
            title="Валюта отображения цен"
          >
            {currency}
          </Button>
          <Button variant="ghost" size="icon" onClick={toggleTheme} aria-label="Сменить тему">
            <Sun className="h-4 w-4 dark:hidden" />
            <Moon className="hidden h-4 w-4 dark:block" />
          </Button>

          {role === "admin" && (
            <Button asChild variant="ghost" size="sm">
              <Link href="/admin">
                <Shield className="h-4 w-4" />
                <span className="hidden lg:inline">Модерация</span>
              </Link>
            </Button>
          )}
          {role === "seller" && (
            <>
              <Button asChild size="sm" className="hidden sm:inline-flex">
                <Link href="/dashboard/listings/new">
                  <Plus className="h-4 w-4" />
                  Подать объявление
                </Link>
              </Button>
              <Button asChild variant="ghost" size="sm">
                <Link href="/dashboard">
                  <User className="h-4 w-4" />
                  <span className="hidden lg:inline">Кабинет</span>
                </Link>
              </Button>
            </>
          )}
          {session ? (
            <Button variant="ghost" size="icon" onClick={() => signOut({ callbackUrl: "/" })} aria-label="Выйти">
              <LogOut className="h-4 w-4" />
            </Button>
          ) : (
            <Button asChild variant="outline" size="sm">
              <Link href="/login">Войти</Link>
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
