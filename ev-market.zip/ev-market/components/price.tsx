"use client";

import { useEffect, useState } from "react";
import { useCurrencyStore } from "@/lib/store/currency";
import { formatPrice, type DisplayCurrency } from "@/lib/utils";

/** Цена в выбранной пользователем валюте. До гидрации показываем BYN, чтобы не было рассинхрона SSR. */
export function Price({ byn, className }: { byn: number; className?: string }) {
  const currency = useDisplayCurrency();
  return <span className={className}>{formatPrice(byn, currency)}</span>;
}

export function useDisplayCurrency(): DisplayCurrency {
  const stored = useCurrencyStore((s) => s.currency);
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  return mounted ? stored : "BYN";
}
