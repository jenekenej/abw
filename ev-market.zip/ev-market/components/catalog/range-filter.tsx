"use client";

import { useEffect, useState, type KeyboardEvent } from "react";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { cn } from "@/lib/utils";
import type { RangeBucketCount } from "@/types";

interface RangeFilterProps {
  min: number | null;
  max: number | null;
  onChange: (min: number | null, max: number | null) => void;
  /** Границы слайдера; если не заданы — слайдер не показывается (только инпуты/диапазоны). */
  bounds?: { min: number; max: number; step: number };
  /** Предустановленные диапазоны со счётчиками фасетов. */
  presets?: RangeBucketCount[];
  /** Показывать ли поля ввода «от/до». */
  withInputs?: boolean;
  unit?: string;
}

const parseNum = (v: string): number | null => {
  const n = Number(v.replace(/\s/g, "").replace(",", "."));
  return v.trim() !== "" && Number.isFinite(n) && n >= 0 ? n : null;
};

/**
 * Универсальный фильтр диапазона: два инпута + range-слайдер + кнопки-пресеты.
 * Значения применяются по blur/Enter (инпуты) и по отпусканию бегунка (слайдер),
 * чтобы не дёргать API на каждое движение.
 */
export function RangeFilter({ min, max, onChange, bounds, presets, withInputs = true, unit }: RangeFilterProps) {
  const [fromText, setFromText] = useState(min?.toString() ?? "");
  const [toText, setToText] = useState(max?.toString() ?? "");
  const [slider, setSlider] = useState<[number, number]>([min ?? bounds?.min ?? 0, max ?? bounds?.max ?? 0]);

  // Синхронизация локального состояния при внешнем изменении (сброс, переход по ссылке)
  useEffect(() => {
    setFromText(min?.toString() ?? "");
    setToText(max?.toString() ?? "");
    setSlider([min ?? bounds?.min ?? 0, max ?? bounds?.max ?? 0]);
  }, [min, max, bounds?.min, bounds?.max]);

  const commitInputs = () => {
    let from = parseNum(fromText);
    let to = parseNum(toText);
    if (from !== null && to !== null && from > to) [from, to] = [to, from];
    if (from !== min || to !== max) onChange(from, to);
  };

  const onKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") commitInputs();
  };

  return (
    <div className="space-y-3">
      {withInputs && (
        <div className="flex items-center gap-2">
          <Input
            inputMode="numeric"
            placeholder="от"
            value={fromText}
            onChange={(e) => setFromText(e.target.value)}
            onBlur={commitInputs}
            onKeyDown={onKey}
            className="h-9"
            aria-label={`Минимум${unit ? `, ${unit}` : ""}`}
          />
          <span className="text-muted-foreground">—</span>
          <Input
            inputMode="numeric"
            placeholder="до"
            value={toText}
            onChange={(e) => setToText(e.target.value)}
            onBlur={commitInputs}
            onKeyDown={onKey}
            className="h-9"
            aria-label={`Максимум${unit ? `, ${unit}` : ""}`}
          />
          {unit && <span className="shrink-0 text-xs text-muted-foreground">{unit}</span>}
        </div>
      )}

      {bounds && (
        <Slider
          min={bounds.min}
          max={bounds.max}
          step={bounds.step}
          value={slider}
          minStepsBetweenThumbs={1}
          onValueChange={(v) => {
            const [a = bounds.min, b = bounds.max] = v;
            setSlider([a, b]);
            setFromText(a === bounds.min ? "" : String(a));
            setToText(b === bounds.max ? "" : String(b));
          }}
          onValueCommit={(v) => {
            const [a = bounds.min, b = bounds.max] = v;
            // Крайние положения бегунков = «без ограничения»
            onChange(a === bounds.min ? null : a, b === bounds.max ? null : b);
          }}
        />
      )}

      {presets && presets.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {presets.map((p) => {
            const active = p.min === min && p.max === max;
            const disabled = p.count === 0 && !active;
            return (
              <button
                key={p.key}
                type="button"
                disabled={disabled}
                onClick={() => (active ? onChange(null, null) : onChange(p.min, p.max))}
                className={cn(
                  "rounded-full border px-2.5 py-1 text-xs transition-colors",
                  active ? "border-primary bg-primary text-primary-foreground" : "hover:border-primary",
                  disabled && "cursor-not-allowed opacity-40",
                )}
                aria-pressed={active}
              >
                {p.label}
                <span className={cn("ml-1", active ? "opacity-80" : "text-muted-foreground")}>{p.count}</span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
