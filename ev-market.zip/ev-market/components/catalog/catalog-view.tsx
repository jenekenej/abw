"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, SearchX, SlidersHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { NativeSelect } from "@/components/ui/input";
import { Dialog, DialogTitle, DialogTrigger, SheetContent } from "@/components/ui/dialog";
import { ListingCard, ListingCardSkeleton } from "@/components/listing/listing-card";
import { FiltersPanel } from "./filters-panel";
import { useFiltersStore } from "@/lib/store/filters";
import { countActiveFilters, filtersToSearchParams, parseFilters, type ListingFilters } from "@/lib/filters";
import { SORT_OPTIONS, type SortValue } from "@/lib/constants";
import { cn, plural } from "@/lib/utils";
import type { CategoryDTO, FacetsResponse, ListingsResponse } from "@/types";

interface CatalogViewProps {
  categories: CategoryDTO[];
  categorySlug?: string;
  subSlug?: string;
}

async function fetchJson<T>(url: string): Promise<T> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Ошибка загрузки: ${res.status}`);
  return (await res.json()) as T;
}

/** Канонический вид фильтров для сравнения «URL ↔ стор». */
const canonical = (f: ListingFilters): string => filtersToSearchParams(f, true).toString();

export function CatalogView({ categories, categorySlug, subSlug }: CatalogViewProps) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const { filters, replace, setFilters, reset } = useFiltersStore();
  const [hydrated, setHydrated] = useState(false);
  const [sheetOpen, setSheetOpen] = useState(false);

  const category = categories.find((c) => c.slug === categorySlug) ?? null;
  const subcategory = category?.children.find((c) => c.slug === subSlug) ?? null;

  // 1) URL → стор: при первой загрузке и навигации «назад/вперёд»
  useEffect(() => {
    const fromUrl: ListingFilters = {
      ...parseFilters(searchParams),
      category: categorySlug ?? null,
      sub: subSlug ?? null,
    };
    if (canonical(fromUrl) !== canonical(useFiltersStore.getState().filters)) replace(fromUrl);
    setHydrated(true);
  }, [searchParams, categorySlug, subSlug, replace]);

  // 2) Стор → URL: после действий пользователя. Используем router.replace, чтобы не засорять историю.
  useEffect(() => {
    if (!hydrated) return;
    const current = useFiltersStore.getState().filters;
    const qs = filtersToSearchParams(current, false).toString();
    if (qs === searchParams.toString()) return;
    router.replace(qs ? `${pathname}?${qs}` : pathname, { scroll: false });
  }, [filters, hydrated, pathname, router, searchParams]);

  // Строка запроса для API: category/sub передаём явно
  const listingsQs = canonical(filters);
  const facetsQs = useMemo(
    () => filtersToSearchParams({ ...filters, sort: "date", page: 1 }, true).toString(),
    [filters],
  );

  const listingsQuery = useQuery({
    queryKey: ["listings", listingsQs],
    queryFn: () => fetchJson<ListingsResponse>(`/api/listings?${listingsQs}`),
    enabled: hydrated,
    placeholderData: keepPreviousData,
  });
  const facetsQuery = useQuery({
    queryKey: ["facets", facetsQs],
    queryFn: () => fetchJson<FacetsResponse>(`/api/listings/facets?${facetsQs}`),
    enabled: hydrated,
    placeholderData: keepPreviousData,
  });

  const data = listingsQuery.data;
  const total = data?.total ?? 0;
  const totalPages = data ? Math.max(1, Math.ceil(data.total / data.pageSize)) : 1;
  const activeCount = countActiveFilters(filters);
  const title = subcategory?.name ?? category?.name ?? (filters.q ? `Поиск: «${filters.q}»` : "Все объявления");

  const goToPage = (page: number) => {
    setFilters({ page });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="container py-6">
      {/* Хлебные крошки */}
      <nav className="mb-2 text-sm text-muted-foreground">
        <Link href="/" className="hover:text-foreground">Главная</Link>
        {" / "}
        <Link href="/catalog" className="hover:text-foreground">Каталог</Link>
        {category && (
          <>
            {" / "}
            <Link href={`/catalog/${category.slug}`} className="hover:text-foreground">{category.name}</Link>
          </>
        )}
        {subcategory && <> / {subcategory.name}</>}
      </nav>

      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold md:text-3xl">{title}</h1>
          <p className="text-sm text-muted-foreground">
            {data ? `${total} ${plural(total, ["объявление", "объявления", "объявлений"])}` : "Загрузка…"}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {/* Мобильная кнопка фильтров → bottom-sheet */}
          <Dialog open={sheetOpen} onOpenChange={setSheetOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="lg:hidden">
                <SlidersHorizontal className="h-4 w-4" />
                Фильтры{activeCount > 0 ? ` (${activeCount})` : ""}
              </Button>
            </DialogTrigger>
            <SheetContent aria-describedby={undefined}>
              <DialogTitle className="sr-only">Фильтры</DialogTitle>
              <div className="flex-1 overflow-y-auto px-4">
                <FiltersPanel category={category} facets={facetsQuery.data} />
              </div>
              <div className="border-t p-4">
                <Button className="w-full" onClick={() => setSheetOpen(false)}>
                  Показать {facetsQuery.data?.total ?? total} {plural(facetsQuery.data?.total ?? total, ["объявление", "объявления", "объявлений"])}
                </Button>
              </div>
            </SheetContent>
          </Dialog>

          <NativeSelect
            value={filters.sort}
            onChange={(e) => setFilters({ sort: e.target.value as SortValue })}
            className="w-auto"
            aria-label="Сортировка"
          >
            {SORT_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </NativeSelect>
        </div>
      </div>

      {/* Подкатегории */}
      {category && category.children.length > 0 && (
        <div className="mb-4 flex flex-wrap gap-2">
          <Link
            href={`/catalog/${category.slug}`}
            className={cn("rounded-full border px-3 py-1 text-sm", !subcategory && "border-primary bg-accent text-accent-foreground")}
          >
            Все
          </Link>
          {category.children.map((s) => (
            <Link
              key={s.id}
              href={`/catalog/${category.slug}/${s.slug}`}
              className={cn(
                "rounded-full border px-3 py-1 text-sm hover:border-primary",
                subcategory?.id === s.id && "border-primary bg-accent text-accent-foreground",
              )}
            >
              {s.name}
            </Link>
          ))}
        </div>
      )}

      <div className="flex gap-6">
        {/* Левая колонка: фиксирована и скроллится независимо */}
        <aside className="scrollbar-thin hidden w-72 shrink-0 lg:sticky lg:top-20 lg:block lg:max-h-[calc(100vh-6rem)] lg:overflow-y-auto lg:pr-2">
          <div className="rounded-lg border bg-card p-4">
            <FiltersPanel category={category} facets={facetsQuery.data} />
          </div>
        </aside>

        <section className="min-w-0 flex-1">
          {!hydrated || (listingsQuery.isPending && !data) ? (
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {Array.from({ length: 6 }, (_, i) => <ListingCardSkeleton key={i} />)}
            </div>
          ) : listingsQuery.isError ? (
            <div className="rounded-lg border bg-card p-10 text-center">
              <p className="font-medium">Не удалось загрузить объявления</p>
              <Button className="mt-4" variant="outline" onClick={() => listingsQuery.refetch()}>Повторить</Button>
            </div>
          ) : data && data.items.length === 0 ? (
            <EmptyState hasFilters={activeCount > 0 || Boolean(filters.q)} onReset={reset} />
          ) : (
            <>
              <div
                className={cn(
                  "grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3 transition-opacity",
                  listingsQuery.isFetching && "opacity-60",
                )}
              >
                {data?.items.map((l) => <ListingCard key={l.id} listing={l} />)}
              </div>
              {totalPages > 1 && (
                <div className="mt-8 flex items-center justify-center gap-1">
                  <Button variant="outline" size="icon" disabled={filters.page <= 1} onClick={() => goToPage(filters.page - 1)} aria-label="Назад">
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                    <Button key={p} variant={p === filters.page ? "default" : "outline"} size="icon" onClick={() => goToPage(p)}>
                      {p}
                    </Button>
                  ))}
                  <Button variant="outline" size="icon" disabled={filters.page >= totalPages} onClick={() => goToPage(filters.page + 1)} aria-label="Вперёд">
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </>
          )}
        </section>
      </div>
    </div>
  );
}

function EmptyState({ hasFilters, onReset }: { hasFilters: boolean; onReset: () => void }) {
  return (
    <div className="rounded-lg border border-dashed bg-card p-10 text-center">
      <SearchX className="mx-auto h-12 w-12 text-muted-foreground" />
      <h2 className="mt-3 text-lg font-semibold">Ничего не найдено</h2>
      <ul className="mx-auto mt-2 max-w-sm space-y-1 text-sm text-muted-foreground">
        <li>• Расширьте диапазон цены или мощности</li>
        <li>• Уберите часть городов или вариантов состояния</li>
        <li>• Посмотрите соседние категории в каталоге</li>
      </ul>
      <div className="mt-5 flex justify-center gap-2">
        {hasFilters && <Button onClick={onReset}>Сбросить фильтры</Button>}
        <Button asChild variant="outline">
          <Link href="/catalog">Все объявления</Link>
        </Button>
      </div>
    </div>
  );
}
