"use client";

import { useState, type ReactNode } from "react";
import { BadgeCheck, ChevronDown, CreditCard, RotateCcw } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { RangeFilter } from "./range-filter";
import { useFiltersStore } from "@/lib/store/filters";
import { BATTERY_TYPES, CITIES, CONDITIONS, SLIDER_BOUNDS } from "@/lib/constants";
import { countActiveFilters } from "@/lib/filters";
import { cn } from "@/lib/utils";
import type { CategoryDTO, FacetsResponse } from "@/types";

/** Сворачиваемая секция фильтра. */
function Section({ title, children, defaultOpen = true }: { title: string; children: ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-b py-4 last:border-b-0">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between text-sm font-semibold"
        aria-expanded={open}
      >
        {title}
        <ChevronDown className={cn("h-4 w-4 transition-transform", open && "rotate-180")} />
      </button>
      {open && <div className="mt-3">{children}</div>}
    </div>
  );
}

/** Строка «чекбокс + подпись + счётчик фасета». */
function CheckRow({
  id,
  label,
  count,
  checked,
  onChange,
}: {
  id: string;
  label: string;
  count: number | undefined;
  checked: boolean;
  onChange: () => void;
}) {
  const disabled = count === 0 && !checked;
  return (
    <label htmlFor={id} className={cn("flex cursor-pointer items-center gap-2 py-1 text-sm", disabled && "opacity-50")}>
      <Checkbox id={id} checked={checked} onCheckedChange={onChange} disabled={disabled} />
      <span className="flex-1">{label}</span>
      <Count value={count} />
    </label>
  );
}

/** Строка «переключатель + подпись + счётчик». */
function ToggleRow({
  id,
  label,
  icon,
  count,
  checked,
  onChange,
}: {
  id: string;
  label: string;
  icon?: ReactNode;
  count: number | undefined;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label htmlFor={id} className="flex cursor-pointer items-center gap-2 py-1.5 text-sm">
      {icon}
      <span className="flex-1">{label}</span>
      <Count value={count} />
      <Switch id={id} checked={checked} onCheckedChange={onChange} disabled={count === 0 && !checked} />
    </label>
  );
}

function Count({ value }: { value: number | undefined }) {
  return (
    <span className="min-w-[1.5rem] text-right text-xs tabular-nums text-muted-foreground">
      {value === undefined ? "…" : value}
    </span>
  );
}

interface FiltersPanelProps {
  category: CategoryDTO | null;
  facets: FacetsResponse | undefined;
}

export function FiltersPanel({ category, facets }: FiltersPanelProps) {
  const { filters, setFilters, toggleInList, reset } = useFiltersStore();
  const [showAllCities, setShowAllCities] = useState(false);

  // Какие фильтры характеристик показывать: по атрибутам категории.
  // Для «всех объявлений» — все, кроме педалей (они только у электровелосипедов).
  const attrCodes = new Set(
    category ? category.attributes.map((a) => a.code) : ["motor_power_w", "battery_capacity_ah", "max_speed_kmh", "battery_type", "no_license", "has_epts"],
  );
  const hasSpecs = attrCodes.size > 0;

  // Города: сначала с ненулевым счётчиком и выбранные, остальные — под «Показать все»
  const sortedCities = [...CITIES].sort((a, b) => (facets?.city[b] ?? 0) - (facets?.city[a] ?? 0));
  const visibleCities = showAllCities
    ? sortedCities
    : sortedCities.filter((c, i) => i < 5 || filters.cities.includes(c));

  const activeCount = countActiveFilters(filters);

  return (
    <div className="text-sm">
      <div className="flex items-center justify-between pb-2">
        <h2 className="text-base font-semibold">Фильтры</h2>
        {activeCount > 0 && (
          <Button variant="ghost" size="sm" onClick={reset}>
            <RotateCcw className="h-3.5 w-3.5" />
            Сбросить фильтры
          </Button>
        )}
      </div>

      {/* ---------- Блок 1. Общие ---------- */}
      <Section title="Цена, BYN">
        <RangeFilter
          min={filters.priceMin}
          max={filters.priceMax}
          bounds={SLIDER_BOUNDS.price}
          onChange={(priceMin, priceMax) => setFilters({ priceMin, priceMax })}
        />
        {facets && facets.price.max > 0 && (
          <p className="mt-2 text-xs text-muted-foreground">
            В выборке: {Math.round(facets.price.min).toLocaleString("ru-RU")} –{" "}
            {Math.round(facets.price.max).toLocaleString("ru-RU")} р.
          </p>
        )}
      </Section>

      <Section title="Город">
        {visibleCities.map((city) => (
          <CheckRow
            key={city}
            id={`city-${city}`}
            label={city}
            count={facets?.city[city] ?? (facets ? 0 : undefined)}
            checked={filters.cities.includes(city)}
            onChange={() => toggleInList("cities", city)}
          />
        ))}
        <button
          type="button"
          className="mt-1 text-xs text-primary hover:underline"
          onClick={() => setShowAllCities((v) => !v)}
        >
          {showAllCities ? "Свернуть" : "Показать все города"}
        </button>
      </Section>

      <Section title="Состояние">
        {CONDITIONS.map((c) => (
          <CheckRow
            key={c.value}
            id={`cond-${c.value}`}
            label={c.label}
            count={facets?.condition[c.value] ?? (facets ? 0 : undefined)}
            checked={filters.conditions.includes(c.value)}
            onChange={() => toggleInList("conditions", c.value)}
          />
        ))}
      </Section>

      <Section title="Гарантии и оплата">
        <ToggleRow
          id="is-original"
          label="Подтверждённая оригинальность"
          icon={<BadgeCheck className="h-4 w-4 text-tag-original" />}
          count={facets?.isOriginal}
          checked={filters.isOriginal}
          onChange={(isOriginal) => setFilters({ isOriginal })}
        />
        <ToggleRow
          id="has-installment"
          label="Доступна рассрочка"
          icon={<CreditCard className="h-4 w-4 text-tag-installment" />}
          count={facets?.hasInstallment}
          checked={filters.hasInstallment}
          onChange={(hasInstallment) => setFilters({ hasInstallment })}
        />
      </Section>

      {/* ---------- Блок 2. Характеристики (зависят от категории) ---------- */}
      {hasSpecs && (
        <>
          <p className="pt-4 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Характеристики</p>

          {attrCodes.has("motor_power_w") && (
            <Section title="Мощность мотор-колеса, Вт">
              <RangeFilter
                min={filters.motorPowerMin}
                max={filters.motorPowerMax}
                bounds={SLIDER_BOUNDS.motorPower}
                presets={facets?.motorPower}
                unit="Вт"
                onChange={(motorPowerMin, motorPowerMax) => setFilters({ motorPowerMin, motorPowerMax })}
              />
            </Section>
          )}

          {attrCodes.has("battery_capacity_ah") && (
            <Section title="Ёмкость аккумулятора, А·ч">
              <RangeFilter
                min={filters.batteryMin}
                max={filters.batteryMax}
                bounds={SLIDER_BOUNDS.battery}
                presets={facets?.battery}
                unit="А·ч"
                onChange={(batteryMin, batteryMax) => setFilters({ batteryMin, batteryMax })}
              />
            </Section>
          )}

          {attrCodes.has("max_speed_kmh") && (
            <Section title="Максимальная скорость">
              <RangeFilter
                min={filters.speedMin}
                max={filters.speedMax}
                presets={facets?.speed}
                withInputs={false}
                onChange={(speedMin, speedMax) => setFilters({ speedMin, speedMax })}
              />
            </Section>
          )}

          {attrCodes.has("battery_type") && (
            <Section title="Тип аккумулятора">
              {BATTERY_TYPES.map((t) => (
                <CheckRow
                  key={t}
                  id={`bt-${t}`}
                  label={t === "Pb" ? "Pb (свинцово-кислотный)" : t}
                  count={facets?.batteryType[t] ?? (facets ? 0 : undefined)}
                  checked={filters.batteryTypes.includes(t)}
                  onChange={() => toggleInList("batteryTypes", t)}
                />
              ))}
            </Section>
          )}

          {(attrCodes.has("no_license") || attrCodes.has("has_epts") || attrCodes.has("pedals")) && (
            <Section title="Особенности">
              {attrCodes.has("no_license") && (
                <ToggleRow
                  id="no-license"
                  label="Без прав"
                  count={facets?.noLicense}
                  checked={filters.noLicense}
                  onChange={(noLicense) => setFilters({ noLicense })}
                />
              )}
              {attrCodes.has("has_epts") && (
                <ToggleRow
                  id="has-epts"
                  label="С ЭПТС"
                  count={facets?.hasEpts}
                  checked={filters.hasEpts}
                  onChange={(hasEpts) => setFilters({ hasEpts })}
                />
              )}
              {attrCodes.has("pedals") && (
                <ToggleRow
                  id="pedals"
                  label="Наличие педалей"
                  count={facets?.pedals}
                  checked={filters.pedals}
                  onChange={(pedals) => setFilters({ pedals })}
                />
              )}
            </Section>
          )}
        </>
      )}
    </div>
  );
}
