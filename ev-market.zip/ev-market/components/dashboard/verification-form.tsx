"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Controller, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { BadgeCheck, Clock, FileText, Loader2, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input, NativeSelect } from "@/components/ui/input";
import { Field, Label } from "@/components/ui/label";
import { FileDropzone } from "./file-dropzone";
import { sellerVerificationSchema, type SellerVerificationInput } from "@/lib/validation";

interface Props {
  initial: {
    type: "individual" | "dealer";
    inn: string | null;
    verificationStatus: "none" | "pending" | "approved" | "rejected";
    verificationDocs: string[];
    verified: boolean;
  };
}

const STATUS_VIEW = {
  none: null,
  pending: { icon: Clock, text: "Заявка на рассмотрении у модератора", cls: "bg-tag-discounted/10 text-tag-discounted" },
  approved: { icon: BadgeCheck, text: "Вы — проверенный продавец", cls: "bg-tag-original/10 text-tag-original" },
  rejected: { icon: XCircle, text: "Заявка отклонена. Исправьте данные и отправьте повторно.", cls: "bg-destructive/10 text-destructive" },
} as const;

export function VerificationForm({ initial }: Props) {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const { register, handleSubmit, control, formState } = useForm<SellerVerificationInput>({
    resolver: zodResolver(sellerVerificationSchema),
    defaultValues: { type: initial.type, inn: initial.inn ?? "", docs: initial.verificationDocs },
  });
  const status = STATUS_VIEW[initial.verificationStatus];

  const onSubmit = async (values: SellerVerificationInput) => {
    setError(null);
    const res = await fetch("/api/sellers/me/verification", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    if (!res.ok) {
      setError("Не удалось отправить заявку");
      return;
    }
    router.refresh();
  };

  return (
    <Card className="max-w-2xl space-y-5 p-6">
      {status && (
        <div className={`flex items-center gap-2 rounded-md p-3 text-sm ${status.cls}`}>
          <status.icon className="h-5 w-5" /> {status.text}
        </div>
      )}
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Тип продавца" htmlFor="type">
            <NativeSelect id="type" {...register("type")}>
              <option value="individual">Частное лицо</option>
              <option value="dealer">Дилер / юрлицо</option>
            </NativeSelect>
          </Field>
          <Field label="УНП / ИНН" htmlFor="inn" error={formState.errors.inn?.message}>
            <Input id="inn" inputMode="numeric" maxLength={9} {...register("inn")} />
          </Field>
        </div>
        <Controller
          control={control}
          name="docs"
          render={({ field, fieldState }) => (
            <div className="space-y-2">
              <Label>Документы (свидетельство о регистрации, дилерский договор)</Label>
              {field.value.length > 0 && (
                <ul className="space-y-1 text-sm">
                  {field.value.map((url) => (
                    <li key={url} className="flex items-center gap-2">
                      <FileText className="h-4 w-4" />
                      <a href={url} target="_blank" rel="noreferrer" className="truncate text-primary hover:underline">{url.split("/").pop()}</a>
                      <button type="button" className="text-xs text-muted-foreground hover:text-destructive" onClick={() => field.onChange(field.value.filter((u) => u !== url))}>
                        удалить
                      </button>
                    </li>
                  ))}
                </ul>
              )}
              <FileDropzone
                accept="application/pdf,image/jpeg,image/png"
                hint="PDF, JPG или PNG до 10 МБ"
                onUploaded={(files) => field.onChange([...field.value, ...files.map((f) => f.url)])}
              />
              {fieldState.error && <p className="text-xs text-destructive">{fieldState.error.message}</p>}
            </div>
          )}
        />
        {error && <p className="text-sm text-destructive">{error}</p>}
        <Button type="submit" disabled={formState.isSubmitting || initial.verificationStatus === "pending"}>
          {formState.isSubmitting && <Loader2 className="h-4 w-4 animate-spin" />}
          {initial.verificationStatus === "approved" ? "Обновить данные" : "Отправить на проверку"}
        </Button>
      </form>
    </Card>
  );
}
