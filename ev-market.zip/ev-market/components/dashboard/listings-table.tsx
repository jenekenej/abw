"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Archive, ExternalLink, Pencil, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ListingBadges } from "@/components/listing/listing-badges";
import { LISTING_STATUS_LABELS } from "@/lib/constants";
import { formatPrice } from "@/lib/utils";
import type { ListingCardDTO } from "@/types";

const STATUS_VARIANT: Record<string, "new" | "used" | "discounted" | "original" | "secondary"> = {
  active: "new",
  moderation: "discounted",
  rejected: "secondary",
  archived: "used",
  draft: "used",
};

/** Таблица объявлений продавца с действиями «редактировать / архивировать». */
export function ListingsTable({ listings }: { listings: ListingCardDTO[] }) {
  const router = useRouter();
  const [busy, setBusy] = useState<string | null>(null);

  const setStatus = async (id: string, status: "archived" | "moderation") => {
    setBusy(id);
    await fetch(`/api/listings/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    setBusy(null);
    router.refresh();
  };

  if (listings.length === 0) {
    return (
      <div className="rounded-lg border border-dashed p-10 text-center text-muted-foreground">
        <p>Здесь пока пусто.</p>
        <Button asChild className="mt-4">
          <Link href="/dashboard/listings/new">Создать первое объявление</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto rounded-lg border bg-card">
      <table className="w-full min-w-[720px] text-sm">
        <thead className="border-b bg-muted/50 text-left text-xs uppercase text-muted-foreground">
          <tr>
            <th className="p-3">Фото</th>
            <th className="p-3">Название</th>
            <th className="p-3">Цена</th>
            <th className="p-3">Статус</th>
            <th className="p-3">Бейджи</th>
            <th className="p-3 text-right">Действия</th>
          </tr>
        </thead>
        <tbody className="divide-y">
          {listings.map((l) => (
            <tr key={l.id}>
              <td className="p-3">
                <div className="h-12 w-16 overflow-hidden rounded bg-muted">
                  {l.imageUrl && <img src={l.imageUrl} alt="" className="h-full w-full object-cover" />}
                </div>
              </td>
              <td className="max-w-[260px] p-3">
                <Link href={`/listing/${l.id}`} className="line-clamp-2 font-medium hover:text-primary">{l.title}</Link>
                <p className="text-xs text-muted-foreground">{l.categoryName} · {l.views} просмотров</p>
              </td>
              <td className="whitespace-nowrap p-3 font-medium">{formatPrice(l.priceByn)}</td>
              <td className="p-3">
                <Badge variant={STATUS_VARIANT[l.status] ?? "secondary"}>{LISTING_STATUS_LABELS[l.status] ?? l.status}</Badge>
              </td>
              <td className="p-3"><ListingBadges badges={l.badges} /></td>
              <td className="p-3">
                <div className="flex justify-end gap-1">
                  <Button asChild variant="ghost" size="icon" title="Открыть">
                    <Link href={`/listing/${l.id}`}><ExternalLink className="h-4 w-4" /></Link>
                  </Button>
                  <Button asChild variant="ghost" size="icon" title="Редактировать">
                    <Link href={`/dashboard/listings/${l.id}/edit`}><Pencil className="h-4 w-4" /></Link>
                  </Button>
                  {l.status === "archived" ? (
                    <Button variant="ghost" size="icon" title="Вернуть из архива (на модерацию)" disabled={busy === l.id} onClick={() => setStatus(l.id, "moderation")}>
                      <RotateCcw className="h-4 w-4" />
                    </Button>
                  ) : (
                    <Button variant="ghost" size="icon" title="В архив" disabled={busy === l.id} onClick={() => setStatus(l.id, "archived")}>
                      <Archive className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
