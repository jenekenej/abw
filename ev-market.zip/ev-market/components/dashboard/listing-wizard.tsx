"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Controller, useForm, type FieldPath } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { ArrowLeft, ArrowRight, Check, ChevronLeft, FileText, Loader2, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input, NativeSelect, Textarea } from "@/components/ui/input";
import { Field, Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { FileDropzone } from "./file-dropzone";
import { listingInputSchema, type ListingInput } from "@/lib/validation";
import { CITIES, CONDITIONS, INSTALLMENT_TERMS } from "@/lib/constants";
import { cn, formatPrice, isRecord, USD_RATE } from "@/lib/utils";
import type { CategoryDTO } from "@/types";

export interface BankOption {
  id: string;
  name: string;
  defaultRate: number;
}

interface Props {
  categories: CategoryDTO[];
  banks: BankOption[];
  /** Для редактирования: ID и исходные значения. */
  listingId?: string;
  initialValues?: ListingInput;
}

const STEPS = [
  { title: "Категория", fields: ["categoryId", "subcategoryId"] },
  { title: "Основное", fields: ["title", "description", "price", "currency", "city"] },
  { title: "Состояние", fields: ["condition", "discountReason", "oldPrice"] },
  { title: "Характеристики", fields: ["attrs"] },
  { title: "Медиа", fields: ["media"] },
  { title: "Оригинальность", fields: ["isOriginal", "serialNumber", "vin", "certificateUrl"] },
  { title: "Рассрочка", fields: ["hasInstallment", "installmentOffers"] },
  { title: "Публикация", fields: [] },
] as const satisfies readonly { title: string; fields: readonly FieldPath<ListingInput>[] }[];

const DEFAULTS: ListingInput = {
  categoryId: "",
  subcategoryId: null,
  title: "",
  description: "",
  price: Number.NaN,
  currency: "BYN",
  city: "Минск",
  condition: "new",
  oldPrice: null,
  discountReason: null,
  attrs: {},
  media: [],
  isOriginal: false,
  serialNumber: null,
  vin: null,
  certificateUrl: null,
  hasInstallment: false,
  installmentOffers: [],
};

/** Номер шага, к которому относится поле с ошибкой (по префиксу пути). */
function stepOfField(path: string): number {
  const idx = STEPS.findIndex((s) => (s.fields as readonly string[]).some((f) => path === f || path.startsWith(`${f}.`)));
  return idx === -1 ? 0 : idx;
}

const emptyToNull = (v: unknown): number | null => (v === "" || v === null || v === undefined ? null : Number(v));
const emptyToUndefined = (v: unknown): number | undefined => (v === "" || v === null || v === undefined ? undefined : Number(v));

/** Мастер создания/редактирования объявления (8 шагов). */
export function ListingWizard({ categories, banks, listingId, initialValues }: Props) {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [serverError, setServerError] = useState<string | null>(null);

  const form = useForm<ListingInput>({
    resolver: zodResolver(listingInputSchema),
    defaultValues: initialValues ?? DEFAULTS,
    mode: "onTouched",
  });
  const { register, control, watch, setValue, getValues, setError, clearErrors, trigger, formState } = form;
  const errors = formState.errors;

  const categoryId = watch("categoryId");
  const category = categories.find((c) => c.id === categoryId) ?? null;
  const condition = watch("condition");
  const media = watch("media");
  const isOriginal = watch("isOriginal");
  const hasInstallment = watch("hasInstallment");
  const offers = watch("installmentOffers");
  const certificateUrl = watch("certificateUrl");

  /** Проверки из superRefine, которые zod не выполнит, пока не валидна вся форма. */
  const crossFieldCheck = (s: number): boolean => {
    const v = getValues();
    let ok = true;
    if (s === 2 && v.condition === "discounted" && !v.discountReason?.trim()) {
      setError("discountReason", { message: "Укажите причину уценки" });
      ok = false;
    }
    if (s === 2 && v.oldPrice != null && Number.isFinite(v.price) && v.oldPrice <= v.price) {
      setError("oldPrice", { message: "Старая цена должна быть выше текущей" });
      ok = false;
    }
    if (s === 5 && v.isOriginal && !v.serialNumber?.trim() && !v.vin?.trim()) {
      setError("serialNumber", { message: "Укажите серийный номер или VIN" });
      ok = false;
    }
    if (s === 6 && v.hasInstallment && v.installmentOffers.length === 0) {
      setError("installmentOffers", { message: "Выберите хотя бы один банк" });
      ok = false;
    }
    return ok;
  };

  const next = async () => {
    const fields = STEPS[step].fields;
    // trigger валидирует всю схему, но возвращает результат только по указанным полям
    const valid = fields.length === 0 ? true : await trigger([...fields]);
    if (valid && crossFieldCheck(step)) setStep((s) => Math.min(s + 1, STEPS.length - 1));
  };

  const onSubmit = async (values: ListingInput) => {
    setServerError(null);
    // Чистим незаполненные характеристики
    const attrs = Object.fromEntries(
      Object.entries(values.attrs).filter(([, v]) => v !== undefined && !(typeof v === "number" && Number.isNaN(v))),
    );
    const payload: ListingInput = { ...values, attrs };
    const res = await fetch(listingId ? `/api/listings/${listingId}` : "/api/listings", {
      method: listingId ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(listingId ? { data: payload } : payload),
    });
    const body: unknown = await res.json().catch(() => null);
    if (!res.ok) {
      setServerError(isRecord(body) && typeof body.error === "string" ? body.error : "Ошибка сохранения");
      if (isRecord(body) && isRecord(body.details)) {
        let firstStep: number | null = null;
        for (const [path, message] of Object.entries(body.details)) {
          if (typeof message !== "string") continue;
          setError(path as FieldPath<ListingInput>, { message });
          const s = stepOfField(path);
          firstStep = firstStep === null ? s : Math.min(firstStep, s);
        }
        if (firstStep !== null) setStep(firstStep);
      }
      return;
    }
    const status = isRecord(body) && typeof body.status === "string" ? body.status : "moderation";
    router.push(`/dashboard?saved=${status}`);
    router.refresh();
  };

  // При ошибке на финальной отправке переходим к первому шагу с ошибкой
  const onInvalid = (errs: typeof errors) => {
    const first = Object.keys(errs)[0];
    if (first) setStep(stepOfField(first));
  };

  const toggleBank = (bankId: string, checked: boolean) => {
    const current = getValues("installmentOffers");
    setValue(
      "installmentOffers",
      checked ? [...current, { bankId, terms: [...INSTALLMENT_TERMS], minDownPercent: 0 }] : current.filter((o) => o.bankId !== bankId),
      { shouldDirty: true },
    );
    clearErrors("installmentOffers");
  };

  const updateOffer = (bankId: string, patch: Partial<ListingInput["installmentOffers"][number]>) => {
    setValue(
      "installmentOffers",
      getValues("installmentOffers").map((o) => (o.bankId === bankId ? { ...o, ...patch } : o)),
      { shouldDirty: true },
    );
  };

  const moveMedia = (from: number, to: number) => {
    const list = [...getValues("media")];
    const [item] = list.splice(from, 1);
    if (item) list.splice(to, 0, item);
    setValue("media", list);
  };

  const isLast = step === STEPS.length - 1;
  // Не уводим фокус из поля при нажатии на кнопки навигации: иначе blur-валидация
  // убирает сообщение об ошибке, вёрстка сдвигается и клик «промахивается» мимо кнопки.
  const keepFocus = (e: React.MouseEvent) => e.preventDefault();

  return (
    <form
      // Enter в поле ввода не публикует объявление, а переходит к следующему шагу.
      // Отправка — только явной кнопкой «Опубликовать» на последнем шаге.
      onSubmit={(e) => {
        e.preventDefault();
        if (!isLast) void next();
      }}
      className="space-y-6"
    >
      {/* Индикатор шагов */}
      <ol className="flex gap-1 overflow-x-auto pb-1">
        {STEPS.map((s, i) => (
          <li key={s.title} className="flex-1">
            <button
              type="button"
              onClick={() => i < step && setStep(i)}
              className={cn(
                "w-full min-w-[96px] rounded-md border px-2 py-2 text-left text-xs",
                i === step && "border-primary bg-accent text-accent-foreground",
                i < step && "cursor-pointer text-muted-foreground hover:border-primary",
                i > step && "cursor-default text-muted-foreground opacity-60",
              )}
            >
              <span className="block font-semibold">{i < step ? <Check className="inline h-3 w-3" /> : i + 1}</span>
              {s.title}
            </button>
          </li>
        ))}
      </ol>

      <Card className="space-y-5 p-5 md:p-6">
        <h2 className="text-xl font-semibold">
          Шаг {step + 1}. {STEPS[step].title}
        </h2>

        {/* Шаг 1. Категория → подкатегория */}
        {step === 0 && (
          <div className="space-y-5">
            <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
              {categories.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => {
                    setValue("categoryId", c.id, { shouldValidate: true });
                    setValue("subcategoryId", null);
                    setValue("attrs", {});
                  }}
                  className={cn(
                    "rounded-lg border p-3 text-sm font-medium",
                    categoryId === c.id ? "border-primary bg-accent text-accent-foreground" : "hover:border-primary/60",
                  )}
                >
                  {c.name}
                </button>
              ))}
            </div>
            {errors.categoryId && <p className="text-sm text-destructive">{errors.categoryId.message}</p>}
            {category && category.children.length > 0 && (
              <Field label="Подкатегория" htmlFor="subcategoryId">
                <NativeSelect id="subcategoryId" {...register("subcategoryId", { setValueAs: (v: string) => v || null })}>
                  <option value="">Не выбрано</option>
                  {category.children.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                </NativeSelect>
              </Field>
            )}
          </div>
        )}

        {/* Шаг 2. Основное */}
        {step === 1 && (
          <div className="space-y-4">
            <Field label="Заголовок" htmlFor="title" error={errors.title?.message} hint="Например: «Электросамокат Kugoo M4 Pro 500 Вт»">
              <Input id="title" {...register("title")} />
            </Field>
            <Field label="Описание" htmlFor="description" error={errors.description?.message}>
              <Textarea id="description" rows={6} {...register("description")} />
            </Field>
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="Цена" htmlFor="price" error={errors.price?.message}>
                <Input id="price" type="number" min={0} step="0.01" {...register("price", { valueAsNumber: true })} />
              </Field>
              <Field label="Валюта" htmlFor="currency">
                <NativeSelect id="currency" {...register("currency")}>
                  <option value="BYN">BYN</option>
                  <option value="USD">USD</option>
                </NativeSelect>
              </Field>
              <Field label="Город" htmlFor="city" error={errors.city?.message}>
                <NativeSelect id="city" {...register("city")}>
                  {CITIES.map((c) => <option key={c} value={c}>{c}</option>)}
                </NativeSelect>
              </Field>
            </div>
            {watch("currency") === "USD" && (
              <p className="text-xs text-muted-foreground">
                Цена будет пересчитана в BYN по курсу {USD_RATE} для поиска и фильтров.
              </p>
            )}
          </div>
        )}

        {/* Шаг 3. Состояние */}
        {step === 2 && (
          <div className="space-y-4">
            <div className="grid gap-2 sm:grid-cols-3" role="radiogroup">
              {CONDITIONS.map((c) => (
                <label
                  key={c.value}
                  className={cn(
                    "flex cursor-pointer items-center gap-2 rounded-lg border p-3 text-sm font-medium",
                    condition === c.value && "border-primary bg-accent text-accent-foreground",
                  )}
                >
                  <input type="radio" value={c.value} {...register("condition")} className="accent-[hsl(var(--primary))]" />
                  {c.label}
                </label>
              ))}
            </div>
            {condition === "discounted" && (
              <>
                <Field label="Причина уценки *" htmlFor="discountReason" error={errors.discountReason?.message}>
                  <Textarea id="discountReason" rows={3} {...register("discountReason")} placeholder="Например: витринный образец, царапина на раме" />
                </Field>
                <Field label="Цена до уценки" htmlFor="oldPrice" error={errors.oldPrice?.message} hint="Будет показана зачёркнутой">
                  <Input id="oldPrice" type="number" min={0} {...register("oldPrice", { setValueAs: emptyToNull })} />
                </Field>
              </>
            )}
          </div>
        )}

        {/* Шаг 4. Характеристики — динамические поля по атрибутам категории */}
        {step === 3 && (
          <div className="grid gap-4 sm:grid-cols-2">
            {!category || category.attributes.length === 0 ? (
              <p className="text-sm text-muted-foreground sm:col-span-2">Для этой категории характеристики не требуются.</p>
            ) : (
              category.attributes.map((a) => {
                const path = `attrs.${a.code}` as const;
                const error = (errors.attrs as Record<string, { message?: string }> | undefined)?.[a.code]?.message;
                if (a.type === "bool") {
                  return (
                    <Controller
                      key={a.code}
                      control={control}
                      name={path}
                      render={({ field }) => (
                        <label className="flex items-center justify-between rounded-lg border p-3 text-sm">
                          {a.name}
                          <Switch checked={field.value === true} onCheckedChange={(v) => field.onChange(v)} />
                        </label>
                      )}
                    />
                  );
                }
                if (a.type === "enum") {
                  return (
                    <Field key={a.code} label={a.name} htmlFor={a.code} error={error}>
                      <NativeSelect id={a.code} {...register(path, { setValueAs: (v: string) => v || undefined })}>
                        <option value="">Не указано</option>
                        {a.options.map((o) => <option key={o} value={o}>{o}</option>)}
                      </NativeSelect>
                    </Field>
                  );
                }
                return (
                  <Field key={a.code} label={`${a.name}${a.unit ? `, ${a.unit}` : ""}`} htmlFor={a.code} error={error}>
                    <Input
                      id={a.code}
                      type="number"
                      min={0}
                      step={a.type === "float" ? "0.1" : "1"}
                      {...register(path, { setValueAs: emptyToUndefined })}
                    />
                  </Field>
                );
              })
            )}
          </div>
        )}

        {/* Шаг 5. Медиа */}
        {step === 4 && (
          <div className="space-y-4">
            <FileDropzone
              accept="image/jpeg,image/png,image/webp,video/mp4"
              hint="JPG, PNG, WEBP или MP4 до 10 МБ. Первое фото станет обложкой."
              onUploaded={(files) =>
                setValue("media", [...getValues("media"), ...files.map((f) => ({ url: f.url, kind: f.kind }))], { shouldValidate: true })
              }
            />
            {errors.media && <p className="text-sm text-destructive">{errors.media.message}</p>}
            {media.length > 0 && (
              <div className="grid grid-cols-3 gap-2 md:grid-cols-5">
                {media.map((m, i) => (
                  <div key={`${m.url}-${i}`} className="group relative aspect-[4/3] overflow-hidden rounded-md border bg-muted">
                    {m.kind === "video" ? (
                      <video src={m.url} className="h-full w-full object-cover" muted />
                    ) : (
                      <img src={m.url} alt="" className="h-full w-full object-cover" />
                    )}
                    {i === 0 && <span className="absolute left-1 top-1 rounded bg-primary px-1.5 text-[10px] text-primary-foreground">Обложка</span>}
                    <div className="absolute inset-x-0 bottom-0 flex justify-between bg-black/50 p-1 opacity-0 transition group-hover:opacity-100">
                      <button type="button" disabled={i === 0} onClick={() => moveMedia(i, i - 1)} className="text-white disabled:opacity-30" aria-label="Левее">
                        <ChevronLeft className="h-4 w-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setValue("media", media.filter((_, j) => j !== i))}
                        className="text-white"
                        aria-label="Удалить"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Шаг 6. Оригинальность */}
        {step === 5 && (
          <div className="space-y-4">
            <Controller
              control={control}
              name="isOriginal"
              render={({ field }) => (
                <label className="flex items-center gap-2 text-sm font-medium">
                  <Checkbox checked={field.value} onCheckedChange={(v) => field.onChange(v === true)} />
                  Товар оригинальный
                </label>
              )}
            />
            {isOriginal && (
              <>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="Серийный номер" htmlFor="serialNumber" error={errors.serialNumber?.message}>
                    <Input id="serialNumber" {...register("serialNumber")} />
                  </Field>
                  <Field label="VIN" htmlFor="vin" error={errors.vin?.message} hint="Для электромобилей и мотоциклов">
                    <Input id="vin" {...register("vin")} />
                  </Field>
                </div>
                <div className="space-y-2">
                  <Label>Сертификат / документы (необязательно)</Label>
                  {certificateUrl ? (
                    <div className="flex items-center gap-2 text-sm">
                      <FileText className="h-4 w-4" />
                      <a href={certificateUrl} target="_blank" rel="noreferrer" className="text-primary hover:underline">Загруженный файл</a>
                      <Button type="button" variant="ghost" size="sm" onClick={() => setValue("certificateUrl", null)}>Удалить</Button>
                    </div>
                  ) : (
                    <FileDropzone
                      accept="application/pdf,image/jpeg,image/png"
                      multiple={false}
                      hint="PDF или фото сертификата. Проверка — вручную модератором."
                      onUploaded={(files) => setValue("certificateUrl", files[0]?.url ?? null)}
                    />
                  )}
                </div>
                <p className="rounded-md bg-tag-original/10 p-3 text-xs text-tag-original">
                  После публикации модератор проверит данные. Бейдж «Оригинал» появится после подтверждения.
                </p>
              </>
            )}
          </div>
        )}

        {/* Шаг 7. Рассрочка */}
        {step === 6 && (
          <div className="space-y-4">
            <Controller
              control={control}
              name="hasInstallment"
              render={({ field }) => (
                <label className="flex items-center gap-2 text-sm font-medium">
                  <Checkbox checked={field.value} onCheckedChange={(v) => field.onChange(v === true)} />
                  Доступна рассрочка
                </label>
              )}
            />
            {hasInstallment && (
              <div className="space-y-3">
                {banks.map((b) => {
                  const offer = offers.find((o) => o.bankId === b.id);
                  return (
                    <div key={b.id} className={cn("rounded-lg border p-4", offer && "border-tag-installment")}>
                      <label className="flex items-center gap-2 text-sm font-medium">
                        <Checkbox checked={Boolean(offer)} onCheckedChange={(v) => toggleBank(b.id, v === true)} />
                        {b.name}
                        <span className="ml-auto text-xs font-normal text-muted-foreground">
                          {b.defaultRate === 0 ? "0%" : `${Math.round(b.defaultRate * 100)}% годовых`}
                        </span>
                      </label>
                      {offer && (
                        <div className="mt-3 grid gap-3 sm:grid-cols-2">
                          <div className="space-y-1.5">
                            <Label>Сроки, мес.</Label>
                            <div className="flex flex-wrap gap-3">
                              {INSTALLMENT_TERMS.map((t) => (
                                <label key={t} className="flex items-center gap-1 text-sm">
                                  <Checkbox
                                    checked={offer.terms.includes(t)}
                                    onCheckedChange={(v) =>
                                      updateOffer(b.id, {
                                        terms: v === true ? [...offer.terms, t] : offer.terms.filter((x) => x !== t),
                                      })
                                    }
                                  />
                                  {t}
                                </label>
                              ))}
                            </div>
                          </div>
                          <Field label="Мин. первоначальный взнос, %" htmlFor={`down-${b.id}`}>
                            <Input
                              id={`down-${b.id}`}
                              type="number"
                              min={0}
                              max={50}
                              value={offer.minDownPercent}
                              onChange={(e) => updateOffer(b.id, { minDownPercent: Math.min(50, Math.max(0, Number(e.target.value) || 0)) })}
                            />
                          </Field>
                        </div>
                      )}
                    </div>
                  );
                })}
                {errors.installmentOffers && (
                  <p className="text-sm text-destructive">{errors.installmentOffers.message ?? "Проверьте условия рассрочки"}</p>
                )}
              </div>
            )}
          </div>
        )}

        {/* Шаг 8. Публикация — сводка */}
        {step === 7 && (
          <div className="space-y-3 text-sm">
            <Summary label="Категория" value={[category?.name, category?.children.find((s) => s.id === watch("subcategoryId"))?.name].filter(Boolean).join(" / ")} />
            <Summary label="Заголовок" value={watch("title")} />
            <Summary
              label="Цена"
              value={Number.isFinite(watch("price")) ? (watch("currency") === "USD" ? `$${watch("price")}` : formatPrice(watch("price"))) : "—"}
            />
            <Summary label="Город" value={watch("city")} />
            <Summary label="Состояние" value={CONDITIONS.find((c) => c.value === condition)?.label ?? ""} />
            <Summary label="Фото/видео" value={`${media.length} шт.`} />
            <Summary label="Оригинальность" value={isOriginal ? "Заявлена, будет проверена" : "Не заявлена"} />
            <Summary label="Рассрочка" value={hasInstallment ? `${offers.length} банк(а)` : "Нет"} />
            <p className="rounded-md bg-muted p-3 text-muted-foreground">
              После отправки объявление получит статус «На модерации» и появится в каталоге после проверки.
            </p>
          </div>
        )}

        {serverError && <p className="rounded-md bg-destructive/10 p-3 text-sm text-destructive">{serverError}</p>}

        <div className="flex justify-between border-t pt-4">
          <Button type="button" variant="outline" onMouseDown={keepFocus} onClick={() => setStep((s) => Math.max(0, s - 1))} disabled={step === 0}>
            <ArrowLeft className="h-4 w-4" /> Назад
          </Button>
          {isLast ? (
            <Button
              key="publish"
              type="button"
              onMouseDown={keepFocus}
              onClick={() => void form.handleSubmit(onSubmit, onInvalid)()}
              disabled={formState.isSubmitting}
            >
              {formState.isSubmitting && <Loader2 className="h-4 w-4 animate-spin" />}
              {listingId ? "Сохранить и отправить на модерацию" : "Опубликовать"}
            </Button>
          ) : (
            <Button key="next" type="button" onMouseDown={keepFocus} onClick={() => void next()}>
              Далее <ArrowRight className="h-4 w-4" />
            </Button>
          )}
        </div>
      </Card>
    </form>
  );
}

function Summary({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-4 border-b pb-2">
      <span className="text-muted-foreground">{label}</span>
      <span className="text-right font-medium">{value || "—"}</span>
    </div>
  );
}
