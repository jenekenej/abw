"use client";

import { useRef, useState, type DragEvent } from "react";
import { Loader2, UploadCloud } from "lucide-react";
import { cn, isRecord } from "@/lib/utils";

export interface UploadedFile {
  url: string;
  kind: "image" | "video";
  name: string;
}

function isUploadedFile(v: unknown): v is UploadedFile {
  return isRecord(v) && typeof v.url === "string" && (v.kind === "image" || v.kind === "video") && typeof v.name === "string";
}

interface Props {
  accept: string;
  multiple?: boolean;
  hint?: string;
  onUploaded: (files: UploadedFile[]) => void;
}

/**
 * Drag&drop-загрузка файлов на /api/uploads.
 * MVP: файлы сохраняются в /public/uploads. В проде — presigned URL в S3.
 */
export function FileDropzone({ accept, multiple = true, hint, onUploaded }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const upload = async (list: FileList | null) => {
    if (!list || list.length === 0) return;
    setError(null);
    setUploading(true);
    try {
      const body = new FormData();
      Array.from(list).forEach((f) => body.append("files", f));
      const res = await fetch("/api/uploads", { method: "POST", body });
      const json: unknown = await res.json();
      if (!res.ok) {
        setError(isRecord(json) && typeof json.error === "string" ? json.error : "Ошибка загрузки");
        return;
      }
      const files = isRecord(json) && Array.isArray(json.files) ? json.files.filter(isUploadedFile) : [];
      onUploaded(files);
    } catch {
      setError("Не удалось загрузить файлы");
    } finally {
      setUploading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  const onDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragOver(false);
    void upload(e.dataTransfer.files);
  };

  return (
    <div>
      <div
        role="button"
        tabIndex={0}
        onClick={() => inputRef.current?.click()}
        onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && inputRef.current?.click()}
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={onDrop}
        className={cn(
          "flex cursor-pointer flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed p-8 text-center text-sm transition-colors",
          dragOver ? "border-primary bg-accent" : "hover:border-primary/60",
        )}
      >
        {uploading ? <Loader2 className="h-8 w-8 animate-spin text-primary" /> : <UploadCloud className="h-8 w-8 text-muted-foreground" />}
        <p className="font-medium">{uploading ? "Загрузка…" : "Перетащите файлы сюда или нажмите для выбора"}</p>
        {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
        <input
          ref={inputRef}
          type="file"
          accept={accept}
          multiple={multiple}
          className="hidden"
          onChange={(e) => void upload(e.target.files)}
        />
      </div>
      {error && <p className="mt-2 text-sm text-destructive">{error}</p>}
    </div>
  );
}
