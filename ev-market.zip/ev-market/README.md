# ЭлектроРынок — MVP классифайда электротранспорта (Беларусь)

Каталог объявлений: электровелосипеды, электроскутеры, электромотоциклы, гироскутеры, моноколёса,
электромобили, запчасти. Есть расширенные фильтры со счётчиками (фасетами), карточка товара,
личный кабинет продавца с мастером подачи объявления, кредитный калькулятор с заявкой в банк-партнёр
(заглушка) и простая модерация.

**Стек:** Next.js 14 (App Router) · TypeScript strict · TailwindCSS + shadcn/ui (Radix) · Prisma 5 · PostgreSQL 16 ·
NextAuth (Credentials + JWT) · react-hook-form + zod · Zustand · TanStack Query · Swiper.

---

## Быстрый старт

Нужны Node.js ≥ 18.18 (проверено на 22) и Docker.

```bash
cp .env.example .env            # при необходимости поправьте NEXTAUTH_SECRET
docker-compose up -d            # PostgreSQL 16 на localhost:5432
npm install                     # заодно выполнит prisma generate
npm run setup                   # = prisma migrate deploy + npm run seed
npm run dev                     # http://localhost:3000
```

Сид можно перезапускать в любой момент (`npm run seed`): он очищает таблицы и заливает демо-данные заново.

Production-сборка: `npm run build && npm start`.

### Демо-аккаунты

| Роль | Email | Пароль |
|---|---|---|
| Администратор (модерация) | admin@evmarket.by | admin123 |
| Продавец-дилер (верифицирован) | seller1@evmarket.by | seller123 |
| Продавец — частное лицо | seller2@evmarket.by | seller123 |
| Покупатель | buyer@evmarket.by | buyer123 |

### Переменные окружения

| Переменная | Назначение |
|---|---|
| `DATABASE_URL` | Строка подключения к PostgreSQL |
| `NEXTAUTH_URL`, `NEXTAUTH_SECRET` | Настройки NextAuth (секрет: `openssl rand -base64 32`) |
| `NEXT_PUBLIC_USD_RATE` | Курс BYN за 1 USD для переключателя валюты и пересчёта цен в USD |
| `AUTO_APPROVE_LISTINGS` | `true` — новые объявления сразу `active`, иначе `moderation` |
| `BANK_WEBHOOK_SECRET` | Секрет заголовка `X-Bank-Secret` для webhook'ов банков |

---

## Структура проекта

```
app/
  page.tsx                                — главная: категории, свежие объявления, топ-бренды
  catalog/page.tsx                        — все объявления
  catalog/[categorySlug]/page.tsx         — категория
  catalog/[categorySlug]/[subSlug]/page.tsx — подкатегория
  listing/[id]/page.tsx                   — карточка товара
  seller/[id]/page.tsx                    — публичный профиль продавца
  login/, register/                       — вход и регистрация (покупатель/продавец)
  dashboard/                              — ЛК продавца (layout + список объявлений)
    listings/new, listings/[id]/edit      — мастер создания/редактирования (8 шагов)
    installments/                         — банки, условия рассрочки, входящие заявки
    verification/                         — заявка на верификацию продавца
  admin/page.tsx                          — модерация объявлений, оригинальности, продавцов
  api/…                                   — Route Handlers (см. ниже)
components/
  ui/                                     — базовые shadcn/ui-компоненты
  catalog/                                — CatalogView (URL ↔ Zustand ↔ TanStack Query), FiltersPanel, RangeFilter
  listing/                                — карточка, бейджи, галерея, калькулятор рассрочки
  dashboard/                              — мастер объявления, таблица, загрузка файлов, верификация
  admin/                                  — кнопки модерации
lib/
  filters.ts                              — модель фильтров и (де)сериализация в query-строку (изоморфно)
  search.ts                               — SQL-поиск и фасеты (единственное место, которое меняется при переходе на Elasticsearch)
  listing-service.ts                      — сохранение объявления: атрибуты, цена в BYN, бейджи, рассрочка, журнал
  validation.ts                           — zod-схемы (общие для форм и API)
  installment.ts                          — формула ежемесячного платежа
  auth.ts, serialize.ts, store/…          — NextAuth, DTO, Zustand-сторы
prisma/
  schema.prisma, seed.ts, migrations/     — схема, сид, SQL-миграция
middleware.ts                             — доступ: /dashboard — продавцы, /admin — администраторы
```

## База данных

Модели: `User`, `Seller`, `Category` (дерево), `AttributeDefinition`, `Listing`, `ListingMedia`, `Badge`,
`ListingBadge`, `Bank`, `InstallmentOffer`, `InstallmentApplication`, `ModerationLog`.

- Динамические характеристики хранятся в `Listing.attrs` (JSONB) с GIN-индексом `jsonb_path_ops`;
  булевы фильтры используют оператор `@>`, поэтому попадают в индекс.
- Цена хранится как введена (`price` + `currency`) и дополнительно в BYN (`priceByn`) — по ней работают фильтр и сортировка.
- Бейджи (`original`, `installment`, `new`, `discounted`) вычисляются из полей объявления и синхронизируются в `ListingBadge`
  при каждом сохранении/решении модератора.
- Миграция: `prisma/migrations/20261015134030_init/migration.sql`. После изменения схемы — `npm run db:migrate`.

## API

| Метод | Путь | Описание |
|---|---|---|
| GET | `/api/categories` | Дерево категорий с атрибутами |
| GET | `/api/banks` | Банки-партнёры |
| GET | `/api/listings` | Поиск: `category, sub, q, condition, city, price_min/max, motor_power_min/max, battery_min/max, speed_min/max, battery_type, has_installment, is_original, no_license, has_epts, pedals, sort, page` → `{ items, total, page, pageSize }` |
| GET | `/api/listings/facets` | Те же параметры → счётчики по каждому значению фильтров |
| GET | `/api/listings/[id]` | Объявление (неактивные — только владельцу/админу) |
| POST | `/api/listings` | Создание (продавец) |
| PATCH | `/api/listings/[id]` | `{ data }` — редактирование, `{ status: "archived" \| "moderation" }` — архив/возврат |
| DELETE | `/api/listings/[id]` | Удаление |
| POST | `/api/listings/[id]/verify` | Заявка на проверку оригинальности (S/N, VIN, сертификат) |
| GET | `/api/sellers/[id]` | Публичный профиль продавца |
| GET/POST | `/api/sellers/me/verification` | Статус / заявка на верификацию продавца |
| POST | `/api/installments/apply` | Заявка на рассрочку → статус `created` |
| POST | `/api/webhooks/bank/[bankId]` | Webhook банка (заглушка, заголовок `X-Bank-Secret`) |
| POST | `/api/uploads` | Загрузка файлов (multipart, поле `files`) |
| POST | `/api/register` | Регистрация |
| POST | `/api/admin/listings/[id]` | `approve / reject / approve_original / reject_original` |
| POST | `/api/admin/sellers/[id]` | `approve / reject` верификации продавца |
| * | `/api/auth/[...nextauth]` | NextAuth |

Пример: `GET /api/listings?category=elektroskutery&condition=new,discounted&motor_power_min=1000&sort=price_asc`.
Множественные значения передаются через запятую. Ссылку каталога можно шарить — все фильтры живут в URL.

Пример webhook'а банка:

```bash
curl -X POST localhost:3000/api/webhooks/bank/belkredit \
  -H 'X-Bank-Secret: dev-bank-secret' -H 'Content-Type: application/json' \
  -d '{"applicationId":"<id заявки>","status":"approved","externalId":"BANK-123"}'
```

## Как устроены фильтры

1. `CatalogView` читает query-параметры → кладёт их в Zustand-стор (`lib/store/filters.ts`).
2. Действия пользователя меняют стор → эффект записывает query-строку обратно в URL (`router.replace`).
3. TanStack Query запрашивает `/api/listings` и `/api/listings/facets` по ключу «строка фильтров».
4. Фасеты считаются в `lib/search.ts`: для каждой группы фильтров берётся `WHERE` **без этой группы**, поэтому счётчик
   показывает, сколько товаров будет, если выбрать значение. Диапазоны считаются одним запросом через `COUNT(*) FILTER (…)`.

Цена в фильтре всегда в BYN; переключатель BYN/USD в шапке меняет только отображение цен.

## Что осталось заглушками

| Что | Сейчас | Что сделать в проде |
|---|---|---|
| Интеграция с банками | Заявка сохраняется со статусом `created`, статусы меняет webhook с общим секретом | API банков, HMAC-подпись, очередь отправки, ретраи |
| Хранение файлов | `/public/uploads` на диске сервера | S3/MinIO + presigned URL, ресайз и WebP-превью |
| Поиск | SQL (Prisma `$queryRaw`) + GIN-индекс | Elasticsearch/OpenSearch: заменить реализацию `searchListings`/`getFacets` в `lib/search.ts` |
| Курс валют | Константа `NEXT_PUBLIC_USD_RATE` | Ежедневная загрузка курса из API НБРБ |
| Чат с продавцом | Кнопка с уведомлением | WebSocket-чат или интеграция с мессенджерами |
| Проверка оригинальности | Ручная проверка модератором | Сверка серийников с базами производителей/дилеров |
| Рейтинг продавца | Значения из сида | Отзывы покупателей |
| Демо-фото | `picsum.photos` (нужен интернет) | Фото продавцов |

Также в MVP не реализованы: восстановление пароля, подтверждение email, избранное, уведомления и оплата продвижения.
