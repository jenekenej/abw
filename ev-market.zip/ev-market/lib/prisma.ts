import { PrismaClient } from "@prisma/client";

// Единый экземпляр PrismaClient: в dev-режиме Next.js перезагружает модули,
// поэтому кешируем клиент в globalThis, чтобы не плодить подключения.
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

export const prisma: PrismaClient =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["warn", "error"] : ["error"],
  });

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = prisma;
}
