// Модель фильтров каталога и её (де)сериализация в URL query-параметры.
// Модуль изоморфный: используется и в API (сервер), и в Zustand-сторе (клиент).

import {
  BATTERY_TYPES,
  CITIES,
  CONDITIONS,
  SORT_OPTIONS,
  type BatteryType,
  type ConditionValue,
  type SortValue,
} from "./constants";

export interface ListingFilters {
  category: string | null; // slug категории
  sub: string | null; // slug подкатегории
  q: string | null; // текстовый поиск
  priceMin: number | null;
  priceMax: number | null;
  cities: string[];
  conditions: ConditionValue[];
  isOriginal: boolean;
  hasInstallment: boolean;
  motorPowerMin: number | null;
  motorPowerMax: number | null;
  batteryMin: number | null;
  batteryMax: number | null;
  speedMin: number | null;
  speedMax: number | null;
  batteryTypes: BatteryType[];
  noLicense: boolean;
  hasEpts: boolean;
  pedals: boolean;
  sort: SortValue;
  page: number;
}

export const EMPTY_FILTERS: ListingFilters = {
  category: null,
  sub: null,
  q: null,
  priceMin: null,
  priceMax: null,
  cities: [],
  conditions: [],
  isOriginal: false,
  hasInstallment: false,
  motorPowerMin: null,
  motorPowerMax: null,
  batteryMin: null,
  batteryMax: null,
  speedMin: null,
  speedMax: null,
  batteryTypes: [],
  noLicense: false,
  hasEpts: false,
  pedals: false,
  sort: "date",
  page: 1,
};

/** Минимальный интерфейс, совместимый с URLSearchParams и ReadonlyURLSearchParams. */
interface ParamsReader {
  get(name: string): string | null;
}

function num(value: string | null): number | null {
  if (value === null || value.trim() === "") return null;
  const n = Number(value);
  return Number.isFinite(n) && n >= 0 ? n : null;
}

function flag(value: string | null): boolean {
  return value === "1" || value === "true";
}

/** Список через запятую с отбором только допустимых значений. */
function list<T extends string>(value: string | null, allowed: readonly T[]): T[] {
  if (!value) return [];
  const allowedSet = new Set<string>(allowed);
  return value
    .split(",")
    .map((v) => v.trim())
    .filter((v): v is T => allowedSet.has(v));
}

const CONDITION_VALUES: readonly ConditionValue[] = CONDITIONS.map((c) => c.value);
const SORT_VALUES: readonly SortValue[] = SORT_OPTIONS.map((s) => s.value);

function isSort(value: string | null): value is SortValue {
  return value !== null && (SORT_VALUES as readonly string[]).includes(value);
}

export function parseFilters(params: ParamsReader): ListingFilters {
  const page = num(params.get("page"));
  const sort = params.get("sort");
  return {
    category: params.get("category"),
    sub: params.get("sub"),
    q: params.get("q")?.trim() || null,
    priceMin: num(params.get("price_min")),
    priceMax: num(params.get("price_max")),
    cities: list(params.get("city"), CITIES),
    conditions: list(params.get("condition"), CONDITION_VALUES),
    isOriginal: flag(params.get("is_original")),
    hasInstallment: flag(params.get("has_installment")),
    motorPowerMin: num(params.get("motor_power_min")),
    motorPowerMax: num(params.get("motor_power_max")),
    batteryMin: num(params.get("battery_min")),
    batteryMax: num(params.get("battery_max")),
    speedMin: num(params.get("speed_min")),
    speedMax: num(params.get("speed_max")),
    batteryTypes: list(params.get("battery_type"), BATTERY_TYPES),
    noLicense: flag(params.get("no_license")),
    hasEpts: flag(params.get("has_epts")),
    pedals: flag(params.get("pedals")),
    sort: isSort(sort) ? sort : "date",
    page: page !== null && page >= 1 ? Math.floor(page) : 1,
  };
}

/**
 * Сериализация фильтров в query-строку. Пустые значения опускаются,
 * чтобы ссылки были короткими и их было удобно шарить.
 * @param withCategory — включать ли category/sub (на страницах категорий они в пути).
 */
export function filtersToSearchParams(f: ListingFilters, withCategory = true): URLSearchParams {
  const p = new URLSearchParams();
  const setNum = (key: string, v: number | null) => {
    if (v !== null) p.set(key, String(v));
  };
  const setFlag = (key: string, v: boolean) => {
    if (v) p.set(key, "1");
  };
  const setList = (key: string, v: readonly string[]) => {
    if (v.length > 0) p.set(key, v.join(","));
  };

  if (withCategory && f.category) p.set("category", f.category);
  if (withCategory && f.sub) p.set("sub", f.sub);
  if (f.q) p.set("q", f.q);
  setNum("price_min", f.priceMin);
  setNum("price_max", f.priceMax);
  setList("city", f.cities);
  setList("condition", f.conditions);
  setFlag("is_original", f.isOriginal);
  setFlag("has_installment", f.hasInstallment);
  setNum("motor_power_min", f.motorPowerMin);
  setNum("motor_power_max", f.motorPowerMax);
  setNum("battery_min", f.batteryMin);
  setNum("battery_max", f.batteryMax);
  setNum("speed_min", f.speedMin);
  setNum("speed_max", f.speedMax);
  setList("battery_type", f.batteryTypes);
  setFlag("no_license", f.noLicense);
  setFlag("has_epts", f.hasEpts);
  setFlag("pedals", f.pedals);
  if (f.sort !== "date") p.set("sort", f.sort);
  if (f.page > 1) p.set("page", String(f.page));
  return p;
}

/** Количество активных фильтров — для кнопки «Фильтры (N)». Сортировка и страница не считаются. */
export function countActiveFilters(f: ListingFilters): number {
  let n = 0;
  if (f.priceMin !== null || f.priceMax !== null) n++;
  if (f.cities.length) n++;
  if (f.conditions.length) n++;
  if (f.isOriginal) n++;
  if (f.hasInstallment) n++;
  if (f.motorPowerMin !== null || f.motorPowerMax !== null) n++;
  if (f.batteryMin !== null || f.batteryMax !== null) n++;
  if (f.speedMin !== null || f.speedMax !== null) n++;
  if (f.batteryTypes.length) n++;
  if (f.noLicense) n++;
  if (f.hasEpts) n++;
  if (f.pedals) n++;
  return n;
}
