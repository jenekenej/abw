// Поиск и фасеты каталога на чистом SQL (Prisma.$queryRaw).
// Вся логика фильтрации собрана в buildWhere(): при переходе на Elasticsearch
// достаточно заменить реализацию searchListings()/getFacets(), не трогая API и UI.

import { Prisma } from "@prisma/client";
import { prisma } from "./prisma";
import {
  BATTERY_PRESETS,
  MOTOR_POWER_PRESETS,
  PAGE_SIZE,
  SPEED_PRESETS,
  type RangePreset,
} from "./constants";
import type { ListingFilters } from "./filters";
import { listingCardInclude, toListingCard } from "./serialize";
import type { FacetsResponse, ListingsResponse, RangeBucketCount } from "@/types";

/** Группы фильтров. При подсчёте фасета группа исключается из WHERE,
 *  чтобы пользователь видел, сколько товаров даст выбор другого значения. */
type FilterGroup =
  | "price"
  | "city"
  | "condition"
  | "original"
  | "installment"
  | "motor"
  | "battery"
  | "speed"
  | "batteryType"
  | "noLicense"
  | "hasEpts"
  | "pedals";

/** Результат разрешения slug'ов категории в ID. */
export interface CategoryScope {
  categoryId: string | null;
  subcategoryId: string | null;
  /** true, если slug указан, но категория не найдена — выдаём пустой результат. */
  notFound: boolean;
}

export async function resolveScope(f: ListingFilters): Promise<CategoryScope> {
  if (!f.category) return { categoryId: null, subcategoryId: null, notFound: false };
  // Категории второго уровня (корень — «Электротранспорт»)
  const category = await prisma.category.findFirst({
    where: { slug: f.category, parent: { parentId: null } },
    select: { id: true },
  });
  if (!category) return { categoryId: null, subcategoryId: null, notFound: true };
  if (!f.sub) return { categoryId: category.id, subcategoryId: null, notFound: false };
  const sub = await prisma.category.findFirst({
    where: { slug: f.sub, parentId: category.id },
    select: { id: true },
  });
  if (!sub) return { categoryId: category.id, subcategoryId: null, notFound: true };
  return { categoryId: category.id, subcategoryId: sub.id, notFound: false };
}

/** Числовое значение характеристики из JSONB. */
function numAttr(code: string): Prisma.Sql {
  return Prisma.sql`(l.attrs->>${code})::numeric`;
}

/** Булев атрибут через оператор @> — использует GIN-индекс jsonb_path_ops. */
function boolAttr(code: string): Prisma.Sql {
  return Prisma.sql`l.attrs @> ${JSON.stringify({ [code]: true })}::jsonb`;
}

function rangeConds(expr: Prisma.Sql, min: number | null, max: number | null): Prisma.Sql[] {
  const conds: Prisma.Sql[] = [];
  if (min !== null) conds.push(Prisma.sql`${expr} >= ${min}`);
  if (max !== null) conds.push(Prisma.sql`${expr} <= ${max}`);
  return conds;
}

/** Собирает WHERE по фильтрам, опционально исключая одну группу (для фасетов). */
function buildWhere(f: ListingFilters, scope: CategoryScope, exclude?: FilterGroup): Prisma.Sql {
  const conds: Prisma.Sql[] = [Prisma.sql`l.status = 'active'`];
  const use = (g: FilterGroup) => g !== exclude;

  if (scope.notFound) conds.push(Prisma.sql`FALSE`);
  if (scope.categoryId) conds.push(Prisma.sql`l."categoryId" = ${scope.categoryId}`);
  if (scope.subcategoryId) conds.push(Prisma.sql`l."subcategoryId" = ${scope.subcategoryId}`);

  if (f.q) {
    const like = `%${f.q.replace(/[%_\\]/g, "\\$&")}%`;
    conds.push(Prisma.sql`(l.title ILIKE ${like} OR l.description ILIKE ${like})`);
  }
  if (use("price")) conds.push(...rangeConds(Prisma.sql`l."priceByn"`, f.priceMin, f.priceMax));
  if (use("city") && f.cities.length) {
    conds.push(Prisma.sql`l.city IN (${Prisma.join(f.cities)})`);
  }
  if (use("condition") && f.conditions.length) {
    conds.push(Prisma.sql`l.condition::text IN (${Prisma.join(f.conditions)})`);
  }
  if (use("original") && f.isOriginal) conds.push(Prisma.sql`l."originalVerified" = TRUE`);
  if (use("installment") && f.hasInstallment) conds.push(Prisma.sql`l."hasInstallment" = TRUE`);
  if (use("motor")) conds.push(...rangeConds(numAttr("motor_power_w"), f.motorPowerMin, f.motorPowerMax));
  if (use("battery")) conds.push(...rangeConds(numAttr("battery_capacity_ah"), f.batteryMin, f.batteryMax));
  if (use("speed")) conds.push(...rangeConds(numAttr("max_speed_kmh"), f.speedMin, f.speedMax));
  if (use("batteryType") && f.batteryTypes.length) {
    conds.push(Prisma.sql`l.attrs->>'battery_type' IN (${Prisma.join(f.batteryTypes)})`);
  }
  if (use("noLicense") && f.noLicense) conds.push(boolAttr("no_license"));
  if (use("hasEpts") && f.hasEpts) conds.push(boolAttr("has_epts"));
  if (use("pedals") && f.pedals) conds.push(boolAttr("pedals"));

  return Prisma.sql`WHERE ${Prisma.join(conds, " AND ")}`;
}

function orderBy(sort: ListingFilters["sort"]): Prisma.Sql {
  switch (sort) {
    case "price_asc":
      return Prisma.sql`ORDER BY l."priceByn" ASC, l."createdAt" DESC`;
    case "price_desc":
      return Prisma.sql`ORDER BY l."priceByn" DESC, l."createdAt" DESC`;
    case "popular":
      return Prisma.sql`ORDER BY l.views DESC, l."createdAt" DESC`;
    default:
      return Prisma.sql`ORDER BY COALESCE(l."publishedAt", l."createdAt") DESC`;
  }
}

export async function searchListings(f: ListingFilters): Promise<ListingsResponse> {
  const scope = await resolveScope(f);
  const where = buildWhere(f, scope);
  const offset = (f.page - 1) * PAGE_SIZE;

  const [rows, countRows] = await Promise.all([
    prisma.$queryRaw<{ id: string }[]>`
      SELECT l.id FROM "Listing" l ${where} ${orderBy(f.sort)}
      LIMIT ${PAGE_SIZE} OFFSET ${offset}`,
    prisma.$queryRaw<{ count: number }[]>`SELECT COUNT(*)::int AS count FROM "Listing" l ${where}`,
  ]);

  const ids = rows.map((r) => r.id);
  const listings = await prisma.listing.findMany({
    where: { id: { in: ids } },
    include: listingCardInclude,
  });
  // findMany не сохраняет порядок — восстанавливаем порядок из SQL-сортировки
  const byId = new Map(listings.map((l) => [l.id, l]));
  const items = ids.flatMap((id) => {
    const l = byId.get(id);
    return l ? [toListingCard(l)] : [];
  });

  return { items, total: countRows[0]?.count ?? 0, page: f.page, pageSize: PAGE_SIZE };
}

// ---------- Фасеты ----------

async function countBy(column: Prisma.Sql, where: Prisma.Sql): Promise<Record<string, number>> {
  const rows = await prisma.$queryRaw<{ key: string | null; count: number }[]>`
    SELECT ${column} AS key, COUNT(*)::int AS count FROM "Listing" l ${where} GROUP BY 1`;
  const result: Record<string, number> = {};
  for (const r of rows) if (r.key !== null) result[r.key] = r.count;
  return result;
}

async function countWith(where: Prisma.Sql, extra: Prisma.Sql): Promise<number> {
  const rows = await prisma.$queryRaw<{ count: number }[]>`
    SELECT COUNT(*)::int AS count FROM "Listing" l ${where} AND ${extra}`;
  return rows[0]?.count ?? 0;
}

/** Счётчики по предустановленным диапазонам одним запросом через COUNT(*) FILTER. */
async function countBuckets(
  expr: Prisma.Sql,
  presets: RangePreset[],
  where: Prisma.Sql,
): Promise<RangeBucketCount[]> {
  const columns = presets.map((p, i) => {
    const conds = rangeConds(expr, p.min, p.max);
    return Prisma.sql`COUNT(*) FILTER (WHERE ${Prisma.join(conds, " AND ")})::int AS ${Prisma.raw(`b${i}`)}`;
  });
  const rows = await prisma.$queryRaw<Record<string, number>[]>`
    SELECT ${Prisma.join(columns)} FROM "Listing" l ${where}`;
  const row = rows[0] ?? {};
  return presets.map((p, i) => ({ ...p, count: row[`b${i}`] ?? 0 }));
}

export async function getFacets(f: ListingFilters): Promise<FacetsResponse> {
  const scope = await resolveScope(f);
  const w = (exclude?: FilterGroup) => buildWhere(f, scope, exclude);

  const [
    totalRows,
    priceRows,
    condition,
    city,
    batteryType,
    isOriginal,
    hasInstallment,
    noLicense,
    hasEpts,
    pedals,
    motorPower,
    battery,
    speed,
  ] = await Promise.all([
    prisma.$queryRaw<{ count: number }[]>`SELECT COUNT(*)::int AS count FROM "Listing" l ${w()}`,
    prisma.$queryRaw<{ min: number | null; max: number | null }[]>`
      SELECT MIN(l."priceByn")::float AS min, MAX(l."priceByn")::float AS max
      FROM "Listing" l ${w("price")}`,
    countBy(Prisma.sql`l.condition::text`, w("condition")),
    countBy(Prisma.sql`l.city`, w("city")),
    countBy(Prisma.sql`l.attrs->>'battery_type'`, w("batteryType")),
    countWith(w("original"), Prisma.sql`l."originalVerified" = TRUE`),
    countWith(w("installment"), Prisma.sql`l."hasInstallment" = TRUE`),
    countWith(w("noLicense"), boolAttr("no_license")),
    countWith(w("hasEpts"), boolAttr("has_epts")),
    countWith(w("pedals"), boolAttr("pedals")),
    countBuckets(numAttr("motor_power_w"), MOTOR_POWER_PRESETS, w("motor")),
    countBuckets(numAttr("battery_capacity_ah"), BATTERY_PRESETS, w("battery")),
    countBuckets(numAttr("max_speed_kmh"), SPEED_PRESETS, w("speed")),
  ]);

  return {
    total: totalRows[0]?.count ?? 0,
    price: { min: priceRows[0]?.min ?? 0, max: priceRows[0]?.max ?? 0 },
    condition,
    city,
    isOriginal,
    hasInstallment,
    motorPower,
    battery,
    speed,
    batteryType,
    noLicense,
    hasEpts,
    pedals,
  };
}
