// Бизнес-логика сохранения объявлений: валидация характеристик, пересчёт цены в BYN,
// синхронизация бейджей и предложений рассрочки, журнал модерации.

import { Prisma, type Condition, type ListingStatus } from "@prisma/client";
import { prisma } from "./prisma";
import { USD_RATE } from "./utils";
import { validateAttrs, type ListingInput } from "./validation";
import { toAttributeDTO } from "./serialize";

export class ListingValidationError extends Error {
  constructor(
    message: string,
    public readonly details: Record<string, string>,
  ) {
    super(message);
  }
}

/** Коды бейджей, которые вычисляются из полей объявления. */
export function computeBadgeCodes(l: {
  condition: Condition;
  originalVerified: boolean;
  hasInstallment: boolean;
}): string[] {
  const codes: string[] = [];
  if (l.originalVerified) codes.push("original");
  if (l.hasInstallment) codes.push("installment");
  if (l.condition === "new") codes.push("new");
  if (l.condition === "discounted") codes.push("discounted");
  return codes;
}

/** Перезаписывает связи ListingBadge по текущему состоянию объявления. */
export async function syncBadges(tx: Prisma.TransactionClient, listingId: string): Promise<void> {
  const listing = await tx.listing.findUniqueOrThrow({
    where: { id: listingId },
    select: { condition: true, originalVerified: true, hasInstallment: true },
  });
  const badges = await tx.badge.findMany({ where: { code: { in: computeBadgeCodes(listing) } } });
  await tx.listingBadge.deleteMany({ where: { listingId } });
  if (badges.length) {
    await tx.listingBadge.createMany({ data: badges.map((b) => ({ listingId, badgeId: b.id })) });
  }
}

const toByn = (amount: number, currency: "BYN" | "USD"): number =>
  Math.round((currency === "USD" ? amount * USD_RATE : amount) * 100) / 100;

/** Создание (existingId не задан) или редактирование объявления. */
export async function saveListing(
  sellerId: string,
  actorId: string,
  input: ListingInput,
  existingId?: string,
): Promise<{ id: string; status: ListingStatus }> {
  const category = await prisma.category.findUnique({
    where: { id: input.categoryId },
    include: { attributes: true, children: { select: { id: true } } },
  });
  if (!category || category.parentId === null) {
    throw new ListingValidationError("Категория не найдена", { categoryId: "Категория не найдена" });
  }
  if (input.subcategoryId && !category.children.some((c) => c.id === input.subcategoryId)) {
    throw new ListingValidationError("Подкатегория не найдена", { subcategoryId: "Подкатегория не найдена" });
  }

  const attrsCheck = validateAttrs(category.attributes.map(toAttributeDTO), input.attrs);
  if (!attrsCheck.ok) {
    const details: Record<string, string> = {};
    for (const [k, v] of Object.entries(attrsCheck.errors)) details[`attrs.${k}`] = v;
    throw new ListingValidationError("Ошибка в характеристиках", details);
  }

  const banks = await prisma.bank.findMany({
    where: { id: { in: input.installmentOffers.map((o) => o.bankId) } },
  });
  const bankRate = new Map(banks.map((b) => [b.id, b.defaultRate]));

  const autoApprove = process.env.AUTO_APPROVE_LISTINGS === "true";
  const status: ListingStatus = autoApprove ? "active" : "moderation";

  const data = {
    title: input.title,
    description: input.description,
    price: new Prisma.Decimal(input.price),
    currency: input.currency,
    priceByn: new Prisma.Decimal(toByn(input.price, input.currency)),
    oldPriceByn: input.oldPrice ? new Prisma.Decimal(toByn(input.oldPrice, input.currency)) : null,
    city: input.city,
    condition: input.condition,
    discountReason: input.condition === "discounted" ? (input.discountReason ?? null) : null,
    attrs: attrsCheck.value,
    isOriginal: input.isOriginal,
    serialNumber: input.serialNumber || null,
    vin: input.vin || null,
    certificateUrl: input.certificateUrl || null,
    hasInstallment: input.hasInstallment && input.installmentOffers.length > 0,
    status,
    publishedAt: autoApprove ? new Date() : null,
    category: { connect: { id: category.id } },
    subcategory: input.subcategoryId ? { connect: { id: input.subcategoryId } } : { disconnect: true },
  } satisfies Prisma.ListingUpdateInput;

  return prisma.$transaction(async (tx) => {
    let id: string;
    if (existingId) {
      // При редактировании оригинальность нужно подтвердить заново, если поменялись номера
      const prev = await tx.listing.findUniqueOrThrow({ where: { id: existingId } });
      const sameIds = prev.serialNumber === data.serialNumber && prev.vin === data.vin;
      await tx.listing.update({
        where: { id: existingId },
        data: { ...data, originalVerified: input.isOriginal && sameIds ? prev.originalVerified : false },
      });
      id = existingId;
      await tx.listingMedia.deleteMany({ where: { listingId: id } });
      await tx.installmentOffer.deleteMany({ where: { listingId: id } });
    } else {
      const { subcategory: _sub, ...createData } = data;
      const created = await tx.listing.create({
        data: {
          ...createData,
          subcategory: input.subcategoryId ? { connect: { id: input.subcategoryId } } : undefined,
          seller: { connect: { id: sellerId } },
        },
      });
      id = created.id;
    }

    if (input.media.length) {
      await tx.listingMedia.createMany({
        data: input.media.map((m, i) => ({ listingId: id, url: m.url, kind: m.kind, sortOrder: i })),
      });
    }
    if (data.hasInstallment) {
      await tx.installmentOffer.createMany({
        data: input.installmentOffers
          .filter((o) => bankRate.has(o.bankId))
          .map((o) => ({
            listingId: id,
            bankId: o.bankId,
            rate: bankRate.get(o.bankId) ?? 0,
            terms: [...o.terms].sort((a, b) => a - b),
            minDownPercent: o.minDownPercent,
          })),
      });
    }
    await syncBadges(tx, id);
    await tx.moderationLog.create({
      data: {
        listingId: id,
        actorId,
        action: autoApprove ? "approved" : "submitted",
        comment: autoApprove ? "Автоматическое одобрение (AUTO_APPROVE_LISTINGS)" : null,
      },
    });
    return { id, status };
  });
}
