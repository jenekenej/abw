// Загрузка дерева категорий (второй уровень + подкатегории + атрибуты).

import { prisma } from "./prisma";
import { toAttributeDTO } from "./serialize";
import type { CategoryDTO } from "@/types";

export async function getCategoryTree(): Promise<CategoryDTO[]> {
  const categories = await prisma.category.findMany({
    where: { parent: { parentId: null } }, // дети корня «Электротранспорт»
    orderBy: { sortOrder: "asc" },
    include: {
      children: { orderBy: { sortOrder: "asc" }, select: { id: true, slug: true, name: true } },
      attributes: { orderBy: { sortOrder: "asc" } },
    },
  });
  return categories.map((c) => ({
    id: c.id,
    slug: c.slug,
    name: c.name,
    isVehicle: c.isVehicle,
    children: c.children,
    attributes: c.attributes.map(toAttributeDTO),
  }));
}

export async function getCategoryBySlug(slug: string): Promise<CategoryDTO | null> {
  const tree = await getCategoryTree();
  return tree.find((c) => c.slug === slug) ?? null;
}
