// Справочники, общие для клиента и сервера.

export const CITIES = [
  "Минск",
  "Брест",
  "Витебск",
  "Гомель",
  "Гродно",
  "Могилёв",
  "Бобруйск",
  "Барановичи",
  "Борисов",
  "Пинск",
  "Орша",
  "Мозырь",
  "Лида",
  "Солигорск",
  "Молодечно",
] as const;

export const CONDITIONS = [
  { value: "new", label: "Новый" },
  { value: "used", label: "Б/У" },
  { value: "discounted", label: "С уценкой" },
] as const;

export type ConditionValue = (typeof CONDITIONS)[number]["value"];

export const CONDITION_LABELS: Record<ConditionValue, string> = {
  new: "Новый",
  used: "Б/У",
  discounted: "С уценкой",
};

export const BATTERY_TYPES = ["Li-Ion", "LiFePO4", "Pb"] as const;
export type BatteryType = (typeof BATTERY_TYPES)[number];

export const INSTALLMENT_TERMS = [3, 6, 12, 24] as const;

/** Описание предустановленного диапазона фильтра. max — включительно, null — без ограничения. */
export interface RangePreset {
  key: string;
  label: string;
  min: number | null;
  max: number | null;
}

export const MOTOR_POWER_PRESETS: RangePreset[] = [
  { key: "0-250", label: "до 250 Вт", min: null, max: 250 },
  { key: "250-500", label: "250–500 Вт", min: 250, max: 500 },
  { key: "500-1000", label: "500–1000 Вт", min: 500, max: 1000 },
  { key: "1000-3000", label: "1000–3000 Вт", min: 1000, max: 3000 },
  { key: "3000+", label: "3000+ Вт", min: 3000, max: null },
];

export const BATTERY_PRESETS: RangePreset[] = [
  { key: "0-10", label: "до 10 А·ч", min: null, max: 10 },
  { key: "10-20", label: "10–20 А·ч", min: 10, max: 20 },
  { key: "20-30", label: "20–30 А·ч", min: 20, max: 30 },
  { key: "30-50", label: "30–50 А·ч", min: 30, max: 50 },
  { key: "50+", label: "50+ А·ч", min: 50, max: null },
];

export const SPEED_PRESETS: RangePreset[] = [
  { key: "0-25", label: "до 25 км/ч", min: null, max: 25 },
  { key: "25-45", label: "25–45 км/ч", min: 25, max: 45 },
  { key: "45-60", label: "45–60 км/ч", min: 45, max: 60 },
  { key: "60+", label: "60+ км/ч", min: 60, max: null },
];

/** Границы слайдеров. */
export const SLIDER_BOUNDS = {
  price: { min: 0, max: 60000, step: 100 },
  motorPower: { min: 0, max: 10000, step: 50 },
  battery: { min: 0, max: 100, step: 1 },
} as const;

export const SORT_OPTIONS = [
  { value: "date", label: "Сначала новые" },
  { value: "price_asc", label: "Сначала дешёвые" },
  { value: "price_desc", label: "Сначала дорогие" },
  { value: "popular", label: "По популярности" },
] as const;

export type SortValue = (typeof SORT_OPTIONS)[number]["value"];

export const PAGE_SIZE = 12;

/** Слаг категории электровелосипедов — для неё показываем фильтр «Педали». */
export const EBIKE_SLUG = "elektrovelosipedy";

export const LISTING_STATUS_LABELS: Record<string, string> = {
  draft: "Черновик",
  moderation: "На модерации",
  active: "Активно",
  rejected: "Отклонено",
  archived: "Архив",
};
