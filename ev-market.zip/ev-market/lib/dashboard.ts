// Серверные хелперы личного кабинета продавца.

import { redirect } from "next/navigation";
import { getSessionUser, type SessionUser } from "./auth";
import { prisma } from "./prisma";
import { USD_RATE } from "./utils";
import type { ListingInput } from "./validation";
import type { BankOption } from "@/components/dashboard/listing-wizard";
import { parseAttrs } from "./serialize";

/** Текущий продавец или редирект на вход. */
export async function requireSeller(): Promise<SessionUser & { sellerId: string }> {
  const user = await getSessionUser();
  if (!user || user.role !== "seller" || !user.sellerId) redirect("/login?callbackUrl=/dashboard");
  return { ...user, sellerId: user.sellerId };
}

export async function getBankOptions(): Promise<BankOption[]> {
  return prisma.bank.findMany({ orderBy: { name: "asc" }, select: { id: true, name: true, defaultRate: true } });
}

/** Значения формы для редактирования объявления. */
export async function getListingFormValues(listingId: string, sellerId: string): Promise<ListingInput | null> {
  const l = await prisma.listing.findFirst({
    where: { id: listingId, sellerId },
    include: { media: { orderBy: { sortOrder: "asc" } }, installmentOffers: true },
  });
  if (!l) return null;
  const oldPriceByn = l.oldPriceByn?.toNumber() ?? null;
  return {
    categoryId: l.categoryId,
    subcategoryId: l.subcategoryId,
    title: l.title,
    description: l.description,
    price: l.price.toNumber(),
    currency: l.currency,
    city: l.city as ListingInput["city"],
    condition: l.condition,
    // Старая цена хранится в BYN — переводим в валюту объявления
    oldPrice: oldPriceByn === null ? null : l.currency === "USD" ? Math.round(oldPriceByn / USD_RATE) : oldPriceByn,
    discountReason: l.discountReason,
    attrs: parseAttrs(l.attrs),
    media: l.media.map((m) => ({ url: m.url, kind: m.kind === "video" ? "video" : "image" })),
    isOriginal: l.isOriginal,
    serialNumber: l.serialNumber,
    vin: l.vin,
    certificateUrl: l.certificateUrl,
    hasInstallment: l.hasInstallment,
    installmentOffers: l.installmentOffers.map((o) => ({ bankId: o.bankId, terms: o.terms, minDownPercent: o.minDownPercent })),
  };
}
