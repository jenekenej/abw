import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

/** Склейка Tailwind-классов с разрешением конфликтов (стандарт shadcn/ui). */
export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

export type DisplayCurrency = "BYN" | "USD";

/** Курс BYN за 1 USD. В проде — подтягивать из API НБРБ. */
export const USD_RATE: number = Number(process.env.NEXT_PUBLIC_USD_RATE ?? "3.27") || 3.27;

/** Форматирование цены, хранящейся в BYN, в выбранной валюте. */
export function formatPrice(priceByn: number, currency: DisplayCurrency = "BYN"): string {
  const value = currency === "USD" ? priceByn / USD_RATE : priceByn;
  const formatted = new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 0 }).format(value);
  return currency === "USD" ? `$${formatted}` : `${formatted} р.`;
}

/** Склонение русских существительных: plural(5, ["объявление", "объявления", "объявлений"]). */
export function plural(n: number, forms: readonly [string, string, string]): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return forms[0];
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return forms[1];
  return forms[2];
}

export function formatDate(iso: string): string {
  return new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "long", year: "numeric" }).format(
    new Date(iso),
  );
}

/** Type guard для «простого» объекта. */
export function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
