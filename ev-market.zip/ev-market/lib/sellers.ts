import { prisma } from "./prisma";
import { listingCardInclude, toListingCard } from "./serialize";
import type { ListingCardDTO, SellerPublicDTO } from "@/types";

export interface SellerProfile {
  seller: SellerPublicDTO;
  listings: ListingCardDTO[];
}

export async function getSellerProfile(id: string): Promise<SellerProfile | null> {
  const seller = await prisma.seller.findUnique({
    where: { id },
    include: {
      listings: {
        where: { status: "active" },
        orderBy: { createdAt: "desc" },
        include: listingCardInclude,
      },
    },
  });
  if (!seller) return null;
  return {
    seller: {
      id: seller.id,
      displayName: seller.displayName,
      type: seller.type,
      city: seller.city,
      rating: seller.rating,
      ratingCount: seller.ratingCount,
      verified: seller.verified,
      activeListings: seller.listings.length,
      createdAt: seller.createdAt.toISOString(),
    },
    listings: seller.listings.map(toListingCard),
  };
}
