// Преобразование моделей Prisma в DTO для API/UI.

import { Prisma } from "@prisma/client";
import type {
  AttrValue,
  AttributeDefinitionDTO,
  ListingAttrs,
  ListingCardDTO,
  ListingDetailDTO,
} from "@/types";
import { isRecord } from "./utils";

export const listingCardInclude = {
  media: { orderBy: { sortOrder: "asc" }, take: 1 },
  badges: { include: { badge: true } },
  category: { select: { slug: true, name: true } },
} satisfies Prisma.ListingInclude;

export type ListingWithCard = Prisma.ListingGetPayload<{ include: typeof listingCardInclude }>;

export const listingDetailInclude = {
  media: { orderBy: { sortOrder: "asc" } },
  badges: { include: { badge: true } },
  category: { include: { attributes: { orderBy: { sortOrder: "asc" } } } },
  subcategory: { select: { id: true, slug: true, name: true } },
  installmentOffers: { include: { bank: true } },
  seller: { include: { _count: { select: { listings: { where: { status: "active" } } } } } },
} satisfies Prisma.ListingInclude;

export type ListingWithDetail = Prisma.ListingGetPayload<{ include: typeof listingDetailInclude }>;

function isAttrValue(v: unknown): v is AttrValue {
  return typeof v === "string" || typeof v === "number" || typeof v === "boolean";
}

/** Безопасное чтение JSONB-поля attrs: отбрасываем всё, что не является скаляром. */
export function parseAttrs(value: Prisma.JsonValue): ListingAttrs {
  const result: ListingAttrs = {};
  if (!isRecord(value)) return result;
  for (const [k, v] of Object.entries(value)) {
    if (isAttrValue(v)) result[k] = v;
  }
  return result;
}

const toNum = (d: Prisma.Decimal): number => d.toNumber();

export function toListingCard(l: ListingWithCard): ListingCardDTO {
  return {
    id: l.id,
    title: l.title,
    priceByn: toNum(l.priceByn),
    oldPriceByn: l.oldPriceByn ? toNum(l.oldPriceByn) : null,
    city: l.city,
    condition: l.condition,
    isOriginal: l.isOriginal,
    originalVerified: l.originalVerified,
    hasInstallment: l.hasInstallment,
    imageUrl: l.media[0]?.url ?? null,
    createdAt: l.createdAt.toISOString(),
    attrs: parseAttrs(l.attrs),
    categorySlug: l.category.slug,
    categoryName: l.category.name,
    badges: l.badges.map((b) => ({ code: b.badge.code, name: b.badge.name, color: b.badge.color })),
    status: l.status,
    views: l.views,
  };
}

export function toAttributeDTO(a: {
  code: string;
  name: string;
  type: AttributeDefinitionDTO["type"];
  unit: string | null;
  options: string[];
}): AttributeDefinitionDTO {
  return { code: a.code, name: a.name, type: a.type, unit: a.unit, options: a.options };
}

export function toListingDetail(l: ListingWithDetail): ListingDetailDTO {
  return {
    ...toListingCard({ ...l, media: l.media.slice(0, 1) }),
    description: l.description,
    currency: l.currency,
    price: toNum(l.price),
    discountReason: l.discountReason,
    media: l.media.map((m) => ({ id: m.id, url: m.url, kind: m.kind })),
    category: { id: l.category.id, slug: l.category.slug, name: l.category.name },
    subcategory: l.subcategory,
    attributeDefinitions: l.category.attributes.map(toAttributeDTO),
    serialNumber: l.serialNumber,
    vin: l.vin,
    certificateUrl: l.certificateUrl,
    installmentOffers: l.installmentOffers.map((o) => ({
      bankId: o.bankId,
      bankName: o.bank.name,
      rate: o.rate,
      terms: o.terms,
      minDownPercent: o.minDownPercent,
    })),
    seller: {
      id: l.seller.id,
      displayName: l.seller.displayName,
      type: l.seller.type,
      city: l.seller.city,
      rating: l.seller.rating,
      ratingCount: l.seller.ratingCount,
      verified: l.seller.verified,
      activeListings: l.seller._count.listings,
      createdAt: l.seller.createdAt.toISOString(),
    },
    updatedAt: l.updatedAt.toISOString(),
  };
}
