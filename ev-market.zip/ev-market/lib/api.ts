// Хелперы для Route Handlers.

import { NextResponse } from "next/server";
import type { ZodError } from "zod";
import type { ApiError } from "@/types";

export function jsonError(status: number, error: string, details?: unknown): NextResponse<ApiError> {
  return NextResponse.json({ error, details }, { status });
}

/** Ошибки zod в плоском виде { "path.to.field": "сообщение" } — удобно для форм. */
export function zodDetails(err: ZodError): Record<string, string> {
  const out: Record<string, string> = {};
  for (const issue of err.issues) {
    const key = issue.path.join(".") || "_";
    if (!(key in out)) out[key] = issue.message;
  }
  return out;
}

/** Безопасное чтение JSON-тела запроса. */
export async function readJson(req: Request): Promise<unknown> {
  try {
    return await req.json();
  } catch {
    return null;
  }
}
