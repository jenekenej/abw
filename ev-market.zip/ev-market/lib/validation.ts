// Zod-схемы, общие для форм (react-hook-form) и API-роутов.

import { z } from "zod";
import { CITIES, INSTALLMENT_TERMS } from "./constants";
import type { AttrValue, AttributeDefinitionDTO, ListingAttrs } from "@/types";

// Русские сообщения по умолчанию для стандартных ошибок zod
z.setErrorMap((issue, ctx) => {
  if (issue.code === z.ZodIssueCode.invalid_type) {
    return { message: issue.received === "undefined" ? "Обязательное поле" : "Некорректное значение" };
  }
  if (issue.code === z.ZodIssueCode.invalid_enum_value) return { message: "Недопустимое значение" };
  return { message: ctx.defaultError };
});

const cityEnum = z.enum(CITIES, { errorMap: () => ({ message: "Выберите город" }) });

// ---------- Регистрация ----------

export const registerSchema = z
  .object({
    name: z.string().trim().min(2, "Минимум 2 символа"),
    email: z.string().trim().email("Некорректный email"),
    password: z.string().min(6, "Минимум 6 символов"),
    role: z.enum(["buyer", "seller"]),
    phone: z.string().trim().optional(),
    city: z.string().optional(),
    sellerType: z.enum(["individual", "dealer"]).optional(),
  })
  .superRefine((v, ctx) => {
    if (v.role !== "seller") return;
    if (!v.phone || !/^\+375\d{9}$/.test(v.phone.replace(/[\s()-]/g, ""))) {
      ctx.addIssue({ code: "custom", path: ["phone"], message: "Формат: +375 XX XXX-XX-XX" });
    }
    if (!v.city || !(CITIES as readonly string[]).includes(v.city)) {
      ctx.addIssue({ code: "custom", path: ["city"], message: "Выберите город" });
    }
  });

export type RegisterInput = z.infer<typeof registerSchema>;

// ---------- Объявление ----------

const attrValue = z.union([z.string(), z.number(), z.boolean()]);

export const installmentOfferInputSchema = z.object({
  bankId: z.string().min(1),
  terms: z
    .array(z.number().int())
    .min(1, "Выберите хотя бы один срок")
    .refine((t) => t.every((x) => (INSTALLMENT_TERMS as readonly number[]).includes(x)), "Недопустимый срок"),
  minDownPercent: z.number().int().min(0).max(50),
});

export const listingInputSchema = z
  .object({
    categoryId: z.string().min(1, "Выберите категорию"),
    subcategoryId: z.string().nullable().optional(),
    title: z.string().trim().min(5, "Минимум 5 символов").max(120, "Максимум 120 символов"),
    description: z.string().trim().min(20, "Минимум 20 символов").max(5000),
    price: z.number({ invalid_type_error: "Укажите цену" }).positive("Цена должна быть больше 0"),
    currency: z.enum(["BYN", "USD"]),
    city: cityEnum,
    condition: z.enum(["new", "used", "discounted"]),
    oldPrice: z.number().positive().nullable().optional(),
    discountReason: z.string().trim().max(500).nullable().optional(),
    // undefined допускаем: незаполненные необязательные характеристики из формы
    attrs: z.record(attrValue.optional()),
    media: z
      .array(z.object({ url: z.string().min(1), kind: z.enum(["image", "video"]) }))
      .max(20, "Не более 20 файлов"),
    isOriginal: z.boolean(),
    serialNumber: z.string().trim().max(64).nullable().optional(),
    vin: z.string().trim().max(32).nullable().optional(),
    certificateUrl: z.string().nullable().optional(),
    hasInstallment: z.boolean(),
    installmentOffers: z.array(installmentOfferInputSchema),
  })
  .superRefine((v, ctx) => {
    if (v.condition === "discounted" && !v.discountReason) {
      ctx.addIssue({ code: "custom", path: ["discountReason"], message: "Укажите причину уценки" });
    }
    if (v.oldPrice != null && v.oldPrice <= v.price) {
      ctx.addIssue({ code: "custom", path: ["oldPrice"], message: "Старая цена должна быть выше текущей" });
    }
    if (v.isOriginal && !v.serialNumber && !v.vin) {
      ctx.addIssue({ code: "custom", path: ["serialNumber"], message: "Укажите серийный номер или VIN" });
    }
    if (v.hasInstallment && v.installmentOffers.length === 0) {
      ctx.addIssue({ code: "custom", path: ["installmentOffers"], message: "Выберите хотя бы один банк" });
    }
  });

export type ListingInput = z.infer<typeof listingInputSchema>;

/** Для PATCH — все поля необязательны, кроме того статуса можно менять (архивировать). */
export const listingPatchSchema = z.object({
  data: listingInputSchema.optional(),
  status: z.enum(["archived", "moderation"]).optional(),
});

/**
 * Проверка динамических характеристик по определениям атрибутов категории.
 * Возвращает очищенный объект (только известные коды) или список ошибок.
 */
export function validateAttrs(
  defs: AttributeDefinitionDTO[],
  attrs: Record<string, AttrValue | undefined>,
): { ok: true; value: ListingAttrs } | { ok: false; errors: Record<string, string> } {
  const value: ListingAttrs = {};
  const errors: Record<string, string> = {};
  for (const def of defs) {
    const raw = attrs[def.code];
    if (raw === undefined || raw === "") continue; // характеристики необязательны
    switch (def.type) {
      case "int":
      case "float": {
        const n = typeof raw === "number" ? raw : Number(raw);
        if (!Number.isFinite(n) || n < 0) errors[def.code] = "Ожидается неотрицательное число";
        else if (def.type === "int" && !Number.isInteger(n)) errors[def.code] = "Ожидается целое число";
        else value[def.code] = n;
        break;
      }
      case "bool":
        if (typeof raw !== "boolean") errors[def.code] = "Ожидается да/нет";
        else if (raw) value[def.code] = true; // false не храним — меньше шума в JSONB
        break;
      case "enum":
        if (typeof raw !== "string" || !def.options.includes(raw)) errors[def.code] = "Недопустимое значение";
        else value[def.code] = raw;
        break;
    }
  }
  return Object.keys(errors).length ? { ok: false, errors } : { ok: true, value };
}

// ---------- Рассрочка ----------

export const installmentApplySchema = z.object({
  listingId: z.string().min(1),
  bankId: z.string().min(1),
  termMonths: z
    .number()
    .int()
    .refine((t) => (INSTALLMENT_TERMS as readonly number[]).includes(t), "Недопустимый срок"),
  downPercent: z.number().min(0).max(50),
  fullName: z.string().trim().min(3, "Укажите ФИО"),
  phone: z
    .string()
    .trim()
    .refine((p) => /^\+375\d{9}$/.test(p.replace(/[\s()-]/g, "")), "Формат: +375 XX XXX-XX-XX"),
});

export type InstallmentApplyInput = z.infer<typeof installmentApplySchema>;

// ---------- Верификация продавца ----------

export const sellerVerificationSchema = z.object({
  type: z.enum(["individual", "dealer"]),
  // УНП в Беларуси — 9 цифр
  inn: z.string().trim().regex(/^\d{9}$/, "УНП/ИНН — 9 цифр"),
  docs: z.array(z.string()).min(1, "Загрузите хотя бы один документ"),
});

export type SellerVerificationInput = z.infer<typeof sellerVerificationSchema>;

// ---------- Верификация оригинальности объявления ----------

export const listingVerifySchema = z
  .object({
    serialNumber: z.string().trim().max(64).optional(),
    vin: z.string().trim().max(32).optional(),
    certificateUrl: z.string().optional(),
  })
  .refine((v) => Boolean(v.serialNumber || v.vin), {
    message: "Укажите серийный номер или VIN",
    path: ["serialNumber"],
  });
