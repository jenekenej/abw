"use client";

// Zustand-стор фильтров каталога. Источник истины для UI;
// синхронизация с URL выполняется в components/catalog/catalog-view.tsx.

import { create } from "zustand";
import { EMPTY_FILTERS, type ListingFilters } from "@/lib/filters";

interface FiltersState {
  filters: ListingFilters;
  /** Частичное обновление. Любое изменение, кроме страницы, сбрасывает пагинацию на 1. */
  setFilters: (patch: Partial<ListingFilters>) => void;
  /** Полная замена (при чтении из URL). */
  replace: (filters: ListingFilters) => void;
  /** Сброс фильтров с сохранением категории, поиска и сортировки. */
  reset: () => void;
  /** Переключение значения в массиве (чекбоксы). */
  toggleInList: <K extends "cities" | "conditions" | "batteryTypes">(
    key: K,
    value: ListingFilters[K][number],
  ) => void;
}

export const useFiltersStore = create<FiltersState>((set) => ({
  filters: EMPTY_FILTERS,
  setFilters: (patch) =>
    set((s) => ({ filters: { ...s.filters, ...patch, page: patch.page ?? 1 } })),
  replace: (filters) => set({ filters }),
  reset: () =>
    set((s) => ({
      filters: { ...EMPTY_FILTERS, category: s.filters.category, sub: s.filters.sub, q: s.filters.q, sort: s.filters.sort },
    })),
  toggleInList: (key, value) =>
    set((s) => {
      const current = s.filters[key] as readonly string[];
      const next = current.includes(value) ? current.filter((v) => v !== value) : [...current, value];
      return { filters: { ...s.filters, [key]: next, page: 1 } };
    }),
}));
