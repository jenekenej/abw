"use client";

// Валюта отображения цен (BYN по умолчанию, опционально USD). Сохраняется в localStorage.

import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { DisplayCurrency } from "@/lib/utils";

interface CurrencyState {
  currency: DisplayCurrency;
  setCurrency: (c: DisplayCurrency) => void;
}

export const useCurrencyStore = create<CurrencyState>()(
  persist((set) => ({ currency: "BYN", setCurrency: (currency) => set({ currency }) }), {
    name: "ev-currency",
  }),
);
