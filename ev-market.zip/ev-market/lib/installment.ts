// Расчёт рассрочки по формуле из ТЗ:
// ежемесячный платёж = (цена − взнос) × (1 + ставка × срок / 12) / срок

export interface InstallmentInput {
  price: number; // BYN
  downPayment: number; // BYN
  rate: number; // годовая ставка, 0.12 = 12%
  termMonths: number;
}

export interface InstallmentResult {
  monthlyPayment: number;
  totalPayment: number;
  overpayment: number;
}

const round2 = (n: number): number => Math.round(n * 100) / 100;

export function calcInstallment({ price, downPayment, rate, termMonths }: InstallmentInput): InstallmentResult {
  const principal = Math.max(price - downPayment, 0);
  const total = principal * (1 + (rate * termMonths) / 12);
  const monthly = termMonths > 0 ? total / termMonths : 0;
  return {
    monthlyPayment: round2(monthly),
    totalPayment: round2(total + downPayment),
    overpayment: round2(total - principal),
  };
}
