// Защита разделов: /dashboard — только продавцы, /admin — только администраторы.
import { withAuth } from "next-auth/middleware";

export default withAuth({
  callbacks: {
    authorized: ({ token, req }) => {
      if (!token) return false;
      const path = req.nextUrl.pathname;
      if (path.startsWith("/admin")) return token.role === "admin";
      if (path.startsWith("/dashboard")) return token.role === "seller";
      return true;
    },
  },
  pages: { signIn: "/login" },
});

export const config = { matcher: ["/dashboard/:path*", "/admin/:path*"] };
