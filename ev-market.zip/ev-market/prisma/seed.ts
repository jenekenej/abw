// Сид-скрипт: категории, атрибуты, бейджи, 3 банка-партнёра, админ, покупатель,
// 2 демо-продавца и 20 демо-объявлений. Запуск: `npm run seed`.
// Скрипт идемпотентен: перед заполнением очищает таблицы.

import { PrismaClient, Prisma, type AttributeType, type Condition, type ListingStatus } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

// ---------- Справочники ----------

interface CategorySeed {
  slug: string;
  name: string;
  isVehicle: boolean;
  withPedals?: boolean;
  children: { slug: string; name: string }[];
}

const CATEGORIES: CategorySeed[] = [
  {
    slug: "elektrovelosipedy",
    name: "Электровелосипеды",
    isVehicle: true,
    withPedals: true,
    children: [
      { slug: "gorodskie", name: "Городские" },
      { slug: "gornye", name: "Горные" },
      { slug: "skladnye", name: "Складные" },
    ],
  },
  {
    slug: "elektroskutery",
    name: "Электроскутеры",
    isVehicle: true,
    children: [
      { slug: "gorodskie", name: "Городские" },
      { slug: "sportivnye", name: "Спортивные" },
    ],
  },
  {
    slug: "elektromotocikly",
    name: "Электромотоциклы",
    isVehicle: true,
    children: [
      { slug: "kross", name: "Кроссовые" },
      { slug: "dorozhnye", name: "Дорожные" },
    ],
  },
  { slug: "giroskutery", name: "Гироскутеры", isVehicle: true, children: [] },
  { slug: "monokolesa", name: "Моноколёса", isVehicle: true, children: [] },
  {
    slug: "elektromobili",
    name: "Электромобили",
    isVehicle: true,
    children: [
      { slug: "sedany", name: "Седаны" },
      { slug: "krossovery", name: "Кроссоверы" },
    ],
  },
  {
    slug: "zapchasti-i-aksessuary",
    name: "Запчасти и аксессуары",
    isVehicle: false,
    children: [
      { slug: "akkumulyatory", name: "Аккумуляторы" },
      { slug: "zaryadnye-ustroystva", name: "Зарядные устройства" },
      { slug: "motor-kolesa", name: "Мотор-колёса" },
    ],
  },
];

interface AttrSeed {
  code: string;
  name: string;
  type: AttributeType;
  unit: string | null;
  options?: string[];
}

const BASE_ATTRS: AttrSeed[] = [
  { code: "motor_power_w", name: "Мощность мотор-колеса", type: "int", unit: "Вт" },
  { code: "battery_capacity_ah", name: "Ёмкость аккумулятора", type: "float", unit: "А·ч" },
  { code: "max_speed_kmh", name: "Максимальная скорость", type: "int", unit: "км/ч" },
  { code: "battery_type", name: "Тип аккумулятора", type: "enum", unit: null, options: ["Li-Ion", "LiFePO4", "Pb"] },
  { code: "no_license", name: "Без прав", type: "bool", unit: null },
  { code: "has_epts", name: "С ЭПТС", type: "bool", unit: null },
];
const PEDALS_ATTR: AttrSeed = { code: "pedals", name: "Наличие педалей", type: "bool", unit: null };

const BADGES = [
  { code: "original", name: "Оригинал", color: "blue" },
  { code: "installment", name: "Рассрочка", color: "purple" },
  { code: "new", name: "Новинка", color: "green" },
  { code: "discounted", name: "Уценка", color: "orange" },
];

// Вымышленные банки-партнёры (интеграция — заглушка)
const BANKS = [
  { code: "belkredit", name: "Белкредит Банк (демо)", defaultRate: 0.0 },
  { code: "minskfinance", name: "Минск Финанс (демо)", defaultRate: 0.12 },
  { code: "neman", name: "Нёман Банк (демо)", defaultRate: 0.18 },
];

// ---------- Демо-объявления ----------

type Attrs = Record<string, string | number | boolean>;

interface ListingSeed {
  seller: 0 | 1;
  category: string;
  sub?: string;
  title: string;
  description: string;
  price: number;
  oldPrice?: number;
  city: string;
  condition: Condition;
  discountReason?: string;
  attrs: Attrs;
  original?: "verified" | "claimed";
  serial?: string;
  vin?: string;
  installment?: string[]; // коды банков
  status?: ListingStatus;
  views: number;
  daysAgo: number;
}

const LISTINGS: ListingSeed[] = [
  {
    seller: 0, category: "elektrovelosipedy", sub: "gorodskie",
    title: "Электровелосипед Eltreco Ultra Max 250W",
    description: "Городской электровелосипед с задним мотор-колесом и рамой из алюминия. Запас хода до 60 км, гидравлические тормоза, крылья и багажник в комплекте.",
    price: 3290, city: "Минск", condition: "new",
    attrs: { motor_power_w: 250, battery_capacity_ah: 13, max_speed_kmh: 25, battery_type: "Li-Ion", no_license: true, pedals: true },
    original: "verified", serial: "ELT-UM-2026-00451", installment: ["belkredit", "minskfinance"], views: 412, daysAgo: 1,
  },
  {
    seller: 0, category: "elektrovelosipedy", sub: "gornye",
    title: "Горный электровелосипед Haibike AllMtn 7",
    description: "Двухподвес с мотором Yamaha PW-X3, батарея 720 Вт·ч. Отличный вариант для трейлов и длинных поездок.",
    price: 18900, city: "Минск", condition: "new",
    attrs: { motor_power_w: 250, battery_capacity_ah: 20, max_speed_kmh: 25, battery_type: "Li-Ion", no_license: true, pedals: true },
    original: "verified", serial: "HB-AM7-88213", installment: ["minskfinance", "neman"], views: 980, daysAgo: 3,
  },
  {
    seller: 1, category: "elektrovelosipedy", sub: "skladnye",
    title: "Складной электровелосипед Xiaomi Himo Z20",
    description: "Компактный складной велосипед, помещается в багажник. Пробег около 1500 км, состояние хорошее, родное зарядное.",
    price: 1450, city: "Гомель", condition: "used",
    attrs: { motor_power_w: 250, battery_capacity_ah: 10, max_speed_kmh: 25, battery_type: "Li-Ion", no_license: true, pedals: true },
    views: 156, daysAgo: 5,
  },
  {
    seller: 0, category: "elektrovelosipedy", sub: "gorodskie",
    title: "Электровелосипед Minako F11 Pro 500W (уценка)",
    description: "Фэтбайк с усиленным мотором 500 Вт. Уценка из-за царапины на раме после транспортировки, на ход не влияет. Полная гарантия.",
    price: 2690, oldPrice: 3190, city: "Брест", condition: "discounted", discountReason: "Царапина на раме после транспортировки",
    attrs: { motor_power_w: 500, battery_capacity_ah: 15.6, max_speed_kmh: 40, battery_type: "Li-Ion", no_license: false, pedals: true },
    original: "verified", serial: "MNK-F11P-3321", installment: ["belkredit"], views: 233, daysAgo: 2,
  },
  {
    seller: 0, category: "elektroskutery", sub: "gorodskie",
    title: "Электроскутер Wellness Citycoco 2000W",
    description: "Ситикоко с широкими колёсами, съёмная батарея 20 А·ч. Подходит для города и парков. Документы для регистрации есть.",
    price: 4590, city: "Минск", condition: "new",
    attrs: { motor_power_w: 2000, battery_capacity_ah: 20, max_speed_kmh: 45, battery_type: "Li-Ion", has_epts: true },
    original: "claimed", serial: "WLN-CC2K-1190", installment: ["belkredit", "minskfinance", "neman"], views: 534, daysAgo: 4,
  },
  {
    seller: 0, category: "elektroskutery", sub: "sportivnye",
    title: "Спортивный электроскутер Super Soco CPx",
    description: "Максимальная скорость 90 км/ч, две батареи LiFePO4 по 30 А·ч. Требуются права категории A. ЭПТС оформлен.",
    price: 12900, city: "Минск", condition: "new",
    attrs: { motor_power_w: 4000, battery_capacity_ah: 60, max_speed_kmh: 90, battery_type: "LiFePO4", has_epts: true },
    original: "verified", vin: "LXYJCKL01P0123456", installment: ["minskfinance", "neman"], views: 1290, daysAgo: 6,
  },
  {
    seller: 1, category: "elektroskutery", sub: "gorodskie",
    title: "Электроскутер Yadea G5 на свинцовых АКБ",
    description: "Скутер 2021 года, эксплуатировался один сезон. Свинцовые аккумуляторы держат заряд на 35 км. Торг уместен.",
    price: 1800, city: "Витебск", condition: "used",
    attrs: { motor_power_w: 1200, battery_capacity_ah: 32, max_speed_kmh: 45, battery_type: "Pb", no_license: false },
    views: 87, daysAgo: 10,
  },
  {
    seller: 0, category: "elektroskutery", sub: "sportivnye",
    title: "Электроскутер NIU NQi GTS Sport (витринный образец)",
    description: "Витринный экземпляр, без пробега. Небольшие потёртости на пластике. Литиевая батарея 35 А·ч, приложение NIU.",
    price: 6900, oldPrice: 8200, city: "Гродно", condition: "discounted", discountReason: "Витринный образец, потёртости на пластике",
    attrs: { motor_power_w: 3000, battery_capacity_ah: 35, max_speed_kmh: 70, battery_type: "Li-Ion", has_epts: true },
    original: "verified", serial: "NIU-GTS-77810", installment: ["neman"], views: 640, daysAgo: 7,
  },
  {
    seller: 0, category: "elektromotocikly", sub: "kross",
    title: "Электромотоцикл Surron Light Bee X",
    description: "Кроссовый электромотоцикл, 6 кВт пикового момента. Подвеска DNM, батарея 40 А·ч. Отличный стартовый байк для бездорожья.",
    price: 15800, city: "Минск", condition: "new",
    attrs: { motor_power_w: 6000, battery_capacity_ah: 40, max_speed_kmh: 75, battery_type: "Li-Ion" },
    original: "verified", serial: "SRN-LBX-26-00912", installment: ["belkredit", "minskfinance"], views: 2100, daysAgo: 2,
  },
  {
    seller: 1, category: "elektromotocikly", sub: "kross",
    title: "Talaria Sting R MX4, 2024 г.",
    description: "Пробег 800 км, обслуживался у дилера. Установлена защита батареи и усиленная цепь. Причина продажи — переезд.",
    price: 11500, city: "Гомель", condition: "used",
    attrs: { motor_power_w: 8000, battery_capacity_ah: 45, max_speed_kmh: 85, battery_type: "Li-Ion" },
    original: "claimed", serial: "TLR-MX4-24-5512", views: 760, daysAgo: 8,
  },
  {
    seller: 0, category: "elektromotocikly", sub: "dorozhnye",
    title: "Дорожный электромотоцикл Horwin CR6 Pro",
    description: "Неоклассический дорожный мотоцикл, 6,2 кВт, круиз-контроль, ABS. Оформление ЭПТС в салоне.",
    price: 17400, city: "Могилёв", condition: "new",
    attrs: { motor_power_w: 6200, battery_capacity_ah: 72, max_speed_kmh: 95, battery_type: "Li-Ion", has_epts: true },
    original: "verified", vin: "LH9CR6P0XR1000317", installment: ["minskfinance", "neman"], views: 455, daysAgo: 12,
  },
  {
    seller: 1, category: "giroskutery",
    title: "Гироскутер Smart Balance 10.5\" с app",
    description: "Гироскутер с самобалансом и Bluetooth-колонкой. Колёса 10,5 дюйма, хорошо идёт по асфальту и грунту.",
    price: 420, city: "Бобруйск", condition: "used",
    attrs: { motor_power_w: 700, battery_capacity_ah: 4.4, max_speed_kmh: 15, battery_type: "Li-Ion", no_license: true },
    views: 64, daysAgo: 15,
  },
  {
    seller: 0, category: "giroskutery",
    title: "Гироскутер Ninebot S Max",
    description: "Гироскутер с рулевой стойкой для коленей, максимальная нагрузка 100 кг. Совместим с картинг-набором.",
    price: 2190, city: "Минск", condition: "new",
    attrs: { motor_power_w: 800, battery_capacity_ah: 7.5, max_speed_kmh: 20, battery_type: "Li-Ion", no_license: true },
    original: "verified", serial: "NB-SMAX-55021", installment: ["belkredit"], views: 310, daysAgo: 9,
  },
  {
    seller: 0, category: "monokolesa",
    title: "Моноколесо Begode Master V4 134V",
    description: "Топовое моноколесо с подвеской, батарея 2400 Вт·ч. Подходит для опытных райдеров, запас хода до 150 км.",
    price: 10900, city: "Минск", condition: "new",
    attrs: { motor_power_w: 3500, battery_capacity_ah: 18, max_speed_kmh: 80, battery_type: "Li-Ion", no_license: true },
    original: "verified", serial: "BGD-MV4-11092", installment: ["minskfinance"], views: 870, daysAgo: 4,
  },
  {
    seller: 1, category: "monokolesa",
    title: "Моноколесо InMotion V8F",
    description: "Лёгкое моноколесо для начинающих. Пробег 2300 км, сменена покрышка, есть защита и сумка.",
    price: 1650, city: "Пинск", condition: "used",
    attrs: { motor_power_w: 1000, battery_capacity_ah: 8.6, max_speed_kmh: 38, battery_type: "Li-Ion", no_license: true },
    views: 120, daysAgo: 20,
  },
  {
    seller: 0, category: "elektromobili", sub: "krossovery",
    title: "BYD Song Plus EV, 2025 г.",
    description: "Кроссовер с батареей Blade (LiFePO4) 71,8 кВт·ч, запас хода 520 км. Новый, растаможен, ЭПТС.",
    price: 98500, city: "Минск", condition: "new",
    attrs: { motor_power_w: 150000, battery_capacity_ah: 202, max_speed_kmh: 175, battery_type: "LiFePO4", has_epts: true },
    original: "verified", vin: "LGXCE4CB5S0012345", installment: ["minskfinance", "neman"], views: 3200, daysAgo: 1,
  },
  {
    seller: 1, category: "elektromobili", sub: "sedany",
    title: "Nissan Leaf 40 kWh, 2019 г.",
    description: "Один владелец в РБ, SOH батареи 88%. Зимняя резина в комплекте, свежее ТО. Торг у машины.",
    price: 44000, city: "Гродно", condition: "used",
    attrs: { motor_power_w: 110000, battery_capacity_ah: 115, max_speed_kmh: 144, battery_type: "Li-Ion", has_epts: true },
    original: "claimed", vin: "SJNFAAZE1U0123456", views: 1500, daysAgo: 11,
  },
  {
    seller: 0, category: "zapchasti-i-aksessuary", sub: "akkumulyatory",
    title: "Аккумулятор 48V 20Ah для электровелосипеда",
    description: "Литий-ионная батарея на ячейках Samsung, корпус «дельфин», BMS 30A. Гарантия 12 месяцев.",
    price: 890, city: "Минск", condition: "new",
    attrs: {},
    installment: ["belkredit"], views: 205, daysAgo: 3,
  },
  {
    seller: 0, category: "elektroskutery", sub: "gorodskie",
    title: "Электроскутер Ventus Line 3000W",
    description: "Новый скутер 2026 года, съёмная батарея 60V 40Ah. Отправлен на проверку оригинальности.",
    price: 5200, city: "Минск", condition: "new",
    attrs: { motor_power_w: 3000, battery_capacity_ah: 40, max_speed_kmh: 60, battery_type: "Li-Ion", has_epts: true },
    original: "claimed", serial: "VNT-L3K-0001", status: "moderation", views: 0, daysAgo: 0,
  },
  {
    seller: 1, category: "elektrovelosipedy", sub: "gorodskie",
    title: "Электровелосипед Shulz Chamonix",
    description: "Городской велосипед, пробег 400 км. Педали и трансмиссия Shimano, мотор 250 Вт. Подготовлен к сезону.",
    price: 2100, city: "Гомель", condition: "used",
    attrs: { motor_power_w: 250, battery_capacity_ah: 11.6, max_speed_kmh: 25, battery_type: "Li-Ion", no_license: true, pedals: true },
    status: "moderation", views: 0, daysAgo: 0,
  },
];

function badgeCodes(l: ListingSeed): string[] {
  const codes: string[] = [];
  if (l.original === "verified") codes.push("original");
  if (l.installment?.length) codes.push("installment");
  if (l.condition === "new") codes.push("new");
  if (l.condition === "discounted") codes.push("discounted");
  return codes;
}

async function main(): Promise<void> {
  console.log("Очистка таблиц…");
  await prisma.$transaction([
    prisma.moderationLog.deleteMany(),
    prisma.installmentApplication.deleteMany(),
    prisma.installmentOffer.deleteMany(),
    prisma.listingBadge.deleteMany(),
    prisma.listingMedia.deleteMany(),
    prisma.listing.deleteMany(),
    prisma.badge.deleteMany(),
    prisma.bank.deleteMany(),
    prisma.attributeDefinition.deleteMany(),
    prisma.category.deleteMany(),
    prisma.seller.deleteMany(),
    prisma.user.deleteMany(),
  ]);

  console.log("Категории и атрибуты…");
  const root = await prisma.category.create({
    data: { slug: "elektrotransport", name: "Электротранспорт", isVehicle: true },
  });
  const categoryIds = new Map<string, string>(); // "slug" и "slug/sub" -> id
  for (const [i, c] of CATEGORIES.entries()) {
    const attrs = c.isVehicle ? [...BASE_ATTRS, ...(c.withPedals ? [PEDALS_ATTR] : [])] : [];
    const cat = await prisma.category.create({
      data: {
        slug: c.slug,
        name: c.name,
        isVehicle: c.isVehicle,
        sortOrder: i,
        parentId: root.id,
        attributes: {
          create: attrs.map((a, idx) => ({
            code: a.code,
            name: a.name,
            type: a.type,
            unit: a.unit,
            options: a.options ?? [],
            sortOrder: idx,
          })),
        },
      },
    });
    categoryIds.set(c.slug, cat.id);
    for (const [j, s] of c.children.entries()) {
      const sub = await prisma.category.create({
        data: { slug: s.slug, name: s.name, parentId: cat.id, sortOrder: j, isVehicle: c.isVehicle },
      });
      categoryIds.set(`${c.slug}/${s.slug}`, sub.id);
    }
  }

  console.log("Бейджи и банки…");
  await prisma.badge.createMany({ data: BADGES });
  const badges = await prisma.badge.findMany();
  const badgeId = new Map(badges.map((b) => [b.code, b.id]));
  await prisma.bank.createMany({ data: BANKS });
  const banks = await prisma.bank.findMany();
  const bankByCode = new Map(banks.map((b) => [b.code, b]));

  console.log("Пользователи…");
  const hash = (p: string) => bcrypt.hash(p, 10);
  const admin = await prisma.user.create({
    data: { email: "admin@evmarket.by", name: "Модератор", role: "admin", passwordHash: await hash("admin123") },
  });
  await prisma.user.create({
    data: { email: "buyer@evmarket.by", name: "Иван Покупатель", role: "buyer", passwordHash: await hash("buyer123") },
  });
  const sellerDealer = await prisma.seller.create({
    data: {
      displayName: "ЭлектроМир — официальный дилер",
      type: "dealer",
      city: "Минск",
      phone: "+375291234567",
      rating: 4.8,
      ratingCount: 126,
      inn: "190000001",
      verificationStatus: "approved",
      verified: true,
      user: {
        create: {
          email: "seller1@evmarket.by",
          name: "ЭлектроМир",
          role: "seller",
          phone: "+375291234567",
          passwordHash: await hash("seller123"),
        },
      },
    },
  });
  const sellerPrivate = await prisma.seller.create({
    data: {
      displayName: "Алексей",
      type: "individual",
      city: "Гомель",
      phone: "+375447654321",
      rating: 4.5,
      ratingCount: 12,
      user: {
        create: {
          email: "seller2@evmarket.by",
          name: "Алексей",
          role: "seller",
          phone: "+375447654321",
          passwordHash: await hash("seller123"),
        },
      },
    },
  });
  const sellers = [sellerDealer, sellerPrivate];

  console.log("Объявления…");
  const now = Date.now();
  for (const [i, l] of LISTINGS.entries()) {
    const categoryId = categoryIds.get(l.category);
    if (!categoryId) throw new Error(`Нет категории ${l.category}`);
    const subcategoryId = l.sub ? categoryIds.get(`${l.category}/${l.sub}`) : undefined;
    const createdAt = new Date(now - l.daysAgo * 86_400_000 - i * 3_600_000);
    const status: ListingStatus = l.status ?? "active";

    const listing = await prisma.listing.create({
      data: {
        sellerId: sellers[l.seller].id,
        categoryId,
        subcategoryId,
        title: l.title,
        description: l.description,
        price: new Prisma.Decimal(l.price),
        currency: "BYN",
        priceByn: new Prisma.Decimal(l.price),
        oldPriceByn: l.oldPrice ? new Prisma.Decimal(l.oldPrice) : null,
        city: l.city,
        condition: l.condition,
        discountReason: l.discountReason ?? null,
        attrs: l.attrs,
        isOriginal: l.original !== undefined,
        originalVerified: l.original === "verified",
        serialNumber: l.serial ?? null,
        vin: l.vin ?? null,
        hasInstallment: Boolean(l.installment?.length),
        status,
        views: l.views,
        createdAt,
        publishedAt: status === "active" ? createdAt : null,
        media: {
          create: [0, 1, 2].map((n) => ({
            url: `https://picsum.photos/seed/ev${i}-${n}/800/600`,
            kind: "image",
            sortOrder: n,
          })),
        },
        badges: {
          create: badgeCodes(l).flatMap((code) => {
            const id = badgeId.get(code);
            return id ? [{ badgeId: id }] : [];
          }),
        },
        installmentOffers: {
          create: (l.installment ?? []).flatMap((code) => {
            const bank = bankByCode.get(code);
            return bank
              ? [{ bankId: bank.id, rate: bank.defaultRate, terms: code === "belkredit" ? [3, 6] : [3, 6, 12, 24], minDownPercent: code === "neman" ? 10 : 0 }]
              : [];
          }),
        },
      },
    });
    await prisma.moderationLog.create({
      data: {
        listingId: listing.id,
        actorId: status === "active" ? admin.id : null,
        action: status === "active" ? "approved" : "submitted",
      },
    });
  }

  const total = await prisma.listing.count();
  console.log(`Готово: ${total} объявлений, ${banks.length} банка, ${sellers.length} продавца.`);
  console.log("Логины: admin@evmarket.by / admin123, seller1@evmarket.by / seller123, seller2@evmarket.by / seller123, buyer@evmarket.by / buyer123");
}

main()
  .catch((e: unknown) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
