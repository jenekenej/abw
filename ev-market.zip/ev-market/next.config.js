/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    // Демо-фото берём с picsum.photos, загруженные — из /public/uploads
    remotePatterns: [{ protocol: "https", hostname: "picsum.photos" }],
  },
  experimental: {
    // Увеличиваем лимит тела запроса для загрузки фото
    serverActions: { bodySizeLimit: "10mb" },
  },
};

module.exports = nextConfig;
